

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Cardiac Risk Factor</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form action="/update_crf" method="POST">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            let toaster = toastr.success(
                                '<?php echo e(Session::get('
                                status ')); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table  table-responsive mb-3">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td colspan="3">
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2"
                                class="table table-responsive no-border">
                                <tbody>
                                    <tr>
                                        <td width="23%">&nbsp;</td>
                                        <td width="19%"><b>RESULT </b></td>
                                        <td colspan="2"><b>POINTS OF RISK FACTOR </b></td>
                                    </tr>
                                    <tr>
                                        <td><b>1. AGE</b></td>
                                        <td><input name="age_result" type="text" class="form-control" id="age_result"
                                                value="<?php echo e($exam->age_result); ?>"></td>
                                        <td width="19%"><input name="age_points" type="text" class="form-control"
                                                id="age_points" value="<?php echo e($exam->age_points); ?>"></td>
                                        <td width="38%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>2. HDL-C</b></td>
                                        <td><input name="hdl_result" type="text" class="form-control" id="hdl_result"
                                                value="<?php echo e($exam->hdl_result); ?>"></td>
                                        <td><input name="hdl_points" type="text" class="form-control" id="hdl_points"
                                                value="<?php echo e($exam->hdl_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>3. TOTAL- C </b></td>
                                        <td><input name="total_result" type="text" class="form-control"
                                                id="total_result" value="<?php echo e($exam->total_result); ?>"></td>
                                        <td><input name="total_points" type="text" class="form-control"
                                                id="total_points" value="<?php echo e($exam->total_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>4. SBP</b></td>
                                        <td><input name="sbp_result" type="text" class="form-control" id="sbp_result"
                                                value="<?php echo e($exam->sbp_result); ?>"></td>
                                        <td><input name="sbp_points" type="text" class="form-control" id="sbp_points"
                                                value="<?php echo e($exam->sbp_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>5. SMOKER</b></td>
                                        <td>
                                            <input name="smoker_result" type="radio" id="smoker_result_0" value="(-)"
                                                <?php echo $exam->smoker_result == '(-)' ? "checked" : null ?>>
                                            (-)
                                            <input name="smoker_result" type="radio" id="smoker_result_1" value="(+)"
                                                <?php echo $exam->smoker_result == '(+)' ? "checked" : null ?>>
                                            (+)
                                        </td>
                                        <td><input name="smoker_points" type="text" class="form-control"
                                                id="smoker_points" value="<?php echo e($exam->smoker_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>6. DIABETES </b></td>
                                        <td>
                                            <input name="diabetes_result" type="radio" id="diabetes_result_0"
                                                value="(-)" <?php echo $exam->diabetes_result == '(-)' ? 'checked' : ''
                                            ?>>
                                            (-)
                                            <input name="diabetes_result" type="radio" id="diabetes_result_1"
                                                value="(+)" <?php echo $exam->diabetes_result == '(+)' ? 'checked' : ''
                                            ?>>
                                            (+)
                                        </td>
                                        <td><input name="diabetes_points" type="text" class="form-control"
                                                id="diabetes_points" value="<?php echo e($exam->diabetes_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>7. ECG-LVH</b></td>
                                        <td>
                                            <input name="ecg_result" type="radio" id="ecg_result_0" value="(-)" <?php
                                                echo $exam->ecg_result == '(-)' ? 'checked' : '' ?>>
                                            (-)
                                            <input name="ecg_result" type="radio" id="ecg_result_1" value="(+)" <?php
                                                echo $exam->ecg_result == '(+)' ? 'checked' : '' ?>>
                                            (+)
                                        </td>
                                        <td><input name="ecg_points" type="text" class="form-control" id="ecg_points"
                                                value="<?php echo e($exam->ecg_points); ?>"></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>PROBABILITY</b></td>
                                        <td><input name="probability" type="text" class="form-control" id="probability"
                                                value="<?php echo e($exam->probability); ?>"></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="0" cellpadding="2"
                                class="table no-border table-responsive">
                                <tbody>
                                    <tr>
                                        <td colspan="5"><b>SPIROMETRY RESULTS</b></td>
                                    </tr>
                                    <tr>
                                        <td width="182">&nbsp;</td>
                                        <td width="169"><b>Predicted</b></td>
                                        <td width="162"><b>Actual</b></td>
                                        <td width="171" align="center"><b>Percentage</b></td>
                                        <td width="96" align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>FEV 1 </td>
                                        <td><input name="fev1_predicted" type="text" class="form-control"
                                                id="fev1_predicted" value="<?php echo e($exam->fev1_predicted); ?>"></td>
                                        <td><input name="fev1_actual" type="text" class="form-control" id="fev1_actual"
                                                value="<?php echo e($exam->fev1_actual); ?>"></td>
                                        <td><input name="fev1_perc" type="text" class="form-control" id="fev1_perc"
                                                value="<?php echo e($exam->fev1_perc); ?>"></td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>FVC </td>
                                        <td><input name="fvc_predicted" type="text" class="form-control"
                                                id="fvc_predicted" value="<?php echo e($exam->fvc_predicted); ?>"></td>
                                        <td><input name="fvc_actual" type="text" class="form-control" id="fvc_actual"
                                                value="<?php echo e($exam->fvc_actual); ?>"></td>
                                        <td><input name="fvc_perc" type="text" class="form-control" id="fvc_perc"
                                                value="<?php echo e($exam->fvc_perc); ?>"></td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>FEV1/ FVC % </td>
                                        <td><input name="fev1fvc_predicted" type="text" class="form-control"
                                                id="fev1fvc_predicted" value="<?php echo e($exam->fev1fvc_predicted); ?>"></td>
                                        <td><input name="fev1fvc_actual" type="text" class="form-control"
                                                id="fev1fvc_actual" value="<?php echo e($exam->fev1fvc_actual); ?>"></td>
                                        <td><input name="fev1fvc_perc" type="text" class="form-control"
                                                id="fev1fvc_perc" value="<?php echo e($exam->fev1fvc_perc); ?>"></td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>RESULT</td>
                                        <td><input name="result" type="text" class="form-control" id="result"
                                                value="<?php echo e($exam->ecg_points); ?>"></td>
                                        <td align="center">&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="24%"><b>Nurse</b></td>
                                                        <td width="76%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "11" ? 'selected' : null); ?>

                                                                        value="11">Pinky Jay C. Junio, R.N.</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "17" ? 'selected' : null); ?>

                                                                        value="17">Jennifer Joy C. Velete, RN
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "52" ? 'selected' : null); ?>

                                                                        value="52">Nanette D. Cabiserano</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Medical Director</b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "2" ? 'selected' : null); ?>

                                                                        value="2">Teresita F. Gonzales, MD</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="card-footer">
                                <button type="reset" class="btn btn-warning mr-1">
                                    <i class="feather icon-x"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-check-square-o"></i> Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/CardiacRiskFactor/edit-crf.blade.php ENDPATH**/ ?>