

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit ECG</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_ecg" role="form">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table=bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control my-1"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control my-1 input-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control my-1" readonly="">
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td colspan="3">
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="12%"><b>Otoscopy:</b></td>
                                        <td width="88%">
                                            <input name="otoscopy" type="text" id="otoscopy"
                                                value="<?php echo e($exam->otoscopy); ?>" size="15" class="form-control my-1"
                                                placeholder="Otoscopy">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Heart:</b></td>
                                        <td>
                                            <input name="heart" type="text" id="heart" value="<?php echo e($exam->heart); ?>"
                                                size="15" class="form-control my-1" placeholder="Heart">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Lung:</b></td>
                                        <td>
                                            <input name="lung" type="text" id="lung" value="<?php echo e($exam->lung); ?>" size="15"
                                                class="form-control my-1" placeholder="Lung">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><b>ECG Result:</b></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio"  name="ecg" id="radio" value="Normal" <?php echo
                                                $exam->ecg == 'Normal' ? 'checked' : '' ?>>
                                            Normal
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio"  name="ecg" id="radio" value="Significant Findings" <?php
                                                echo $exam->ecg == 'Significant Findings' ? 'checked' : '' ?>>
                                            Significant Findings
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio"  name="ecg" id="radio" value="Not Required" <?php echo
                                                $exam->ecg == 'Not Required' ? 'checked' : '' ?>>
                                            Not Required
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio"  name="ecg" id="radio"
                                                value="Clinically Not Significant">
                                            Clinically Not Significant
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td><b>Nurse: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $nurses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nurse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value=<?php echo e($nurse->id); ?>><?php echo e($nurse->firstname); ?> <?php echo e($nurse->lastname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="24%"><b>Physician</b></td>
                                                        <td width="76%">
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <?php $__currentLoopData = $physicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $physician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value=<?php echo e($physician->id); ?> <?php echo e($physician->id == $exam->technician2_id ? "selected" : null); ?>><?php echo e($physician->firstname); ?> <?php echo e($physician->lastname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/ECG/edit-ecg.blade.php ENDPATH**/ ?>