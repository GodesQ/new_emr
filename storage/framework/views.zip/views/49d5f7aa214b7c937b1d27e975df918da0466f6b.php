

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit HIV</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_hiv" role="form">
                            <?php if(Session::get('status')): ?>
                                <?php $__env->startPush('scripts'); ?>
                                    <script>
                                       toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td colspan="3"><b>EXAMINATION DONE:</b></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <input name="exam" type="radio" class="m-1" id="exam_2" value="enzyme" <?php
                                                echo $exam->exam == "enzyme" ? "checked" : "" ?>>
                                            EIA/CMIA/ELFA&nbsp;
                                            <input name="exam" type="radio" class="m-1" id="exam_0" value="rapid" <?php
                                                echo $exam->exam == "rapid" ? "checked" : "" ?>>
                                            RAPID &nbsp;
                                            <input name="exam" type="radio" class="m-1" id="exam_1" value="particle"
                                                <blade
                                                php|%20echo%20%24exam-%3Eexam%20%3D%3D%20%26%2334%3Bparticle%26%2334%3B%20%3F%20%26%2334%3Bchecked%26%2334%3B%20%3A%20%26%2334%3B%26%2334%3B%20%40endphp%3E%0D>
                                            Particle Agglutination
                                            <input name="exam" type="radio" class="m-1" id="exam_3" value="others" <?php
                                                echo $exam->exam == "others" ? "checked" : "" ?>>
                                            OTHERS&nbsp;
                                        </td>
                                        <td width="45%">
                                            <input name="others" type="text" id="others" value="<?php echo e($exam->others); ?>"
                                                placeholder="Others..." class="form-control" style="width:200px">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="25%"><b>Result</b></td>
                                        <td colspan="2">
                                            <input name="result" type="radio" id="result_0" class="m-1"
                                                value="Non Reactive" <?php echo $exam->result == "Non Reactive" ? "checked" : "" ?>>Non Reactive
                                            <input name="result" type="radio" id="result_1" class="m-1" value="Reactive" <?php echo $exam->result == "Reactive" ? "checked" : "" ?>>
                                                Reactive
                                            <input name="result" type="radio" id="result_2" class="m-1" value="" <?php echo $exam->result == "" ? "checked" : "" ?>>Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>HIV Proficiency Cert. <br>
                                                Expiry Date</b></td>
                                        <td colspan="2"><input name="expiry_date" type="date" max="2050-12-31" id="expiry_date"
                                                value="<?php echo e($exam->expiry_date); ?>" class="form-control"
                                                style="width:160px">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td><b>Physician: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician3_id"
                                                                    id="technician3_id" class="form-control">
                                                                    <?php $__currentLoopData = $physicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $physician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($physician->id); ?> <?php echo e($physician->id == $exam->technician3_id ? "selected" : null); ?>><?php echo e($physician->firstname); ?> <?php echo e($physician->lastname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $med_techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med_tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($med_tech->id); ?> <?php echo e($med_tech->id == $exam->technician_id ? "selected" : null); ?>><?php echo e($med_tech->firstname); ?> <?php echo e($med_tech->lastname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <?php $__currentLoopData = $pathologists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pathologist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($pathologist->id); ?> <?php echo e($pathologist->id == $exam->technician2_id ? "selected" : null); ?>><?php echo e($pathologist->firstname); ?> <?php echo e($pathologist->lastname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/HIV/edit-hiv.blade.php ENDPATH**/ ?>