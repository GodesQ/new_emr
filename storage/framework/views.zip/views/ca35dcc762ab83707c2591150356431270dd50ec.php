

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo e($classification); ?>

    <?php if($classification == 'patient'): ?>
    <script>
    window.location = "/progress-patient-info";
    </script>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>