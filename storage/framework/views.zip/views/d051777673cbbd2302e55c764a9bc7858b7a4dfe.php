<html>

<head>
    <title>DAILY PATIENT</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    * {
        font-size: 10px;
        text-transform: uppercase;
    }

    @page  {
        size: landscape;
    }
    </style>
</head>

<body>
    <center>
        <table class="brdAll" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td align="center">
                        <table class="brdNone" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td>
                                        <b style="font-size: 20px;">
                                            <?php $created_at = new DateTime($request_date); 
                                                echo date_format($created_at,'F d, Y'); 
                                            ?></b>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td><b>Record NO.</b></td>
                                    <td><b>AGENCY</b></td>
                                    <td><b>NO.</b></td>
                                    <td><b>FAMILY NAME</b></td>
                                    <td><b>FIRST NAME</b></td>
                                    <td><b>MIDDLE NAME</b></td>
                                    <td><b>AGE/SEX</b></td>
                                    <td><b>POSITION</b></td>
                                    <td><b>PACKAGE</b></td>
                                    <td><b>PRINCIPAL</b></td>
                                    <td><b>ADD TEST</b></td>
                                    <td><b>VESSEL</b></td>
                                    <td><b>LAST MEDICAL</b></td>
                                    <td><b>BDAY</b></td>
                                    <td><b>BILLED/PAID</b></td>
                                    <td><b>REFERRAL NAME</b></td>
                                </tr>
                                <?php $count = 1; ?>
                                <?php if(count($today_patients) > 0): ?>
                                    <?php $__currentLoopData = $today_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $today_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($today_patient->admission_id); ?></td>
                                            <td><?php echo e($today_patient->agencyname); ?></td>
                                            <td><?php echo e($count++); ?></td>
                                            <td><?php echo e($today_patient->patient_lastname); ?></td>
                                            <td><?php echo e($today_patient->patient_firstname); ?></td>
                                            <td><?php echo e($today_patient->patient_middlename); ?></td>
                                            <td><?php echo e($today_patient->patient_age ? $today_patient->patient_age : 0); ?>/<?php echo e($today_patient->patient_gender); ?></td>
                                            <td><?php echo e($today_patient->position); ?></td>
                                            <td><?php echo e($today_patient->packagename); ?></td>
                                            <td><?php echo e($today_patient->principal); ?></td>
                                            <td></td>
                                            <td><?php echo e($today_patient->vessel); ?></td>
                                            <td><?php echo e($today_patient->last_medical); ?></td>
                                            <td><?php echo e($today_patient->birthdate); ?></td>
                                            <td><?php echo e($today_patient->payment_type); ?></td>
                                            <td><?php echo e($today_patient->requestor); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="20" align="center">No Record Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </center>
    <script>
        window.addEventListener('load', () => {
            window.print();
        })
    </script>
</body>
</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintTemplates/daily_patient_print.blade.php ENDPATH**/ ?>