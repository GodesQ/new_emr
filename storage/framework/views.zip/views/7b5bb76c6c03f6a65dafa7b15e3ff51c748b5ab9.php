<html>

<head>
    <title>West England</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <!--<link href="dist/css/eureka-print.css?v=1650353917" rel="stylesheet" type="text/css" />-->
    <style>
    body,
    table,
    tr,
    td {
        font-family: arial;
        font-size: 9px;
    }

    .fontBoldLrg {
        font: bold 15px arial;
    }

    .fontMed {
        font: normal 12px arial;
    }
    @page  {
        size: A4;
    }
    </style>
</head>

<body>
    <center>
        <table width="680" border="0" cellpadding="2" cellspacing="0">
            <tbody>
                <tr>
                    <td colspan="3" align="center" valign="bottom" class="lblReport">
                        <table width="680" border="0" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td align="right">
                                        <img src="../../../app-assets/images/logo/logoWOE.png">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" valign="top">
                        <table width="680" border="0" cellspacing="1" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <table width="680" border="0" cellpadding="3" cellspacing="0" class="brdMLC">
                                            <tbody>
                                                <tr>
                                                    <td colspan="5" align="center"
                                                        style="font-size:x-large; font-weight:bold;">MEDICAL CERTIFICATE
                                                        FOR SERVICE AT SEA</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" valign="top">
                                                        SURNAME/LAST NAME:<br>
                                                        <span class="fontBoldLrg"><?php echo e($admission->lastname); ?></span>
                                                    </td>
                                                    <td colspan="2" valign="top">
                                                        GIVEN/FIRST NAME:<br>
                                                        <span class="fontBoldLrg"><?php echo e($admission->firstname); ?></span>
                                                    </td>
                                                    <td width="213" valign="top">
                                                        MIDDLE NAME:<br>
                                                        <span class="fontBoldLrg"><?php echo e($admission->middlename); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td width="91" valign="top">
                                                        AGE:<br>
                                                        <span class="fontMed"><?php echo e($admission->age); ?></span>
                                                    </td>
                                                    <td colspan="2" valign="top">
                                                        DATE OF BIRTH: (DAY/MONTH/YEAR)<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->birthdate); ?></span>
                                                    </td>
                                                    <td width="205" valign="top">
                                                        PLACE OF BIRTH:<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->birthplace); ?></span>
                                                    </td>
                                                    <td valign="top">
                                                        NATIONALITY:<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->nationality); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" valign="top">
                                                        GENDER:&nbsp;&nbsp;<?php echo e($admission->gender); ?> </td>
                                                    <td colspan="2" valign="top">
                                                        CIVIL STATUS:&nbsp;&nbsp; </td>
                                                    <td valign="top">
                                                        <?php echo e($patientInfo->maritalstatus); ?>:&nbsp;&nbsp; </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5" valign="top">
                                                        ADDRESS:<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->address); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4" valign="top">
                                                        PASSPORT NUMBER:<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->passportno); ?></span>
                                                    </td>
                                                    <td valign="top">SEAMAN'S BOOK NUMBER:<br>
                                                        <span class="fontMed"><?php echo e($patientInfo->srbno); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4" valign="top">
                                                        POSITION APPLIED FOR:<br>
                                                        <b>DECK</b>&nbsp;&nbsp;&nbsp;
                                                        <?php if($admission->category == "DECK SERVICES"): ?>
                                                        <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                        <img src="../../../app-assets/images/icoUncheck.gif" width="10">
                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <b>ENGINE</b>&nbsp;&nbsp;&nbsp;
                                                        <?php if($admission->category == "ENGINE SERVICES"): ?>
                                                        <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                        <img src="../../../app-assets/images/icoUncheck.gif" width="10">
                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <b>CATERING&nbsp;&nbsp;&nbsp;</b>
                                                        <?php if($admission->category == "CATERING SERVICES"): ?>
                                                        <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                        <img src="../../../app-assets/images/icoUncheck.gif" width="10">
                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;
                                                        <b>OTHER</b>
                                                        <?php if($admission->category == "OTHER SERVICES"): ?>
                                                        <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                        <img src="../../../app-assets/images/icoUncheck.gif" width="10">
                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                        SPECIFY: <?php echo e($admission->other_position); ?>

                                                    </td>
                                                    <td valign="top">COMPANY:<br>
                                                        <span class="fontMed"><?php echo e($admission->agencyname); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5"><b>DECLARATION OF THE AUTHORIZED PHYSICIAN</b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">CONFIRMATION THAT
                                                                        IDENTIFICATION DOCUMENTS WERE CHECKED AT THE
                                                                        POINT OF EXAMINATION:</td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <!-- check if the remarks in patient exam_audio is normal -->
                                                                    <td width="87%" valign="middle">HEARING MEETS THE
                                                                        STANDARDS IN STCW
                                                                        CODE, SECTION A-1/9?</td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_audio): ?>
                                                                        <?php if(preg_match('/Normal/i', $exam_audio->remarks) || preg_match('/Cleared/i', $exam_audio->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_audio): ?>
                                                                        <?php if(!preg_match('/Normal/i',
                                                                        $exam_audio->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">UNAIDED HEARING
                                                                        SATISFACTORY? </td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_audio): ?>
                                                                        <?php if(preg_match('/unaided/i',
                                                                        $exam_audio->hearing)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_audio): ?>
                                                                        <?php if(!preg_match('/aided/i',
                                                                        $exam_audio->hearing)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">VISUAL ACUITY MEETS
                                                                        STANDARDS IN
                                                                        STCW CODE, SECTION A-1/9?</td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_visacuity): ?>
                                                                        <?php if(preg_match('/Normal/i',
                                                                        $exam_visacuity->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>

                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_visacuity): ?>
                                                                        <?php if(!preg_match('/Normal/i',
                                                                        $exam_visacuity->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5" valign="top">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">COLOUR VISION MEETS
                                                                        STANDARDS IN
                                                                        STCW CODE, SECTION A-1/9? <br>
                                                                        Date of last colour vision test:
                                                                        <?php echo e($exam_ishihara ? $exam_ishihara->trans_date : null); ?>

                                                                    </td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_ishihara): ?>
                                                                        <?php if(preg_match('/Normal/i', $exam_ishihara->remarks) || preg_match('/Cleared/i', $exam_ishihara->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_ishihara): ?>
                                                                        <?php if(!preg_match('/Normal/i',
                                                                        $exam_ishihara->remarks)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="32%" valign="middle">VISUAL AIDS (tick if
                                                                        worn) </td>
                                                                    <td width="11%" align="right" valign="middle">
                                                                        SPECTACLES&nbsp;&nbsp;
                                                                    </td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if(preg_match('/Spectacles/i',
                                                                        $exam_physical->visual_required)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="14%" align="right" valign="middle">
                                                                        CONTACT
                                                                        LENSES&nbsp;&nbsp; </td>
                                                                    <td width="40%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if(preg_match('/Contact Lenses/i',
                                                                        $exam_physical->visual_required)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">FIT FOR LOOKOUT
                                                                        DUTIES: </td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if(preg_match('/Fit/i',
                                                                        $exam_physical->duty)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if(!preg_match('/Fit/i',
                                                                        $exam_physical->duty)): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="tblNoneRightNew">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="87%" valign="middle">FIT BUT AT RISK?<br>
                                                                        If “AT RISK” specify limitations or
                                                                        restrictions : <br>
                                                                        <textarea name="co" type="text" id="co" value="" class="brdNone" style="width:500px;height: 30px;font-size: 10px;text-align:left;border: none;"></textarea> 
                                                                    </td>
                                                                    <td width="4%" valign="middle">YES</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if($exam_physical->question8 == "Yes" ||
                                                                        $exam_physical->question8 == "1"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="3%" valign="middle">NO</td>
                                                                    <td width="3%" valign="middle">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php if($exam_physical->question8 == "No" ||
                                                                        $exam_physical->question8 == "0"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table width="678" border="0" cellpadding="0" cellspacing="0" class="brdAll">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table width="678" border="0" cellpadding="3" cellspacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="178" align="center" valign="middle"
                                                                        class="brdBtm" style="padding-top:20px;">
                                                                        <?php if($admission->patient_image): ?>
                                                                        <img src="../../../app-assets/images/profiles/<?php echo e($admission->patient_image); ?>"
                                                                            alt="Patient Picture" width="140"
                                                                            height="140" class="brdAll">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                                                            alt="Patient Picture" width="140"
                                                                            height="140" class="brdAll">
                                                                        <?php endif; ?><br>
                                                                        <span class="fontMed">P22-007559</span>
                                                                    </td>
                                                                    <td width="500" class="brdLeftBtm">
                                                                        <table width="500" border="0" cellpadding="0"
                                                                            cellspacing="0" class="size10">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td colspan="2">
                                                                                        THIS IS TO CERTIFY THAT A
                                                                                        MEDICAL AND PHYSICAL EXAMINATION
                                                                                        WAS GIVEN IN ACCORDANCE WITH
                                                                                        WEST OF ENGLAND REOMMENDED
                                                                                        PROTOCOLS HAS BEEN CARRIED
                                                                                        OUT<br>
                                                                                        <br>
                                                                                        <span>NAME OF SEAFARER:
                                                                                        </span><span
                                                                                            class="fontBoldLrg"><u><?php echo e($admission->lastname); ?>,
                                                                                                <?php echo e($admission->firstname); ?>

                                                                                                <?php echo e($admission->middlename); ?></u></span><br><br>
                                                                                        <span
                                                                                            class="fontMed">RESULT:<br><br>
                                                                                            <span
                                                                                                style="margin-left:50px">FIT
                                                                                                FOR DUTY
                                                                                                <?php if($exam_physical): ?>
                                                                                                <?php if(preg_match('/Fit/i',
                                                                                                $exam_physical->duty) ): ?>
                                                                                                <img src="../../../app-assets/images/icoCheck.gif"
                                                                                                    width="10">
                                                                                                <?php else: ?>
                                                                                                <img src="../../../app-assets/images/icoUncheck.gif"
                                                                                                    width="10">
                                                                                                <?php endif; ?>
                                                                                                <?php else: ?>
                                                                                                <img src="../../../app-assets/images/icoUncheck.gif"
                                                                                                    width="10">
                                                                                                <?php endif; ?>
                                                                                            </span>
                                                                                            <span
                                                                                                style="margin-left:20px">FIT
                                                                                                BUT AT RISK <img
                                                                                                    src="../../../app-assets/images/icoUncheck.gif"
                                                                                                    width="10"></span>
                                                                                            <span
                                                                                                style="margin-left:20px">UNFIT
                                                                                                FOR DUTY
                                                                                                <?php if($exam_physical): ?>
                                                                                                <?php if(!preg_match('/Fit/i',
                                                                                                $exam_physical->duty)): ?>
                                                                                                <img src="../../../app-assets/images/icoCheck.gif"
                                                                                                    width="10">
                                                                                                <?php else: ?>
                                                                                                <img src="../../../app-assets/images/icoUncheck.gif"
                                                                                                    width="10">
                                                                                                <?php endif; ?>
                                                                                                <?php else: ?>
                                                                                                <img src="../../../app-assets/images/icoUncheck.gif"
                                                                                                    width="10">
                                                                                                <?php endif; ?>
                                                                                            </span>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td colspan="2" valign="bottom">
                                                                                        <br><br>
                                                                                        <span
                                                                                            style="margin-left:280px"><img
                                                                                                src="" alt="e-Signature"
                                                                                                width="80"
                                                                                                height="25"></span><br>
                                                                                        Name and Signature of
                                                                                        Examining/Authorized Physician:
                                                                                        <?php if($exam_physical): ?>
                                                                                        <?php echo e($exam_physical->tech1_firstname . " " . $exam_physical->tech1_middlename . " " . $exam_physical->tech1_lastname); ?>

                                                                                        <?php endif; ?><br><br>
                                                                                        Date of Examination:
                                                                                        <?php if($exam_physical): ?>
                                                                                        <?php echo e(date_format(new DateTime($exam_physical->trans_date), "F d, Y")); ?>

                                                                                        <?php endif; ?><br>
                                                                                        <br>
                                                                                        <br>
                                                                                        <br>
                                                                                        Approved By: TERESITA F.
                                                                                        GONZALES, MD<br><br>
                                                                                        Title: MEDICAL DIRECTOR
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="150" align="center" class="brdRight">
                                                                        <img src="../../../app-assets/images/logo/hologramWOE.jpg"
                                                                            width="100" height="100"><br><span
                                                                            class="fontMed"></span>
                                                                    </td>
                                                                    <td valign="top" class="brdLeft">
                                                                        <table width="100%" border="0" cellspacing="0"
                                                                            cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td valign="top">
                                                                                        NAME OF CLINIC: MERITA
                                                                                        DIAGNOSTIC CLINIC INC.<br><br>
                                                                                        ADDRESS: 5th &amp; 6th Flr
                                                                                        Jettac Bldg., 920 Quirino Ave.
                                                                                        Cor. San Antonio St. Malate
                                                                                        Manila<br><br>
                                                                                        PHYSICIAN’S CERTIFYING
                                                                                        AUTHORITY: PROFESSIONAL
                                                                                        REGULATION COMMISSION <br><br>
                                                                                        PHYSICIAN’S LICENSE NUMBER:
                                                                                        <?php if($exam_physical): ?>
                                                                                        <?php echo e($exam_physical->license_no); ?>

                                                                                        <?php endif; ?> </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="680" border="0" cellpadding="2" cellspacing="0" class="brdMLC">
                                            <tbody>
                                                <tr>
                                                    <td colspan="7">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0"
                                                            id="brdNone">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="4">I HAVE READ AND UNDERSTOOD AND WAS
                                                                        INFORMED OF THE CONTENTS OF THE CERTIFICATE AND
                                                                        OF THE RIGHT TO A REVIEW IN ACCORDANCE WITH
                                                                        PARAGRAPH 6 OF SECTION A-1/9 OF THE STCW
                                                                        CODE.<br><br> </td>
                                                                </tr>
                                                                <style>
                                                                #divImage {
                                                                    width: 100%;
                                                                    height: 35px;
                                                                    overflow: hidden;
                                                                    position: relative;
                                                                }

                                                                #divImage img {
                                                                    position: absolute;
                                                                    width: 100px;
                                                                    height: 50px;
                                                                    top: 1%;
                                                                    left: 35%;
                                                                }
                                                                </style>
                                                                <tr>
                                                                    <td width="27%">&nbsp;</td>
                                                                    <td width="48%" align="center">
                                                                        <div id="divImage"></div>
                                                                    </td>
                                                                    <td width="6%">&nbsp;</td>
                                                                    <td width="19%">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="27%">SEAFARER’S NAME AND SIGNATURE:</td>
                                                                    <td width="48%" align="center"
                                                                        style="border-bottom:solid 1px black">
                                                                        <b><?php echo e($admission->lastname); ?>,
                                                                            <?php echo e($admission->firstname); ?>

                                                                            <?php echo e($admission->middlename); ?></b>
                                                                    </td>
                                                                    <td width="6%">DATE:</td>
                                                                    <td width="19%"
                                                                        style="border-bottom:solid 1px black"></td>
                                                                </tr>
                                                                <tr height="20">
                                                                    <td colspan="4" valign="bottom">(This signature
                                                                        should be affixed in the presence of the
                                                                        examining physician)</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" cellpadding="2" cellspacing="0" class="brdMLC"
                                            style="margin-top:1px">
                                            <tbody>
                                                <tr>
                                                    <td colspan="6" style="font-size:12px"> <b>DATE OF ISSUANCE:</b></td>
                                                    <td width="51%" style="font-size:12px"> <b>DATE OF EXPIRATION:</b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" valign="top"> <span class="lblForm">FORM NO.84 / REV. 00 / 21 Feb. 2019</span> </td>
                </tr>
            </tbody>
        </table>
    </center>

</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintPanel/west_england.blade.php ENDPATH**/ ?>