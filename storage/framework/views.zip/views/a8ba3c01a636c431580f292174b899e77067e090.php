<html>

<head>
    <title>Medical Examination Report for Seafarers</title>
    <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
    <link href="dist/css/eureka-print.css?v=1650448751" rel="stylesheet" type="text/css">
    <style>
    body,
    table,
    tr,
    td {
        font-family: arial;
        font-size: 10px;
    }

    .aa {
        font-size: 10px;
    }
    </style>
</head>

<body>
    <center>
        <table width="800" border="0" cellpadding="2" cellspacing="2">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" border="1" cellpadding="5" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td align="center" valign="top"><span
                                            style="font-size:18px;font-weight:bold">MEDICAL EXAMINATION REPORT FOR
                                            SEAFARERS</span><br>
                                        Approved and authorized by the Department of Health(DOH) and the Maritime
                                        Industry Authority (MARINA) of the Republic of the Philippines <br>
                                        Issued in compliance with STCW Convention, 1978, as amended Section A-1/9
                                        Paragraph 7 and the Maritime Labour Convetion, 2008.</td>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <table width="100%" border="1" cellpadding="0" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td>
                                        <table width="100%" border="1" cellpadding="5"
                                            style="border-top : none;border-left : none;border-right : none;"
                                            cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td colspan="2">
                                                        SURNAME/LASTNAME<br>
                                                        <span class="lblName"><?php echo e($admission->lastname); ?></span>
                                                    </td>
                                                    <td>
                                                        GIVEN NAME<br>
                                                        <span class="lblName"><?php echo e($admission->firstname); ?></span>
                                                    </td>
                                                    <td>
                                                        MIDDLE NAME<br>
                                                        <span class="lblName"><?php echo e($admission->middlename); ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td width="13%">
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>AGE</td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><?php echo e($admission->age); ?></b>&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td width="27%">
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>DATE OF BIRTH (YEAR/MONTH/DAY)</td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><?php echo e($patientInfo->birthdate); ?></b>&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td width="30%">
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="4">PLACE OF BIRTH :(City/Country)</td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><?php echo e($patientInfo->birthplace); ?></b>&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td width="30%">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>NATIONALITY :</td>
                                                                </tr>
                                                                <tr>
                                                                    <td><b><?php echo e($patientInfo->nationality); ?></b>&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">GENDER:&nbsp;&nbsp;
                                                        Male
                                                        <?php if($admission->gender == 'Male'): ?>
                                                        <span style="font-size:15px;">☑</span>
                                                        <?php else: ?>
                                                        <span style="font-size:15px;">☐</span>
                                                        <?php endif; ?>
                                                        Female
                                                        <?php if($admission->gender == 'Female'): ?>
                                                        <span style="font-size:15px;">☑</span>
                                                        <?php else: ?>
                                                        <span style="font-size:15px;">☐</span>
                                                        <?php endif; ?>

                                                    </td>
                                                    <td>CIVIL STATUS:&nbsp;&nbsp;
                                                        Single
                                                        <?php if($patientInfo->maritalstatus == 'Single'): ?>
                                                        <span style="font-size:15px;">☑</span>
                                                        <?php else: ?>
                                                        <span style="font-size:15px;">☐</span>
                                                        <?php endif; ?>
                                                        Married
                                                        <?php if($patientInfo->maritalstatus == 'Married'): ?>
                                                        <span style="font-size:15px;">☑</span>
                                                        <?php else: ?>
                                                        <span style="font-size:15px;">☐</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td> RELIGION: <b><?php echo e($patientInfo->religion); ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">ADDRESS : <b><?php echo e($patientInfo->address); ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">PASSPORT NUMBER : <b>
                                                            <?php echo e($patientInfo->passportno); ?></b></td>
                                                    <td colspan="2">SEAMAN'S BOOK(SIRB) NUMBER : <b>
                                                            <?php echo e($patientInfo->srbno); ?> </b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>POSITION APPLIED FOR:<br>
                                                                        <b>DECK</b>&nbsp;&nbsp;&nbsp;
                                                                        <?php if($admission->category == "DECK SERVICES"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        <b>ENGINE</b>&nbsp;&nbsp;&nbsp;
                                                                        <?php if($admission->category == "ENGINE SERVICES"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        <b>CATERING&nbsp;&nbsp;&nbsp;</b>
                                                                        <?php if($admission->category == "CATERING SERVICES"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;
                                                                        <b>OTHER</b>
                                                                        <?php if($admission->category == "OTHER SERVICES"): ?>
                                                                        <img src="../../../app-assets/images/icoCheck.gif"
                                                                            width="10">
                                                                        <?php else: ?>
                                                                        <img src="../../../app-assets/images/icoUncheck.gif"
                                                                            width="10">
                                                                        <?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        SPECIFY: <?php echo e($admission->other_position); ?>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">NAME OF COMPANY : <b>
                                                            Marlow Navigation Phils. Inc. </b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="1" cellpadding="2" cellspacing="0"
                                                            style="border-top : none;border-left : none;border-right : none;border-bottom : none;">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="6" align="left"> I.MEDICAL HISTORY -
                                                                        Has applicant suffered from, been diagnosed,
                                                                        sought advice or treatment from medical doctor
                                                                        on the following conditions: <br>
                                                                        Place a check mark (✔) in the appropriate box<b>
                                                                            <span style="font-size:15px;">☐</span> </b>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="202" style="font-size: 10px">&nbsp;</td>
                                                                    <td width="40" align="center">YES NO</td>
                                                                    <td width="194" style="font-size: 10px">&nbsp;</td>
                                                                    <td width="42" align="center">YES NO</td>
                                                                    <td width="230" style="font-size: 10px">&nbsp;</td>
                                                                    <td width="42" align="center">YES NO</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Head or Neck Injury
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick1 == 'Yes' ||
                                                                            $exam_physical->sick1 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick1 == 'No' ||
                                                                            $exam_physical->sick1 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Other Lung Disorders
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick11 == 'Yes' ||
                                                                            $exam_physical->sick11 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick11 == 'No' ||
                                                                            $exam_physical->sick11 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Other Abdominal
                                                                            Disorder :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick21 == 'Yes' ||
                                                                            $exam_physical->sick21 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick21 == 'No' ||
                                                                            $exam_physical->sick21 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Frequent Headaches
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick2 == 'Yes' ||
                                                                            $exam_physical->sick2 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick2 == 'No' ||
                                                                            $exam_physical->sick2 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>High Blood Pressure
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick12 == 'Yes' ||
                                                                            $exam_physical->sick12 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick12 == 'No' ||
                                                                            $exam_physical->sick12 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Kidney or Bladder
                                                                            Disorder :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick22 == 'Yes' ||
                                                                            $exam_physical->sick22 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick22 == 'No' ||
                                                                            $exam_physical->sick22 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Frequent Dizziness
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick3 == 'Yes' ||
                                                                            $exam_physical->sick3 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick3 == 'No' ||
                                                                            $exam_physical->sick3 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Heart Disease/Chest
                                                                            Pain :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick13 == 'Yes' ||
                                                                            $exam_physical->sick13 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick13 == 'No' ||
                                                                            $exam_physical->sick13 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Back Injury: Joint
                                                                            Pain/Arthritis/Rheumatic :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick23 == 'Yes' ||
                                                                            $exam_physical->sick23 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick23 == 'No' ||
                                                                            $exam_physical->sick23 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px">
                                                                        <p><b>Fainting Spells, Fits,Seizures or Other
                                                                                Neurological Disorders :</b></p>
                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick4 == 'Yes' ||
                                                                            $exam_physical->sick4 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick4 == 'No' ||
                                                                            $exam_physical->sick4 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Rheumatic Fever :</b>
                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick14 == 'Yes' ||
                                                                            $exam_physical->sick14 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick14 == 'No' ||
                                                                            $exam_physical->sick14 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Genetic,Hereditary or
                                                                            Familial Disorders:</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick24 == 'Yes' ||
                                                                            $exam_physical->sick24 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick24 == 'No' ||
                                                                            $exam_physical->sick24 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="20" style="font-size: 10px"><b>Insomnia
                                                                            or Sleep Disorders :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick5 == 'Yes' ||
                                                                            $exam_physical->sick5 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick5 == 'No' ||
                                                                            $exam_physical->sick5 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Diabetes Mellitus
                                                                            :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick15 == 'Yes' ||
                                                                            $exam_physical->sick15 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick15 == 'No' ||
                                                                            $exam_physical->sick15 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b> Tropical
                                                                            Diseases(e.g Malaria,Filariasis<br>
                                                                            <br>
                                                                            Schistosomiasis - Specify Date):<br>
                                                                        </b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick25 == 'Yes' ||
                                                                            $exam_physical->sick25 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick25 == 'No' ||
                                                                            $exam_physical->sick25 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Depression, Other
                                                                            Mental Disorders :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick6 == 'Yes' ||
                                                                            $exam_physical->sick6 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick6 == 'No' ||
                                                                            $exam_physical->sick6 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Other Endocrine
                                                                            Disorder (e.g Goiter) :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick16 == 'Yes' ||
                                                                            $exam_physical->sick16 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick16 == 'No' ||
                                                                            $exam_physical->sick16 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Sexually Transmitted
                                                                            Diseases :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick26 == 'Yes' ||
                                                                            $exam_physical->sick26 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick26 == 'No' ||
                                                                            $exam_physical->sick26 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Trachoma,Other Eye
                                                                            Disorders :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick7 == 'Yes' ||
                                                                            $exam_physical->sick7 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick7 == 'No' ||
                                                                            $exam_physical->sick7 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Cancer or Tumor :</b>
                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick17 == 'Yes' ||
                                                                            $exam_physical->sick17 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick17 == 'No' ||
                                                                            $exam_physical->sick17 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Asthma :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick27 == 'Yes' ||
                                                                            $exam_physical->sick27 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick27 == 'No' ||
                                                                            $exam_physical->sick27 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Deafness, Other Ear
                                                                            Disorders :</b></td>
                                                                    <td align="center"><span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick8 == 'Yes' ||
                                                                            $exam_physical->sick8 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick8 == 'No' ||
                                                                            $exam_physical->sick8 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Blood Disorders :</b>
                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick18 == 'Yes' ||
                                                                            $exam_physical->sick18 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick18 == 'No' ||
                                                                            $exam_physical->sick18 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Allergies (Specify)
                                                                            :</b><?php echo e($exam_physical ? $exam_physical->allergies : null); ?>

                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick28 == 'Yes' ||
                                                                            $exam_physical->sick28 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick28 == 'No' ||
                                                                            $exam_physical->sick28 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Nose or Throat
                                                                            Disorders :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick9 == 'Yes' ||
                                                                            $exam_physical->sick9 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick9 == 'No' ||
                                                                            $exam_physical->sick9 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Stomach
                                                                            Pain,Gastritis or Ulcer :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick19 == 'Yes' ||
                                                                            $exam_physical->sick19 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick19 == 'No' ||
                                                                            $exam_physical->sick19 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Operations (Specify)
                                                                            :</b><?php echo e($exam_physical ? $exam_physical->operations : null); ?>

                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick29 == 'Yes' ||
                                                                            $exam_physical->sick29 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick29 == 'No' ||
                                                                            $exam_physical->sick29 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 10px"><b>Tuberculosis :</b>
                                                                    </td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick10 == 'Yes' ||
                                                                            $exam_physical->sick10 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick10 == 'No' ||
                                                                            $exam_physical->sick10 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="font-size: 10px"><b>Liver Gall Bladder
                                                                            diseases/Jaundice :</b></td>
                                                                    <td align="center">
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick20 == 'Yes' ||
                                                                            $exam_physical->sick20 == '1'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                        <span style="font-size:15px;">
                                                                            <?php if($exam_physical): ?>
                                                                            <?php if($exam_physical->sick20 == 'No' ||
                                                                            $exam_physical->sick20 == '0'): ?>
                                                                            ☑
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                            <?php else: ?>
                                                                            ☐
                                                                            <?php endif; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td>&nbsp;</td>
                                                                    <td>&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="1"
                                                            style="border-top : none;border-left : none;border-right : none;border-bottom : none;"
                                                            cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <table width="100%" border="0"
                                                                            style="font-size: 11px;" cellpadding="2"
                                                                            cellspacing="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td width="474" valign="top">
                                                                                        <b>&nbsp;&nbsp;Place a check
                                                                                            mark (✔) in the appropriate
                                                                                            box
                                                                                            <span
                                                                                                style="font-size:15px;">☐</span></b>
                                                                                    </td>
                                                                                    <td colspan="2" align="center"
                                                                                        valign="top"><b>YES
                                                                                        </b><b>NO</b></td>
                                                                                    <td width="184" rowspan="10"
                                                                                        align="center" valign="top">
                                                                                        <p><b><br>
                                                                                                <span
                                                                                                    class="brdRightBtm"><?php if($admission->patient_image): ?>
                                                                                                    <img src="../../../app-assets/images/profiles/<?php echo e($admission->patient_image); ?>"
                                                                                                        alt="Patient Picture"
                                                                                                        width="153"
                                                                                                        height="154"
                                                                                                        class="brdAll">
                                                                                                    <?php else: ?>
                                                                                                    <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                                                                                        alt="Patient Picture"
                                                                                                        width="153"
                                                                                                        height="154"
                                                                                                        class="brdAll">
                                                                                                    <?php endif; ?>
                                                                                                </span></b>
                                                                                        </p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>1. Have you ever been signed off
                                                                                        as sick or repatriated from a
                                                                                        ship?</td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question1 == "Yes" || $exam_physical->question1 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question1 == "No" || $exam_physical->question1 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>2. Have you ever been
                                                                                        hospitalized?</td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question2 == "Yes" || $exam_physical->question2 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question2 == "No" || $exam_physical->question2 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>3. Have you ever been declared
                                                                                        unfit for sea duty?</td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question3 == "Yes" || $exam_physical->question3 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question3 == "No" || $exam_physical->question3 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>4. Has your medical certificate
                                                                                        ever been restricted or revoked?
                                                                                    </td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question4 == "Yes" || $exam_physical->question4 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question4 == "No" || $exam_physical->question4 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>5. Are you aware that you have
                                                                                        any medical problem,disease or
                                                                                        illness?</td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question5 == "Yes" || $exam_physical->question5 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question5 == "No" || $exam_physical->question5 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>6. Do you feel healthy and fit
                                                                                        to perform the duties of your
                                                                                        designated position/occupation?
                                                                                    </td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question6 == "Yes" || $exam_physical->question6 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question6 == "No" || $exam_physical->question6 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>7. Are you allergic to any
                                                                                        medication?</td>
                                                                                    <td colspan="2" align="center">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question7 == "Yes" || $exam_physical->question7 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question7 == "No" || $exam_physical->question7 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td colspan="3">&nbsp;Comments:<b>
                                                                                        </b></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>
                                                                                        <p>8. Are you taking any
                                                                                            non-prescription or
                                                                                            prescription medication?<br>
                                                                                            if <b>YES</b>, please list
                                                                                            the medication(s)
                                                                                            taken/being taken, and the
                                                                                            purpose(s) and dosage(s):
                                                                                            <br>
                                                                                            <span
                                                                                                style="border-bottom : 1px solid"><b>
                                                                                                </b></span>
                                                                                        </p>
                                                                                    </td>
                                                                                    <td colspan="2" align="center"
                                                                                        valign="top">
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question8 == "Yes" || $exam_physical->question8 == "1" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                        <span style="font-size:15px;">
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->question8 == "No" || $exam_physical->question8 == "0" ?  '☑' : '☐'); ?>

                                                                                            <?php else: ?>
                                                                                            ☐
                                                                                            <?php endif; ?>
                                                                                        </span>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td colspan="2" align="center" valign="top">
                                                                                        <textarea name="co" type="text" id="co" value="" class="brdNone" style="width:100%;height: 50px;text-align:left;border: none;"></textarea>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <table width="100%" border="0" cellspacing="0"
                                                                            cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>
                                                                                        <table width="100%" border="1"
                                                                                            style="border-left : none;border-right : none;"
                                                                                            cellspacing="0"
                                                                                            cellpadding="2">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td colspan="10"
                                                                                                        align="left"
                                                                                                        valign="top">
                                                                                                        <b>II. MEDICAL
                                                                                                            EXAMINATION
                                                                                                            <br>
                                                                                                            Enter the
                                                                                                            data called
                                                                                                            for. Place a
                                                                                                            checkmark
                                                                                                            (✔) in the
                                                                                                            appropriate
                                                                                                            box
                                                                                                            <span
                                                                                                                style="font-size:15px;">☐</span>
                                                                                                        </b>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td valign="top">
                                                                                                        HEIGHT(cm):<br>
                                                                                                        <b><?php echo e($exam_physical ? $exam_physical->height : null); ?></b>
                                                                                                    </td>
                                                                                                    <td colspan="2"
                                                                                                        valign="top">
                                                                                                        WEIGHT (kg):<br>
                                                                                                        <b><?php echo e($exam_physical ? $exam_physical->weight : null); ?></b>
                                                                                                    </td>
                                                                                                    <td colspan="2"
                                                                                                        align="left"
                                                                                                        valign="top">
                                                                                                        BLOOD
                                                                                                        PRESSURE:<br>
                                                                                                        Systolic:
                                                                                                        <b><u><?php echo e($exam_physical ? $exam_physical->systollic : null); ?></u></b>
                                                                                                        <br>
                                                                                                        Diastolic:<b><u><?php echo e($exam_physical ? $exam_physical->diastollic : null); ?></u></b>
                                                                                                    </td>
                                                                                                    <td colspan="2"
                                                                                                        valign="top">
                                                                                                        PULSE
                                                                                                        RATE:<b><br><u><?php echo e($exam_physical ? $exam_physical->pulse : null); ?></u></b>/min
                                                                                                        <br>
                                                                                                        Regular
                                                                                                        Rhythm:<b><u><?php echo e($exam_physical ? $exam_physical->rhythm : null); ?></u></b>
                                                                                                    </td>
                                                                                                    <td colspan="2"
                                                                                                        valign="top">
                                                                                                        RESPIRATION:<b><br>
                                                                                                            <u><?php echo e($exam_physical ? $exam_physical->respiration : null); ?></u>
                                                                                                        </b>/min</td>
                                                                                                    <td valign="top">BMI
                                                                                                        :<br>
                                                                                                        <b><?php echo e($exam_physical ? $exam_physical->bmi : null); ?></b>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td width="11%"
                                                                                                        align="center">
                                                                                                        VISUAL ACUITY
                                                                                                    </td>
                                                                                                    <td colspan="2"
                                                                                                        align="center">
                                                                                                        FAR VISION</td>
                                                                                                    <td colspan="2"
                                                                                                        align="center">
                                                                                                        NEAR VISION</td>
                                                                                                    <td width="12%"
                                                                                                        align="center">
                                                                                                        ISHIHARA COLOR
                                                                                                    </td>
                                                                                                    <td width="8%"
                                                                                                        align="center">
                                                                                                        EAR</td>
                                                                                                    <td colspan="2"
                                                                                                        align="center">
                                                                                                        Hearing by
                                                                                                        Audiometry</td>
                                                                                                    <td width="11%"
                                                                                                        align="center">
                                                                                                        Clarity of
                                                                                                        Speech</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td>Uncorrected</td>
                                                                                                    <td width="9%">OD
                                                                                                        <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->ufvod : null); ?>

                                                                                                        </b>
                                                                                                    </td>
                                                                                                    <td width="9%">OS
                                                                                                        <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->ufvos : null); ?>

                                                                                                        </b>
                                                                                                    </td>
                                                                                                    <td width="9%">ODJ
                                                                                                        <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->unvodj : null); ?>

                                                                                                        </b>
                                                                                                    </td>
                                                                                                    <td width="10%">OSJ
                                                                                                        <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->unvosj : null); ?>

                                                                                                        </b>
                                                                                                    </td>
                                                                                                    <td align="center"
                                                                                                        width="12%">
                                                                                                        Adequate
                                                                                                        <b>
                                                                                                            <span
                                                                                                                style="font-size:15px;">
                                                                                                                ☐
                                                                                                            </span>
                                                                                                        </b>
                                                                                                    </td>
                                                                                                    <td align="center">
                                                                                                        Right</td>
                                                                                                    <td width="10%"><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled>
                                                                                                        </b> Adequate
                                                                                                    </td>
                                                                                                    <td width="11%"><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled="">
                                                                                                        </b> Inadequate
                                                                                                    </td>
                                                                                                    <td align="left"><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled="">
                                                                                                        </b> Adequate
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td width="11%">
                                                                                                        Corrected</td>
                                                                                                    <td>OD <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->cfvod : null); ?>

                                                                                                        </b></td>
                                                                                                    <td>OS <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->cfvod : null); ?>

                                                                                                        </b></td>
                                                                                                    <td>ODJ <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->cnvodj : null); ?>

                                                                                                        </b></td>
                                                                                                    <td>OSJ <b>
                                                                                                            <?php echo e($exam_visacuity ? $exam_visacuity->cnvosj : null); ?>

                                                                                                        </b></td>
                                                                                                    <td align="center">
                                                                                                        Defective<b>
                                                                                                            <span
                                                                                                                style="font-size:15px;">☐</span></b>
                                                                                                    </td>
                                                                                                    <td align="center">
                                                                                                        Left</td>
                                                                                                    <td><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled="">
                                                                                                        </b>Adequate
                                                                                                    </td>
                                                                                                    <td><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled="">
                                                                                                        </b> Inadequate
                                                                                                    </td>
                                                                                                    <td align="left"><b>
                                                                                                            <input
                                                                                                                name="b1"
                                                                                                                type="checkbox"
                                                                                                                id="a1"
                                                                                                                value="Yes"
                                                                                                                disabled="">
                                                                                                        </b>Defective
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <table width="100%" border="1" cellpadding="0" cellspacing="00">
                            <tbody>
                                <tr>
                                    <td>
                                        <table width="100%" border="1" style="border-left : none;border-right : none;"
                                            cellspacing="0" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td colspan="9"><b>II.MEDICAL EXAMINATION(Continuation). Alongside
                                                            columns A,B,C put check mark(✔) under "YES" if Normal. If
                                                            not Normal, specify findings</b></td>
                                                </tr>
                                                <tr>
                                                    <td width="15%" align="center"><b>A</b></td>
                                                    <td width="4%" align="center"><b>YES</b></td>
                                                    <td width="16%" align="center"><b>Significant Findings</b></td>
                                                    <td width="14%" align="center"><b>B</b></td>
                                                    <td width="4%" align="center"><b>YES</b></td>
                                                    <td width="15%" align="center"><b>Significant Findings</b></td>
                                                    <td width="13%" align="center"><b>C</b></td>
                                                    <td width="3%" align="center"><b>YES</b></td>
                                                    <td width="16%" align="center"><b>Significant Findings</b></td>
                                                </tr>
                                                <tr>
                                                    <td>Skin</td>
                                                    <td align="center"><b>
                                                            <input name="a1" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a1 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a1_findings ? $exam_physical->a1_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Neck,Lymph Nodes,Thyroid</td>
                                                    <td align="center"><b>
                                                            <input name="b1" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b1 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b1_findings ? $exam_physical->b1_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Genito-urinary System</td>
                                                    <td align="center"><b>
                                                            <input name="c1" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->c1_findings ? $exam_physical->c1_findings : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a1_findings ? $exam_physical->a1_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td>Head, neck, scalp</td>
                                                    <td align="center"><b>
                                                            <input name="a2" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a2 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a2_findings ? $exam_physical->a2_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Chest-Breast-Axilla</td>
                                                    <td align="center"><b>
                                                            <input name="b2" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b2 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                        </b></td>
                                                    <td>Inguinals, Genitals</td>
                                                    <td align="center"><b>
                                                            <input name="c2" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->c2 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->c2_findings ? $exam_physical->c2_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td>Eyes, external</td>
                                                    <td align="center"><b>
                                                            <input name="a3" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a3 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a3_findings ? $exam_physical->a3_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Lungs</td>
                                                    <td align="center"><b>
                                                            <input name="b3" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b3 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b3_findings ? $exam_physical->b3_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Extremities</td>
                                                    <td align="center"><b>
                                                            <input name="c3" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->c3 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->c3_findings ? $exam_physical->c3_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td>Pupils,Opthalmoscopic</td>
                                                    <td align="center"><b>
                                                            <input name="a4" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a4 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a4_findings ? $exam_physical->a4_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Heart</td>
                                                    <td align="center"><b>
                                                            <input name="b4" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b4 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b4_findings ? $exam_physical->b4_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Reflexes</td>
                                                    <td align="center"><b>
                                                            <input name="c4" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->c4 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->c4_findings ? $exam_physical->c4_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td>Ears</td>
                                                    <td align="center"><b>
                                                            <input name="a5" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a5 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a5_findings ? $exam_physical->a5_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Abdomen</td>
                                                    <td align="center"><b>
                                                            <input name="b5" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b5 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b5_findings ? $exam_physical->b5_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Dental(Teeth/Gums)</td>
                                                    <td align="center"><b>
                                                            <input name="c5" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->c5 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->c5_findings ? $exam_physical->c5_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td>Noses, Sinuses</td>
                                                    <td align="center"><b>
                                                            <input name="a6" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a6 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a6_findings ? $exam_physical->a6_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Back</td>
                                                    <td align="center"><b>
                                                            <input name="b6" type="checkbox" id="a2" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b6 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b6_findings ? $exam_physical->b6_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>&nbsp;</td>
                                                    <td align="center">&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td>Mouth, Throat</td>
                                                    <td align="center"><b>
                                                            <input name="a7" type="checkbox" id="a7" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->a7 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->a7_findings ? $exam_physical->a7_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>Anus-rectum</td>
                                                    <td align="center"><b>
                                                            <input name="b7" type="checkbox" id="b7" value="Yes"
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->b7 == "Yes" ? 'checked' : null); ?>

                                                                <?php endif; ?> disabled="">
                                                        </b></td>
                                                    <td align="center"><b>
                                                            <?php if($exam_physical): ?>
                                                            <?php echo e($exam_physical->b7_findings ? $exam_physical->b7_findings : null); ?>

                                                            <?php endif; ?>
                                                        </b></td>
                                                    <td>&nbsp;</td>
                                                    <td align="center">&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="1"
                                            style="border-top : none;border-left : none;border-right : none;"
                                            cellspacing="0" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td colspan="6"><b>III.RESULTS OF ANCILLARY EXAMINATION. Place a
                                                            check mark (✔) in the appropriate box
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="">
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td width="12%">A. CHEST X-RAY:</td>
                                                    <td width="20%"><b>
                                                            <input name="xray" type="checkbox" xray="xray"
                                                                value="Normal Chest" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->chest == "normal" || $exam_physical->chest == "Non-Significant" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Normal<b>
                                                            <input name="xray" type="checkbox" xray="xray"
                                                                value="Significant Findings" disabled=""
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->chest == "findings" || $exam_physical->chest == "Significant Findings" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>With Findings</td>
                                                    <td width="13%">D. URINALYSIS :</td>
                                                    <td width="21%" valign="top"><b>
                                                            <input name="urine" type="checkbox" id="urine"
                                                                value="Normal" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->urinalysis == "normal" || $exam_physical->urinalysis == "Non-Significant" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Normal<b>
                                                            <input name="urine" type="checkbox" id="urine"
                                                                value="With Findings" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->urinalysis == "findings" || $exam_physical->urinalysis == "Significant Findings" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>With Findings</td>
                                                    <td width="13%">G. HIV/AIDS Test :</td>
                                                    <td width="21%"><b>
                                                            <input name="hiv" type="checkbox" id="hiv" value="Reactive"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hiv == "Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Reactive<b>
                                                            <input name="hiv" type="checkbox" id="hiv"
                                                                value="Non-Reactive" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hiv == "Non Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b> Non-Reactive </td>
                                                </tr>
                                                <tr>
                                                    <td>B. ECG :</td>
                                                    <td><b>
                                                            <input name="ecg" type="checkbox" id="ecg" value="Normal"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->ecg == "normal" || $exam_physical->ecg == "Non-Significant" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Normal<b>
                                                            <input name="ecg" type="checkbox" id="ecg"
                                                                value="Significant Findings" disabled=""
                                                                <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->ecg == "findings" || $exam_physical->ecg == "Significant Findings" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>With Findings</td>
                                                    <td> E. STOOL EXAM : <br></td>
                                                    <td valign="top"><b>
                                                            <input name="stool" type="checkbox" id="stool"
                                                                value="Normal" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->stool == "normal" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Normal<b>
                                                            <input name="stool" type="checkbox" id="stool"
                                                                value="With Findings" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->stool == "findings" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>With Findings</td>
                                                    <td>H. RPR :</td>
                                                    <td><b>
                                                            <input name="sero" type="checkbox" id="sero"
                                                                value="Reactive" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->rph == "Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Reactive<b>
                                                            <input name="sero" type="checkbox" id="sero"
                                                                value="Non-Reactive" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->rph == "Non Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Non-Reactive</td>
                                                </tr>
                                                <tr>
                                                    <td>C. CBC :</td>
                                                    <td><b>
                                                            <input name="cbc" type="checkbox" id="cbc" value="Normal"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hiv == "normal" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Normal<b>
                                                            <input name="cbc" type="checkbox" id="cbc"
                                                                value="With Findings" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hiv == "findings" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>With Findings</td>
                                                    <td>F. Hepatitis B :</td>
                                                    <td valign="top"><b>
                                                            <input name="hepa" type="checkbox" id="a2" value="Reactive"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hepa_b == "Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Reactive <b>
                                                            <input name="hepa" type="checkbox" id="a2"
                                                                value="Non-Reactive" disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->hepa_b == "Non Reactive" ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>Non-Reactive</td>
                                                    <td colspan="2">I. BLOOD TYPE(Specify) :<b>
                                                        </b><?php if($exam_physical): ?>
                                                        <?php echo e($exam_physical->blood_type ? $exam_physical->blood_type : null); ?>

                                                        <?php endif; ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellspacing="0" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td><b>IV. Summary. Place a check mark(✔) in the appropriate box
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="">
                                                        </b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="1" cellspacing="0"
                                            style="border-left : none;border-right : none;" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td width="32%">Basic DOH Mandatory Medical Examination :</td>
                                                    <td><b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_medexam == 'passed' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b> PASSED <b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_medexam == 'findings' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>WITH SIGNIFICANT FINDINGS</td>
                                                </tr>
                                                <tr>
                                                    <td>Additional Laboratory Test :</td>
                                                    <td><b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_labtest == 'passed' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>PASSED<b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_labtest == 'findings' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>WITH SIGNIFICANT FINDINGS</td>
                                                </tr>
                                                <tr>
                                                    <td>Flag/Host Medical and Laboratory Requirements</td>
                                                    <td><b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_labrequirements == 'passed' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>PASSED<b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->summary_labrequirements == 'findings' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b>WITH SIGNIFICANT FINDINGS</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2"><b>REMARKS/SPECIAL NEEDS SPECIFY</b>(Specify e.g.
                                                        with medication,diet restriction etc.)<br>
                                                        <?php if($exam_physical): ?>
                                                        <?php echo e($exam_physical->remarks ? $exam_physical->remarks : null); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellspacing="0" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td colspan="4">V.ASSESSMENT OF FITNESS FOR SERVICE AT SEA. Place a
                                                        check mark (✔) in the appropriate box<b>
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="">
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">On the basis of the examinee's personal declaration,
                                                        my clinic examination and the diagnostic test results recorded
                                                        above, I declare the examinee medically:</td>
                                                </tr>
                                                <tr>
                                                    <td width="12%">&nbsp;</td>
                                                    <td width="33%" align="left"><b>FIT FOR LOOK OUT DUTY
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->duty == 'Fit' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b></td>
                                                    <td width="28%" align="center"><b>NOT FIT FOR LOOK OUT DUTY
                                                            <input name="a" type="checkbox" id="a2" value="Yes"
                                                                disabled="" <?php if($exam_physical): ?>
                                                                <?php echo e($exam_physical->duty == 'Unfit' ? 'checked' : null); ?>

                                                                <?php endif; ?>>
                                                        </b></td>
                                                    <td width="27%">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellspacing="0" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td width="12%">&nbsp;</td>
                                                    <td width="18%"><b>DECK SERVICE</b></td>
                                                    <td width="22%"><b>ENGINE SERVICE</b></td>
                                                    <td width="19%"><b>CATERING SERVICE</b></td>
                                                    <td width="29%"><b>OTHER SERVICE</b></td>
                                                </tr>
                                                <tr>
                                                    <td><b>FIT</b></td>
                                                    <td><b>
                                                            <input name="deck_fit" type="checkbox" id="a2" value="fit"
                                                                disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="engine_fit" type="checkbox" id="a2" value="fit"
                                                                disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="catering_fit" type="checkbox" id="a2"
                                                                value="fit" disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="other_fit" type="checkbox" id="a2" value="fit"
                                                                disabled="">
                                                        </b></td>
                                                </tr>
                                                <tr>
                                                    <td><b>UNFIT</b></td>
                                                    <td><b>
                                                            <input name="deck_fit" type="checkbox" id="a2" value="unfit"
                                                                disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="engine_fit" type="checkbox" id="a2"
                                                                value="unfit" disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="catering_fit" type="checkbox" id="a2"
                                                                value="unfit" disabled="">
                                                        </b></td>
                                                    <td><b>
                                                            <input name="other_fit" type="checkbox" id="a2"
                                                                value="unfit" disabled="">
                                                        </b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="1" style="border-left : none;border-right : none;"
                                            cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="19%" height="29">WITH RESTRICTIONS: <b>
                                                                            <input name="a" type="checkbox" id="a2"
                                                                                value="Yes" disabled=""
                                                                                <?php if($exam_physical): ?>
                                                                                <?php echo e($exam_physical->restriction == 'with restriction' ? 'checked' : null); ?>

                                                                                <?php endif; ?>>
                                                                        </b></td>
                                                                    <td width="30%">WITHOUT RESTRICTIONS: <b>
                                                                            <input name="a" type="checkbox" id="a3"
                                                                                value="Yes" disabled=""
                                                                                <?php if($exam_physical): ?>
                                                                                <?php echo e($exam_physical->restriction == 'without restriction' ? 'checked' : null); ?>

                                                                                <?php endif; ?>>
                                                                        </b></td>
                                                                    <td width="18%">VISUAL AIDS REQUIRED:</td>
                                                                    <td width="15%" valign="top">Spectacles<b>
                                                                            <input name="a2" type="checkbox" id="a11"
                                                                                value="Yes" disabled=""
                                                                                <?php if($exam_physical): ?>
                                                                                <?php echo e(preg_match('/Spectacles/i', $exam_physical->visual_required) ? 'checked' : null); ?>

                                                                                <?php endif; ?>>
                                                                        </b></td>
                                                                    <td width="18%" valign="top">Contact Lenses<b>
                                                                            <input name="a" type="checkbox" id="a2"
                                                                                value="Yes" disabled=""
                                                                                <?php if($exam_physical): ?>
                                                                                <?php echo e(preg_match("/Contact Lenses/i", $exam_physical->visual_required) ? 'checked' : null); ?>

                                                                                <?php endif; ?>>
                                                                        </b></td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">Describe restriction**(refer to
                                                                        standard restrictions at the bottom of this
                                                                        page)
                                                                    </td>
                                                                    <td>&nbsp;</td>
                                                                    <td colspan="2">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3" style="border-bottom : 1px solid">
                                                                        <b>
                                                                            <?php if($exam_physical): ?>
                                                                            <?php echo e($exam_physical->describe_restriction); ?>

                                                                            <?php endif; ?>
                                                                        </b>
                                                                    </td>
                                                                    <td colspan="2">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3" style="border-bottom : 1px solid">

                                                                    </td>
                                                                    <td colspan="2">&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="1"
                                            style="border-top : none;border-left : none;border-right : none;"
                                            cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="5">
                                                            <tbody>
                                                                <tr>
                                                                    <td>Date of Medical Examination</td>
                                                                    <td width="36%">Date Expire of Medical Examination
                                                                        Report</td>
                                                                    <td>Medical Examination Report No.</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>(DD/MM/YY):<b>
                                                                            <?php if($exam_physical): ?>
                                                                            <?php echo e($exam_physical->date_examination); ?>

                                                                            <?php endif; ?>
                                                                        </b></td>
                                                                    <td>(DD/MM/YY):<b>
                                                                            <?php if($exam_physical): ?>
                                                                            <?php echo e($exam_physical->date_expiration); ?>

                                                                            <?php endif; ?>
                                                                        </b></td>
                                                                    <td><b>
                                                                            <?php if($exam_physical): ?>
                                                                            <?php echo e($exam_physical->examination_number); ?>

                                                                            <?php endif; ?>
                                                                        </b></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" borded="1" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="3">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="3">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="47%"><b>NAME AND SIGNATURE OF
                                                                            EXAMINING/AUTHORIZED PHYSICIAN:</b></td>
                                                                    <td width="42%" style="border-bottom : 1px solid">
                                                                        <b>
                                                                            <?php if($exam_physical): ?>
                                                                            <?php echo e($exam_physical->tech1_firstname . " " . $exam_physical->tech1_middlename . " " . $exam_physical->tech1_lastname); ?>

                                                                            <?php endif; ?>
                                                                        </b>
                                                                    </td>
                                                                    <td width="11%">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3">
                                                                        <table width="100%" border="0" cellspacing="0"
                                                                            cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td width="15%"><b>LICENSE NUMBER
                                                                                            :</b></td>
                                                                                    <td width="25%"
                                                                                        style="border-bottom : 1px solid">
                                                                                        <b>
                                                                                            <?php if($exam_physical): ?>
                                                                                            <?php echo e($exam_physical->license_no); ?>

                                                                                            <?php endif; ?>
                                                                                        </b>
                                                                                    </td>
                                                                                    <td width="60%">&nbsp;</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3">
                                                                        <table width="100%" border="0" cellspacing="0"
                                                                            cellpadding="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td width="10%"><b>ADDRESS: </b>
                                                                                    </td>
                                                                                    <td width="39%"
                                                                                        style="border-bottom : 1px solid">
                                                                                        <b>
                                                                                        </b>
                                                                                    </td>
                                                                                    <td width="51%">&nbsp;</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3">&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="1" cellpadding="5"
                                            style="border-left : none;border-right : none;border-bottom : none"
                                            cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td colspan="3" align="left">
                                                        <p>I hereby certify that the personal declaration above is true
                                                            to the best of my knowlegde and I fully understand the above
                                                            results of my medical examination as explained to me by the
                                                            examining/authorized physician.</p>
                                                        <p>I hereby authorized the release of all my medical records to
                                                            the DOH/MARINA/POEA, the examining/authorized physician and
                                                            my employer/manning agency </p>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="1%" align="right">(</td>
                                                                    <td width="34%" align="center"
                                                                        style="border-bottom : 1px solid"><b>
                                                                        </b></td>
                                                                    <td width="65%">)</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table width="100%" border="0" cellpadding="2" cellspacing="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="4" align="center">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="395" align="center"
                                                                        style="border-bottom: 1px black solid">
                                                                        <?php echo e($admission->lastname . ", " . $admission->firstname); ?>

                                                                    </td>
                                                                    <td width="85" align="center">&nbsp;</td>
                                                                    <td width="182" align="center"
                                                                        style="border-bottom: 1px black solid">
                                                                        <?php if($exam_physical): ?>
                                                                        <?php echo e($exam_physical->trans_date); ?>

                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td width="86" align="center">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center" valign="top"><b>NAME AND
                                                                            SIGNATURE OF SEAFARER</b> <br style="">

                                                                        <span
                                                                            style="font-size: 7px;font-color:solid"><b>THIS
                                                                                SIGNATURE SHOULD BE AFFIXED IN THE
                                                                                PRESENCE OF THE EXAMINING PHYSICIAN
                                                                            </b></span>
                                                                    </td>
                                                                    <td align="center">&nbsp;</td>
                                                                    <td align="center" valign="top"><b>DATE</b></td>
                                                                    <td align="center">&nbsp;</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <table width="800" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td width="54%" valign="top"><b>**STANDARD RESTRICTION(Duties) :</b>
                                        <ul>
                                            <li>No solo watchkeeping</li>
                                            <li>Not fit for emergency duties</li>
                                            <li>Not fit for lookout duties</li>
                                            <li>Only fit for lookout during daylight hours</li>
                                            <li>Not fit for work with colour coded tables etc.</li>
                                            <li>Not to be away from (home) port overnight</li>
                                            <li>Not to be away from (home) port for periods over 24 hours/7days</li>
                                            <li>Not to lift items weighing over 5/10/20/40kg</li>
                                            <li>Protective gloves to be worn for work with .......(specify)</li>
                                            <li>Eye protection to be worn to all work</li>
                                        </ul>
                                    </td>
                                    <td valign="top">
                                        <p>&nbsp;</p>
                                        <ul>
                                            <li>Not to work ...........(specify)</li>
                                            <li>Not fit for food handling</li>
                                            <li>Within.......(specify) miles from a safe haven</li>
                                            <li>Near - coastal only</li>
                                            <li>Coastal waters only,up to....(specify) miles from shore</li>
                                            <li>Non - tropical waters only</li>
                                            <li>Not fit for service on stand-by vessels</li>
                                            <li>Fit for service only on vessels with ship's doctor</li>
                                            <li>Toilet/washing facilities in private cabin required</li>
                                            <li>Special needs.....in emergencies(specify)</li>
                                        </ul>
                                        <p>&nbsp;</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </center>

</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintPanel/mer.blade.php ENDPATH**/ ?>