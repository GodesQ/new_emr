

<?php $__env->startSection('content'); ?>
<style>
    .form-control {
        padding: 0.2rem;
    }
    
    .table th,
    .table td {
        padding: 0.5rem;
    }
</style>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Drug</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_drug" role="form">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            let toaster = toastr.success(
                                '<?php echo e(Session::get("status")); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td align="right"><b>Report No.</b></td>
                                        <td><input name="reportno" id="reportno" type="text"
                                                value="<?php echo e($exam->reportno); ?>" class="form-control"></td>
                                        <td align="right">&nbsp;</td>
                                        <td align="right">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="19%" align="right"><b>Purpose</b></td>
                                        <td width="31%">
                                            <select type="menu" name="purpose" id="purpose" class="form-control">
                                                <option value="" <?php echo $exam->purpose == "" ? "selected=''" : ""
                                                    ?>>--SELECT--</option>
                                                <option value="Not Required" <?php echo $exam->purpose == "Not Required"
                                                    ? "selected=''" : "" ?>>Not Required</option>
                                                <option value="Pre-Employement" <?php echo $exam->purpose ==
                                                    "Pre-Employement" ? "selected=''" : "" ?>>Pre-Employement
                                                </option>
                                                <option value="Student" <?php echo $exam->purpose == "Student" ?
                                                    "selected=''" : "" ?>>Student</option>
                                                <option value="Licensing" <?php echo $exam->purpose == "Licensing" ?
                                                    "selected=''" : "" ?>>Licensing</option>
                                                <option value="Random Drug Testing" <?php echo $exam->purpose == "Random
                                                    Drug Testing" ? "selected=''" : "" ?>>Random Drug Testing
                                                </option>
                                                <option value="Others" <?php echo $exam->purpose == "Others" ?
                                                    "selected=''" : "" ?>>Others</option>
                                            </select>
                                        </td>
                                        <td width="18%" align="right"><b>Method</b></td>
                                        <td width="32%" align="right">
                                            <select type="menu" name="method" id="method" class="form-control">
                                                <option value="" <?php echo $exam->method == "" ? "selected=''" : ""
                                                    ?>>--SELECT--</option>
                                                <option value="Not Required" <?php echo $exam->method == "Not Required" ?
                                                    "selected=''" : "" ?>>Not Required</option>
                                                <option value="Instrumented" <?php echo $exam->method == "Instrumented" ?
                                                    "selected=''" : "" ?>>Instrumented</option>
                                                <option value="Test Kit" <?php echo $exam->method == "Test Kit" ?
                                                    "selected=''" : "" ?>>Test Kit</option>
                                                <option value="Random Drug Test" <?php echo $exam->method == "Random Drug
                                                    Test" ? "selected=''" : "" ?>>Random Drug Test</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right">&nbsp;</td>
                                        <td align="right">&nbsp;</td>
                                        <td align="right">&nbsp;</td>
                                        <td align="right">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right"><b>Methamphetamine</b></td>
                                        <td>
                                            <input name="methamphetamine" type="radio" style="width: 20px; height: 20px;" class="m-75" <?php echo
                                                $exam->methamphetamine == "Negative" ? "checked" : "" ?>
                                            id="methamphetamine_0" value="Negative">
                                            Negative
                                            <input name="methamphetamine" type="radio" style="width: 20px; height: 20px;" class="m-75" <?php echo
                                                $exam->methamphetamine == "Positive" ? "checked" : "" ?>
                                            id="methamphetamine_1" value="Positive">
                                            Positive
                                            <input name="methamphetamine" type="radio" style="width: 20px; height: 20px;" class="m-75" <?php echo
                                                $exam->methamphetamine == "" ? "checked" : "" ?>
                                            id="methamphetamine_1" value="">
                                            Reset
                                        </td>
                                        <td align="right"><b>Barbiturates</b></td>
                                        <td>
                                            <input name="barbiturates" type="radio" style="width: 20px; height: 20px;" class="m-75" id="barbiturates_0"
                                                value="Negative" <?php echo $exam->barbiturates == "Negative" ? "checked"
                                            : "" ?>>
                                            Negative
                                            <input name="barbiturates" type="radio" style="width: 20px; height: 20px;" class="m-75" id="barbiturates_1"
                                                value="Positive" <?php echo $exam->barbiturates == "Positive" ? "checked"
                                            : "" ?>>
                                            Positive
                                            <input name="barbiturates" type="radio" style="width: 20px; height: 20px;" class="m-75" id="barbiturates_1"
                                                value="" <?php echo $exam->barbiturates == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right"><b>Tetrahydrocannabinol</b></td>
                                        <td><input name="tetrahydrocannabinol" type="radio" style="width: 20px; height: 20px;" class="m-75"
                                                id="tetrahydrocannabinol_0" value="Negative" <?php echo
                                                $exam->tetrahydrocannabinol == "Negative" ? "checked" : "" ?>>
                                            Negative
                                            <input name="tetrahydrocannabinol" type="radio" style="width: 20px; height: 20px;" class="m-75"
                                                id="tetrahydrocannabinol_1" value="Positive" <?php echo
                                                $exam->tetrahydrocannabinol == "Positive" ? "checked" : "" ?>>
                                            Positive
                                            <input name="tetrahydrocannabinol" type="radio" style="width: 20px; height: 20px;" class="m-75"
                                                id="tetrahydrocannabinol_1" value="" <?php echo
                                                $exam->tetrahydrocannabinol == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                        <td align="right"><b>Ecstacy(MDMA)</b></td>
                                        <td>
                                            <input name="ecstacy" type="radio" style="width: 20px; height: 20px;" class="m-75" id="ecstacy_0"
                                                value="Negative" <?php echo $exam->ecstacy == "Negative" ? "checked" : ""
                                            ?>>
                                            Negative
                                            <input name="ecstacy" type="radio" style="width: 20px; height: 20px;" class="m-75" id="ecstacy_1"
                                                value="Positive" <?php echo $exam->ecstacy == "Positive" ? "checked" : ""
                                            ?>>
                                            Positive
                                            <input name="ecstacy" type="radio" style="width: 20px; height: 20px;" class="m-75" id="ecstacy_1" value="" <?php
                                                echo $exam->ecstacy == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right"><b>Morphine</b></td>
                                        <td>
                                            <input name="morphine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="morphine_0"
                                                value="Negative" <?php echo $exam->morphine == "Negative" ? "checked" :
                                            "" ?>>
                                            Negative
                                            <input name="morphine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="morphine_1"
                                                value="Positive" <?php echo $exam->morphine == "Positive" ? "checked" :
                                            "" ?>>
                                            Positive
                                            <input name="morphine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="morphine_1" value=""
                                                <blade
                                                php|%20echo%20%24exam-%3Emorphine%20%3D%3D%20%26%2334%3B%26%2334%3B%20%3F%20%26%2334%3Bchecked%26%2334%3B%20%3A%20%26%2334%3B%26%2334%3B%20%40endphp%3E%0D>
                                            Reset
                                        </td>
                                        <td width="18%" colspan="-2" align="right"><b> Benzodiazepine </b></td>
                                        <td width="32%" colspan="-2">
                                            <input name="benzodiazepine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="benzodiazepine_0"
                                                value="Negative" <?php echo $exam->benzodiazepine == "Negative" ?
                                            "checked" : "" ?>>
                                            Negative
                                            <input name="benzodiazepine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="benzodiazepine_1"
                                                value="Positive" <?php echo $exam->benzodiazepine == "Positive" ?
                                            "checked" : "" ?>>
                                            Positive
                                            <input name="benzodiazepine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="benzodiazepine_1"
                                                value="" <?php echo $exam->benzodiazepine == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right"><b>Cocaine</b></td>
                                        <td>
                                            <input name="cocaine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="cocaine_0"
                                                value="Negative" <?php echo $exam->cocaine == "Negative" ? "checked" : ""
                                            ?>>
                                            Negative
                                            <input name="cocaine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="cocaine_1"
                                                value="Positive" <?php echo $exam->cocaine == "Positive" ? "checked" : ""
                                            ?>>
                                            Positive
                                            <input name="cocaine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="cocaine_1" value="" <?php
                                                echo $exam->cocaine == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                        <td align="right"><b>Opiates</b></td>
                                        <td>
                                            <input name="opiapes" type="radio" style="width: 20px; height: 20px;" class="m-75" id="opiapes_0"
                                                value="Negative" <?php echo $exam->opiapes == "Negative" ? "checked" : ""
                                            ?>>
                                            Negative
                                            <input name="opiapes" type="radio" style="width: 20px; height: 20px;" class="m-75" id="opiapes_1"
                                                value="Positive" <?php echo $exam->opiapes == "Positive" ? "checked" : ""
                                            ?>>
                                            Positive
                                            <input name="opiapes" type="radio" style="width: 20px; height: 20px;" class="m-75" id="opiapes_1" value="" <?php
                                                echo $exam->opiapes == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="-2" align="right"><b> Phencyclidine</b></td>
                                        <td colspan="-2">
                                            <input name="phencyclidine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="phencyclidine_0"
                                                value="Negative" <?php echo $exam->phencyclidine == "Negative" ?
                                            "checked" : "" ?>>
                                            Negative
                                            <input name="phencyclidine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="phencyclidine_1"
                                                value="Positive" <?php echo $exam->phencyclidine == "Positive" ?
                                            "checked" : "" ?>>
                                            Positive
                                            <input name="phencyclidine" type="radio" style="width: 20px; height: 20px;" class="m-75" id="phencyclidine_1"
                                                value="" <?php echo $exam->phencyclidine == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                        <td width="18%" colspan="-2" align="right"><b>Methadone</b></td>
                                        <td width="32%" colspan="-2">
                                            <input name="methadone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="methadone_0"
                                                value="Negative" <?php echo $exam->methadone == "Negative" ? "checked" :
                                            "" ?>>
                                            Negative
                                            <input name="methadone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="methadone_1"
                                                value="Positive" <?php echo $exam->methadone == "Positive" ? "checked" :
                                            "" ?>>
                                            Positive
                                            <input name="methadone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="methadone_1" value=""<?php echo $exam->methadone == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right"><b>Alcohol</b></td>
                                        <td><input name="alcohol" type="radio" style="width: 20px; height: 20px;" class="m-75" id="alcohol_0"
                                                value="Negative" <?php echo $exam->alcohol == "Negative" ? "checked" : ""
                                            ?>>
                                            Negative
                                            <input name="alcohol" type="radio" style="width: 20px; height: 20px;" class="m-75" id="alcohol_1"
                                                value="Positive" <?php echo $exam->alcohol == "Positive" ? "checked" : ""
                                            ?>>
                                            Positive
                                            <input name="alcohol" type="radio" style="width: 20px; height: 20px;" class="m-75" id="alcohol_1" value="" <?php
                                                echo $exam->alcohol == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                        <td width="18%" colspan="-2" align="right"><b> Metaqualone</b></td>
                                        <td width="32%" colspan="-2">
                                            <input name="metaqualone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="metaqualone_0"
                                                value="Negative" <?php echo $exam->metaqualone == "Negative" ? "checked"
                                            : "" ?>>
                                            Negative
                                            <input name="metaqualone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="metaqualone_1"
                                                value="Positive" <?php echo $exam->metaqualone == "Positive" ? "checked"
                                            : "" ?>>
                                            Positive
                                            <input name="metaqualone" type="radio" style="width: 20px; height: 20px;" class="m-75" id="metaqualone_1"
                                                value="" <?php echo $exam->metaqualone == "" ? "checked" : "" ?>>
                                            Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="right">&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td align="right"><b>Propoxyphene</b></td>
                                        <td>
                                            <input name="propoxyphene" type="radio" style="width: 20px; height: 20px;" class="m-75" id="propoxyphene_0"
                                                value="Negative" <?php echo $exam->propoxyphene == "Negative" ? "checked"
                                            : "" ?>>
                                            Negative
                                            <input name="propoxyphene" type="radio" style="width: 20px; height: 20px;" class="m-75" id="propoxyphene_1"
                                                value="Positive" <?php echo $exam->propoxyphene == "Positive" ? "checked"
                                            : "" ?>>
                                            Positive
                                            <input name="propoxyphene" type="radio" style="width: 20px; height: 20px;" class="m-75" id="propoxyphene_1"
                                                value="Positive" <?php echo $exam->propoxyphene == "" ? "checked" : ""
                                            ?>>
                                            Reset
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" style="width: 20px; height: 20px;" class="m-75"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" style="width: 20px; height: 20px;" class="m-75"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "14" ? 'selected' : null); ?>

                                                                        value="14">Rowena P. Bondoc, RMT</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "16" ? 'selected' : null); ?>

                                                                        value="16">Audrey Dianne G. Partosa, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "53" ? 'selected' : null); ?>

                                                                        value="53">Audrey Dianne F. Gonzales, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "55" ? 'selected' : null); ?>

                                                                        value="55">GRACE JOY C. PEÑARANDA, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "56" ? 'selected' : null); ?>

                                                                        value="56">MA. LOURDES C. VELEÑA, RMT
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "33" ? 'selected' : null); ?>

                                                                        value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Drug/edit-drug.blade.php ENDPATH**/ ?>