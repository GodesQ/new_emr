

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-body">
            <div class="card">
                <div class="card-body">
                    <div class="fc fc-ltr fc-unthemed" id="fc-default">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let csrf = '<?php echo e(csrf_token()); ?>';
$.ajax({
    url: '/month_scheduled_patients',
    method: 'GET',
    data: {
        _token: csrf
    },
    success: function(response) {
        console.log(response);
        var calendarEl = document.getElementById('fc-default');
        var fcCalendar = new FullCalendar.Calendar(calendarEl, {
            defaultDate: new Date(),
            editable: true,
            plugins: ["dayGrid", "interaction"],
            header: {
                left: 'title',
                center: '',
                right: ''
            },
            eventLimit: true, // allow "more" link when too many events
            events: response
        });

        fcCalendar.render();
    }
})
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/scheduled_patients.blade.php ENDPATH**/ ?>