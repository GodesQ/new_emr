<html>

<head>
    <title>MLC</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    body,
    table,
    tr,
    td {
        font-family: constantia;
        font-size: 10px;
    }

    .fontBoldLrg {
        font: bold 15px constantia;
    }

    .fontMed {
        font: bold 13px constantia;
    }

    div,
    ul li {
        font-size: 11px;
        font-weight: 400;
    }
    </style>
</head>

<body>
    <center>
        <table width="760" cellspacing="0" cellpadding="0" class="brdAll">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="10" class="brdAll">
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <span style="font-size: 20px; font-weight: 700;">MEDICAL EXAMINATION
                                            REPORT/CERTIFICATE</span><br>
                                        <span style="font-size: 17px; font-weight: 700;">MARITIME ADMINISTRATOR</span>
                                        <br>
                                        <span style="font-size: 14px; font-weight: 700; color: red;">CONFIDENTIAL
                                            DOCUMENT</span> <br>
                                        <span style="font-size: 17px; font-weight: 700;">REPUBLIC OF THE MARSHALL
                                            ISLANDS</span>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td width="50%">
                                        Surname <br>
                                        <span class="fontBoldLrg"><?php echo e($admission->lastname); ?></span>
                                    </td>
                                    <td width="50%">
                                        GIVEN NAME(S) <br>
                                        <span class="fontBoldLrg"><?php echo e($admission->firstname); ?></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="2">
                            <tbody>
                                <tr>
                                    <td>DATE OF BIRTH <br>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div>
                                                <span> </span> <br> MONTH
                                            </div>
                                            <div>
                                                <span> </span> <br> DAY
                                            </div>
                                            <div>
                                                <span></span> <br> YEAR
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        PLACE OF BIRTH <br>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div>
                                                <span> </span> <br> CITY
                                            </div>
                                            <div>
                                                <span> </span> <br> COUNTRY
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        SEX <br>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div>
                                                <span><img src="../../../app-assets/images/icoCheck.gif"
                                                        width="10"></span> MALE
                                            </div>
                                            <div>
                                                <span><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span> FEMALE
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>EXAMINATION FOR DUTY AS: <br>
                                        <div
                                            style="display: flex; align-items: center; justify-content: space-around; width: 100%;">
                                            <div style="width: 50%; text-align: center">MASTER</div>
                                            <div style="font-size: 15px; width: 50%;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></div>
                                        </div>
                                        <div
                                            style="display: flex; align-items: center; justify-content: space-around; width: 100%;">
                                            <div style="width: 50%; text-align: center;">DECK OFFICER</div>
                                            <div style="font-size: 15px; width: 50%;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></div>
                                        </div>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div style="width: 50%; text-align: center;">ENGINEERING OFFICER</div>
                                            <div style="font-size: 15px; width: 50%;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></div>
                                        </div>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div style="width: 50%; text-align: center;">RADIO OFFICER</div>
                                            <div style="font-size: 15px; width: 50%;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></div>
                                        </div>
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div style="width: 50%; text-align: center;">RATING</div>
                                            <div style="font-size: 15px; width: 50%;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></div>
                                        </div>
                                    </td>
                                    <td colspan="2" valign="top">
                                        MAILING ADDRESS OF APPLICANT: <br> <span>65 ABOGADO PANIQUI TARLAC</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">MEDICAL EXAMINATION (SEE REVERSE SIDE FOR MEDICAL REQUIREMENTS)
                                        STATE DETAILS ON REVERSE SIDE</td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td>
                                        HEIGHT <br> <span class="fontMed">172</span>
                                    </td>
                                    <td>
                                        WEIGHT <br> <span class="fontMed">172</span>
                                    </td>
                                    <td>
                                        BLOOD PRESSURE <br> <span class="fontMed">172</span>
                                    </td>
                                    <td>
                                        PULSE <br> <span class="fontMed">172</span>
                                    </td>
                                    <td>
                                        RESPIRATION <br> <span class="fontMed">172</span>
                                    </td>
                                    <td>
                                        GENERAL APPEARANCE <br> <span class="fontMed">172</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <div style="display: flex; align-items: center; justify-content: space-around;">
                                            <div style="width: 40%;">VISION:</div>
                                            <div style="width: 25%;">RIGHT EYE</div>
                                            <div style="width: 10%;"> </div>
                                            <div style="width: 25%;">LEFT EYE</div>
                                        </div>
                                        <div
                                            style="display: flex; align-items: flex-end; justify-content: space-around; margin: 1rem 0;">
                                            <div style="width: 40%;">WITHOUT GLASSES</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                20/25</div>
                                            <div style="width: 10%; text-align: center;">/</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                20/25</div>
                                        </div>
                                        <div
                                            style="display: flex; align-items: flex-end; justify-content: space-around;">
                                            <div style="width: 40%;">WITH GLASSES</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                20/25</div>
                                            <div style="width: 10%; text-align: center;">/</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                20/25</div>
                                        </div>
                                    </td>
                                    <td colspan="2" valign="top">
                                        HEARING: <br> <br>
                                        <div
                                            style="display: flex; align-items: flex-end; justify-content: space-around; height: 50px">
                                            <div>RT. EAR</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                NORMAL</div>
                                            <div>LEFT EAR</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                NORMAL</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <div
                                            style="display: flex; align-items: center; justify-content: space-between; width: 100%">
                                            <div>COLOR TEST TYPE:
                                                <span style="margin: 0 1rem;">BOOK
                                                    <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                                </span>
                                                <span style="margin: 0 1rem;">LANTERN
                                                    <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                                </span>
                                            </div>
                                            <div>COLOR TEST TYPE:
                                                <span style="margin: 0 1rem;">YES
                                                    <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                                </span>
                                                <span style="margin: 0 1rem;">NO
                                                    <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                                </span>
                                                <span> (If “No” explain on page 2)</span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <div>
                                            ARE GLASSES OR CONTACT LENSES NECESSARY TO MEET THE REQUIRED VISION
                                            STANDARD?
                                            <span style="margin: 0 1rem;">YES
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                            <span style="margin: 0 1rem;">NO
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        HEAD AND NECK <br> <span>NORMAL</span>
                                    </td>
                                    <td colspan="2">
                                        HEART (CARDIOVASCULAR) <br> ECG: <span>NORMAL</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        LUNGS <br> <span>NORMAL</span>
                                    </td>
                                    <td colspan="2">
                                        SPEECH (DECK/NAVIGATIONAL OFFICER AND RADIO OFFICER) <br>
                                        <span style="font-size: 9px;">IS SPEECH UNIMPAIRED FOR NORMAL VOICE
                                            COMMUNICATION?</span>
                                        <span>NORMAL</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        EXTREMITIES:: <br> <br>
                                        <div
                                            style="display: flex; align-items: flex-end; justify-content: space-around;">
                                            <div>UPPER</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                NORMAL</div>
                                            <div>LOWER</div>
                                            <div style="width: 25%; border-bottom: 1px solid black; font-size: 13px;">
                                                NORMAL</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <div>
                                            IS APPLICANT VACCINATED IN ACCORDANCE WITH WHO RECOMMENDATIONS?
                                            <span style="margin: 0 1rem;">YES
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                            <span style="margin: 0 1rem;">NO
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">IS APPLICANT SUFFERING FROM ANY DISEASE LIKELY TO BE AGGRAVATED BY
                                        WORKING ABOARD A VESSEL, OR TO RENDER HIM/HER UNFIT FOR SERVICE <br>
                                        AT SEA OR LIKELY TO ENDANGER THE HEALTH OF OTHER PERSONS ON BOARD?
                                        <span style="margin: 0 1rem;">YES
                                            <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                        </span>
                                        <span style="margin: 0 1rem;">NO
                                            <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                        </span> <br>
                                        IF YES, PLEASE ENTER EXPLANATION IN THE SECTION AT THE BOTTOM OF ON PAGE 2
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <div>
                                            IS APPLICANT TAKING ANY NON-PRESCRIPTION OR PRESCRIPTION MEDICATIONS?
                                            <span style="margin: 0 1rem;">YES
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                            <span style="margin: 0 1rem;">NO
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>29 MARCH 2022</td>
                                    <td></td>
                                    <td>28 MARCH 2024</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>SIGNATURE OF APPLICANT</td>
                                    <td></td>
                                    <td>DATE OF EXAMINATION</td>
                                    <td></td>
                                    <td>EXPIRY DATE</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td colspan="5">THIS SIGNATURE SHOULD BE AFFIXED IN THE PRESENCE OF THE EXAMINING
                                        PHYSICIAN.</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td colspan="3">THIS IS TO CERTIFY THAT A PHYSICAL EXAMINATION WAS GIVEN TO:</td>
                                    <td align="center" colspan="2">ADSUARA, ULYSSES VENTURA</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td colspan="3"></td>
                                    <td align="center" colspan="2">NAME OF APPLICANT</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td colspan="5">
                                        <div>
                                            IS APPLICANT TAKING ANY NON-PRESCRIPTION OR PRESCRIPTION MEDICATIONS?
                                            <span style="margin: 0 1rem;">YES
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                            <span style="margin: 0 1rem;">NO
                                                <span style="font-size: 15px;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span>
                                            </span>
                                        </div>
                                    </td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td colspan="5">
                                        <div>
                                            SEAFARER IS FOUND TO BE
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>FIT </span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>NOT FIT FOR
                                                DUTY AS A</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>MASTER
                                                /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>DECK OFFICER
                                                /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>ENGINEERING
                                                OFFICER /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>RADIO OFFICER
                                                /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>RATING
                                                /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>CHIEF COOK
                                                /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>COOK /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>WITHOUT ANY
                                                RESTRICTIONS /</span>
                                            <span style="font-size: 15px; margin: 0 0.5rem;"><img src="../../../app-assets/images/icoUncheck.gif"
                                                        width="10"></span><span>WITH THE
                                                FOLLOWING /</span> <br>
                                            <span style="font-size: 11px; margin: 0 0.5rem;">RESTRICTIONS: <span>
                                                </span></span>
                                        </div>
                                    </td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td>NAME AND DEGREE OF PHYSICIAN</td>
                                    <td>Teresita F. Gonzales M.D.</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>ADDRESS</td>
                                    <td>5th Floor JETTAC Bldg. 920 Pres. Quirino Ave. Cor. San Antonio St. Malate,
                                        Manila</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>NAME OF PHYSICIAN&#39;S CERTIFICATING</td>
                                    <td>Professional Regulation Commission</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>AUTHORITY <br> DATE OF ISSUE OF PHYSICIAN&#39;S CERTIFICATE</td>
                                    <td>14 June 1984</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" class="brdTable" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td>SIGNATURE OF PHYSICIAN</td>
                                    <td><img src="" alt="" width="60"></td>
                                    <td></td>
                                    <td align="center">29 MARCH 2022</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                    <td></td>
                                    <td align="center">DATE</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <div style="width: 760px; border: 1px solid black; margin-top: 100px; padding: 10px;">
            <h2 style="text-align: center;">MEDICAL REQUIREMENTS</h2>
            <p style="text-align: left; font-size: 11px; line-height: 15px;">All applicants for an officer certificate,
                Seafarer's Identification and Record Book or certification of special qualifications shall be required
                to have a medical examination reported on this Medical Form completed by a certificated physician. The
                completed medical form must accompany the application for officer’s certificate, application for
                Seafarer's Identification and Record Book, or application for certification of special qualifications.
                This medical examination must be carried out within the 24 months immediately preceding application for
                an officer certificate, certification of special qualifications or a Seafarer’s Identification and
                Record Book. The examination shall be conducted in accordance with RMI MG-7-47-1. Such proof of
                examination must establish that the applicant is in satisfactory physical and mental condition for the
                specific duty assignment undertaken and is generally in possession of all body faculties necessary in
                fulfilling the requirements of the seafaring profession.
                In conducting the examination, the certified physician should, where appropriate, examine the seafarer’s
                previous medical records (including vaccinations) and information on occupational history, noting any
                diseases, including alcohol or drug-related problems and/or injuries. In addition, the following minimum
                requirements shall apply:
            </p>
            <div style="text-align: left;">
                <div>(a) Hearing</div>
                <ul>
                    <li>All applicants must have hearing unimpaired for normal sounds and be
                        capable of hearing a whispered voice in better ear at 15 feet (4.57 m)
                        and in poorer ear at 5 feet (1.52 m).
                    </li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(b) Eyesight</div>
                <ul>
                    <li>Deck officer applicants must have (either with or without glasses) at least 20/20(1.00)
                        vision in one eye and at least 20/40 (0.50) in the other. Applicants for deck officer and deck
                        ratings who will serve on vessels of 500 gross tons or more must have normal color perception
                        that complies with C.I.E. Standard 1;
                        those serving on vessels less than 500 gross tons must comply with C.I.E. Standards 1 or 2.
                    </li>
                    <li>
                        Engineer and radio officer applicants must have (either with or without glasses) at least 20/30
                        (0.63) vision in one eye and at least 20/50 (0.40) in the other.
                        Applicants for engineering officer or rating and for radio operator must comply with C.I.E.
                        Standards 1, 2, or 3.
                        Engineer and radio officer applicants must also be able to perceive the colors red, yellow and
                        green.
                    </li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(c) Dental</div>
                <ul>
                    <li>Seafarers must be free from infections of the mouth cavity or gums.
                    </li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(d) Blood Pressure</div>
                <ul>
                    <li>An applicant&#39;s blood pressure must fall within an average range, taking age into
                        consideration.</li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(e) Voice</div>
                <ul>
                    <li>Deck/Navigational officer applicants and Radio officer applicants must have speech which is
                        unimpaired for normal voicecommunication.</li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(f) Vaccinations</div>
                <ul>
                    <li>All applicants should be vaccinated according to the recommendations provided in the WHO
                        publication, International
                        Travel and Health, Vaccination Requirements and Health Advice, and should be given advice by the
                        certified physician on
                        immunizations. If new vaccinations are given, these should be recorded.</li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(g) Diseases or Conditions</div>
                <ul>
                    <li>Applicants afflicted with any of the following diseases or conditions shall be disqualified:
                        epilepsy, insanity, senility,
                        alcoholism, tuberculosis, acute venereal disease or neurosyphilis, AIDS, and/or the use of
                        narcotics.</li>
                </ul>
            </div>
            <div style="text-align: left;">
                <div>(g) Physical Requirements</div>
                <ul>
                    <li>Applicants for able seafarer, bosun, GP-1, ordinary seafarer and junior ordinary seafarer must
                        meet the physical
                        requirements for a deck/navigational officer&#39;s certificate.
                    </li>
                    <li>
                        Applicants for fire/watertender, oiler/motor, pump technician, electrician, wiper, tanker rating
                        and survival craft/rescue
                        boat crewmember must meet the physical requirements for an engineer officer&#39;s certificate.
                    </li>
                </ul>
            </div>
        </div>
        <div style="width: 760px; border: 1px solid black; margin-top: 20px; padding: 10px;">
            <h2 style="text-align: center; ">IMPORTANT NOTE:</h2>
            <p style="text-align: left; ">A copy of the MI-105M must accompany the application. The applicant must
                retain the original of the MI-105M as evidence of physical qualification while serving on board a
                vessel.
                An applicant who has been refused a medical certificate or has had a limitation imposed on his/her
                ability to work, shall be given the opportunity to have an additional examination by another medical
                practitioner or medical referee who is independent of the shipowner or
                of any organization of shipowners or seafarers.
                Medical examination reports shall be marked as and remain confidential with the applicant having the
                right of a copy to his/her report. The medical examination report shall be used only for determining the
                fitness of the seafarer for work and enhancing health care.
            </p>
        </div>
        <div style="width: 760px; border: 1px solid black; margin-top: 20px; padding: 10px 20px;">
            <h2 style="text-align: center; ">DETAILS OF MEDICAL EXAMINATION</h2>
            <p style="text-align: left; ">(To be completed by examining physician; alternatively, the examining
                physician may attach a form similar or identical to the model
                provided in Appendix 1 of RMI MG-7-47-1).
            </p>
        </div>
    </center>
</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintPanel/marshall.blade.php ENDPATH**/ ?>