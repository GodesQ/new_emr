<!DOCTYPE html>
<html>

<head>
    <title>Referral Slip</title>
    <style>
    body,
    table,
    tr,
    td {
        font-family: sans-serif;
        font-size: 10px;
    }

    .fontBoldLrg {
        font: bold 15px sans-serif;
    }

    .fontMed {
        font: normal 12px sans-serif;
    }

    .text-below {
        word-spacing: 1rem;
        font-weight: 600;
        font-size: 0.8rem;
        margin-top: 1rem;
    }

    .box-container {
        padding: 0rem;
        width: 100%;
        margin-bottom: 1rem;
        border: 1px solid black;
        text-align: center;
    }

    .instruction {
        width: 100%;
    }

    .box {
        margin-left: 0.5rem;
        padding-left: 0.5rem;
        padding-right: 0.5rem;
        padding-bottom: 0.2rem;
        padding-top: 0.2rem;
        border: 1px solid black;
    }
    span, p, td, b {
        color: #476434;
    }
    @page
    </style>
</head>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table width="100%" celspacing="0" cellpadding="5">
    <tbody>
        <tr>
            <td><span style="font-weight: bold; font-size: 20px; font-family: serif; display: block; text-align: center;">REFERRAL SLIP FOR MEDICAL
                    EXAMINATION</span></td>
        </tr>
        <tr>
            <td><span style="display: block;margin-top: -10px;text-align: center;font-weight: 400;font-size: 12px;font-family: sans-serif;">Joint DOH-POEA-MARINA CONSULTATIVE
                    COMMITTEE</span></td>
        </tr>
    </tbody>
</table>
<table width="100%">
    <tbody>
        <tr width="100%">
            <td width="80%">
                <table width="100%" cellspacing="2" cellpadding="8">
                    <tbody>
                        <tr>
                            <td width="35%" style="font-size: 11px;">Name of Employer/Agency:</td>
                            <td width="100%">
                                <div style="border-bottom: 1px solid #476434; font-size: 11px;"><?php echo e($row->agencyname); ?></div>
                            </td>
                        </tr>
                        <tr>
                            <td width="28%" style="font-size: 11px;">Vessel:</td>
                            <td width="72%">
                                <div style="border-bottom: 1px solid #476434; font-size: 11px;"><?php echo e($row->vessel); ?></div>
                            </td>
                        </tr>
                        <tr>
                            <td width="28%" style="font-size: 11px;">Country of Destination:</td>
                            <td width="72%">
                                <div style="border-bottom: 1px solid #476434; font-size: 11px;"><?php echo e($row->country_destination); ?></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
            <td style="text-align: center; border: 1px solid #476434; width: 100px; height: 100px;">
                    <span>IMAGE HERE</span>
            </td>
        </tr>
    </tbody>
</table>
<table width="100%" celspacing="0" cellpadding="5" style="margin-top: 20px;">
    <tbody>
        <tr>
            <td width="33%">
                <div style="border-bottom: 1px solid #476434;  margin-bottom: 0.3rem; font-size: 11px;">
                    <?php echo e($row->lastname); ?>

                </div>
                <span style="font-size: 11px;" >Last Name</span>
            </td>
            <td width="33%">
                <div style="border-bottom: 1px solid #476434;  margin-bottom: 0.3rem; font-size: 11px;">
                    <?php echo e($row->firstname); ?>

                </div>
                <span style="font-size: 11px;" >First Name</span>
            </td>
            <td width="33%">
                <div style="border-bottom: 1px solid #476434;  margin-bottom: 0.3rem; font-size: 11px;">
                    <?php echo e($row->middlename); ?>

                </div>
                <span style="font-size: 11px;">Middle Name</span>
            </td>
        </tr>
    </tbody>
</table>
<table  width="100%" celspacing="0" cellpadding="5">
    <tbody>
        <tr>
            <td width="71%">
                <table style="margin-top: 10px;" width="100%">
                    <tbody>
                        <tr>
                            <td width="100%">
                                <div style="border-bottom: 1px solid #476434; margin-bottom: 1rem;"><?php echo e($row->address); ?>

                                </div>
                                <div style="text-align: center; font-size: 11px; display: block; margin-top: -10px;">Permanent Address
                                    (Street,
                                    Municipality)</div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="margin-top: 20px;" width="100%">
                    <tbody>
                        <tr>
                            <td width="50%">
                                <div style="border-bottom: 1px solid #476434;  margin-bottom: 0.3rem; font-size: 11px;">
                                    <?php echo e($row->age); ?>

                                </div>
                                <span style="font-size: 11px;" >Age</span>
                            </td>
                            <td width="50%">
                                <div style="border-bottom: 1px solid #476434;  margin-bottom: 0.3rem; font-size: 11px;">
                                    <?php echo e($row->position_applied); ?>

                                </div>
                                <span style="font-size: 11px;">Position Applied</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
            <td width="29%">
                <table width="100%" cellspacing="0" cellpadding="5">
                    <tbody>
                                <tr><td>Birthday:</td><td  style="font-weight: 400; border-bottom: 1px solid black;"><?php echo e($row->birthdate); ?></td></tr>
                                <tr><td>Passport:</td><td  style="font-weight: 400; border-bottom: 1px solid black; "><?php echo e($row->passport); ?></td></tr>
                                <tr><td>SSRB:</td><td  style="font-weight: 400; border-bottom: 1px solid black; "><?php echo e($row->ssrb); ?></td></tr>
                                <tr><td>Cellphone #:</td><td  style="font-weight: 400; border-bottom: 1px solid black; "><?php echo e($row->contactno); ?></td></tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php
$path = "https://meritaclinic.ph/wp-content/uploads/2022/03/Merita-Logo.png";
$type = pathinfo($path, PATHINFO_EXTENSION);
$data = file_get_contents($path);
$logo = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>
<table width="100%" celspacing="0" cellpadding="5" style="text-align: center; border: 1px solid #476434;" >
    <tbody>
        <tr width="90%" style="border: 1px solid black; text-align: center;">
             
             <td width="25%" style="text-align: right;">
                <img src="<?php echo e($logo); ?>" width="80" />
            </td>
            <td width="75%">
               
                     <h2 style="font-family: serif; font-size: 16px; font-weight: 600;">MERITA DIAGNOSTIC CLINIC INC.</h2>
                    <p style="line-height: 10px;">5th floor Jettac Bldg. 920 Pres. Quirino Ave.cor. San Antonio, Malate, Manila</p>
                    <p style="line-height: 10px;">Tel: (02) 310-0595/404-3441 / Cell No. 0917-8576942 Email: mdcinc2019@gmail.com</p>
              
            </td>
        </tr>
    </tbody>
</table>
<table width="100%" cellspacing="2" cellpadding="3">
    <tbody>
        <tr>
            <td colspan="2"><b>INSTRUCTION TO WORKER: (ONLY PATIENT ARE ALLOWED TO ENTER)</b></td>
        </tr>
        <tr>
            <td>
                1. Register to the Merita EMR: https://meritaclinic.app/register.
            </td>
        </tr>
        <tr>
            <td>
                2. Fill up all the necessary information and schedule your appointment.
            </td>
        </tr>
        <tr>
            <td colspan="2">3. Bring 3 copies of 1x1 PICTURES.</td>
        </tr>
        <tr>
            <td colspan="2">4. (FASTING) NO INTAKE OF FOOD OR DRINKS FOR 8-10 HOURS.</td>
        </tr>
        <tr>
            <td colspan="2">5. Non-Compliance of the above Instruction may cause delay of processing
                of your application.</td>
        </tr>
        <tr style="margin-top: 15px;">
            <td colspan="2"><b>I have read, understand and agree to comply with the above
                    requirement.</b></td>
        </tr>
        <tr>
            <td width="50%" style="text-align: center; border-bottom: 1px solid #476434">
                <?php echo e($row->created_date); ?>

            </td>
            <td width="50%" style="text-align: center; border-bottom: 1px solid #476434">
                <img width="150px" height="45px" style="object-fit:cover;"
                src="" alt="">
            </td>
        </tr>
        <tr>
            <td style="text-align: center; font-size: 11px; font-family: sans-serif;">
            Date of PEME
            </td>                      
            <td style="text-align: center; font-size: 11px; font-family: sans-serif;">Signature</td>
        </tr>
    </tbody>
</table>
<table width="100%" cellspacing="5" cellpadding="3" >
    <tbody>
        <tr>
            <td colspan="3">5. Please conduct the following medication exam:</td>
        </tr>
        <tr>
            <td width="20%">5.1 Medical Package/Test:</td><td width="80%" style="text-align: left; border-bottom: 1px solid #476434"><?php echo e($row->packagename); ?></td>
        </tr>
        <tr>
            <td width="20%">5.2 Additional Request:</td><td width="80%" style="text-align: left; border-bottom: 1px solid #476434"><?php echo e($row->custom_request); ?></td>
        </tr>
    </tbody>
</table>
<table width="100%" cellspacing="5" cellpadding="3">
    <tbody>
        <tr>
            <td width="30%" style="text-align: center;"><b>Type of Payment: </b></td>
            <td style="text-align: center;">Applicant Paid
                <span>
                    <?php if($row->payment_type == "Applicant Paid"): ?>
                    <input type="checkbox" name="" id="" checked disabled style="vertical-align: middle;">
                    <?php else: ?>
                    <input type="checkbox" name="" id="" disabled style="vertical-align: middle;">
                    <?php endif; ?>
                </span>
            </td>
            <td style="text-align: center;">Billed Agency
                <span>
                    <?php if($row->payment_type == "Billed"): ?>
                    <input type="checkbox" name="" id="" checked disabled style="vertical-align: middle;">
                    <?php else: ?>
                    <input type="checkbox" name="" id="" disabled style="vertical-align: middle;">
                    <?php endif; ?>
                </span>
            </td>
        </tr>
    </tbody>
</table>
<table width="100%" cellspacing="5" cellpadding="3">
<tbody>
    <tr>
        <td width="30%">&nbsp;</td>
        <td width="40%" style="text-align: center; border-bottom: 1px solid #476434;"> <img src="<?php echo base64_decode($row->signature)?>" alt=""  width="150px" height="45px" style="object-fit:cover;"></td>
        <td width="30%">&nbsp;</td>
    </tr>
    <tr>
        <td width="30%">&nbsp;</td>
        <td width="40%" style="text-align: center;"> Signature over Printed name of Authorized Official</td>
        <td width="30%">&nbsp;</td>
    </tr>
</tbody>
</table>
<?php
$path2 = "https://meritaclinic.ph/wp-content/uploads/2022/06/merita-map.png";
$type2 = pathinfo($path2, PATHINFO_EXTENSION);
$data2 = file_get_contents($path2);
$map = 'data:image/' . $type2 . ';base64,' . base64_encode($data2);
?>
<table width="100%" cellspacing="5" cellpadding="3">
    <tbody>
        <tr>
            <td width="25%" style="text-align: center;"><h3>Location Map</h3></td>
            <td width="50%" style="text-align: center;"> <img src="<?php echo e($map); ?>" width="100%" /></td>
            <td width="25%">&nbsp;</td>
        </tr>
    </tbody>
</table>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</html><?php /**PATH C:\merita-app\resources\views/emails/refferal-pdf.blade.php ENDPATH**/ ?>