

<?php $__env->startSection('name'); ?>
<?php echo e($data['agencyName']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="container my-1">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <h2>Refferal Slip</h2>
                </div>
            </div>
            <hr>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12 col-md-6">
                        <table class="table table-borderless">
                            <tbody>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Employer :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->employer); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Firstname :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->firstname); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Lastname :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->lastname); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Middlename :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->middlename); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Package :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->packagename); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Email :</td>
                                    <td class="col-6"><?php echo e($referral->email_employee); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Address :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->address); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Payment Type :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->payment_type); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <table class="table table-borderless">
                            <tbody>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Age :</td>
                                    <td class="col-6"><?php echo e($referral->age); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Civil Status :</td>
                                    <td class="col-6"><?php echo e($referral->civil_status); ?></td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Position Applied :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->position_applied); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Country Destination :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->country_destination); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Vessel :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->vessel); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Passport :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->passport); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">SSRB :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->ssrb); ?>

                                    </td>
                                </tr>
                                <tr class="row">
                                    <td class="col-6 font-weight-bold">Custom Request :</td>
                                    <td class="col-6">
                                        <?php echo e($referral->custom_request); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Referral/view-refferal.blade.php ENDPATH**/ ?>