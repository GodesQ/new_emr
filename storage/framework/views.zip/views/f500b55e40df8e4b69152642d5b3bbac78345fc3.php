


<?php $__env->startSection('content'); ?>
<!-- BEGIN: Content-->
<div class="container">
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-11 col-12 mb-2">
                    <h3 class="content-header-title mb-0">Patient Information</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/progress-patient-info">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="#">Patient</a>
                                </li>
                                <li class="breadcrumb-item active">Patient Information
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="col-md-1 col-12">
                    <a class="btn btn-solid bg-success bg-darken-2 text-white" href="/edit-patient-info">Edit</a>
                </div>
            </div>
            <div class="content-body">
                <div class="content-body">
                    <!-- account setting page start -->
                    <section id="page-account-settings">
                        <div class="row">
                            <!-- left menu section -->
                            <div class="col-md-3 mb-2 mb-md-0">
                                <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                                    <li class="nav-item">
                                        <a class="nav-link d-flex active" id="account-pill-general" data-toggle="pill"
                                            href="#account-vertical-general" aria-expanded="true">
                                            <i class="feather icon-info"></i>
                                            Personal Information
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link d-flex" id="account-pill-password" data-toggle="pill"
                                            href="#account-vertical-password" aria-expanded="false">
                                            <i class="feather icon-globe"></i>
                                            Agency Information
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link d-flex" id="account-pill-connections" data-toggle="pill"
                                            href="#account-vertical-connections" aria-expanded="false">
                                            <i class="feather icon-feather"></i>
                                            Medical History
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link d-flex" id="account-pill-notifications" data-toggle="pill"
                                            href="#account-vertical-notifications" aria-expanded="false">
                                            <i class="feather icon-book"></i>
                                            Declaration Form
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <!-- right content section -->
                            <div class="col-md-9">
                                <div class="card">
                                    <div class="card-content">
                                        <div class="card-body">
                                            <div class="card">
                                                <div class="card-content">
                                                    <div class="card-body">
                                                        <div class="col-12">
                                                            <h3 class="mb-1"><i class="feather icon-info"></i>
                                                                Personal Info</h3>
                                                            <table class="table table-borderless">
                                                                <tbody>
                                                                    <tr class="row">
                                                                        <td class="col-3">Firstname:</td>
                                                                        <td class="col-4">
                                                                            <?php echo e($patient->firstname); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Lastname:</td>
                                                                        <td class="col-4">
                                                                            <?php echo e($patient->lastname); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Middlename:</td>
                                                                        <td class="col-4">
                                                                            <?php echo e($patient->middlename); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Contact No.:</td>
                                                                        <td class="col-4"><?php echo e($patientInfo->contactno); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Email:</td>
                                                                        <td class="col-4"><?php echo e($patient->email); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Address:</td>
                                                                        <td class="col-4"><?php echo e($patientInfo->address); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Gender:</td>
                                                                        <td class="col-4"><?php echo e($patient->gender); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Age:</td>
                                                                        <td class="col-4"><?php echo e($patient->age); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Occupation:</td>
                                                                        <td class="col-4"><?php echo e($patientInfo->occupation); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Nationality:</td>
                                                                        <td class="col-4"><?php echo e($patientInfo->nationality); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Religion:</td>
                                                                        <td class="col-4"><?php echo e($patientInfo->religion); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Marital Status:</td>
                                                                        <td class="col-4">
                                                                            <?php echo e($patientInfo->maritalstatus); ?>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <div class="col-12 my-5s">
                                                            <h3 class="mb-1"><i class="feather icon-globe"></i>
                                                                Agency Info</h3>
                                                            <table class="table table-borderless">
                                                                <tbody>
                                                                    <tr class="row">
                                                                        <td class="col-3">Firstname:</td>
                                                                        <td class="users-view-username col-4">
                                                                            <?php echo e($patient->firstname); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Lastname:</td>
                                                                        <td class="users-view-name col-4">
                                                                            <?php echo e($patient->lastname); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Middlename:</td>
                                                                        <td class="users-view-email">
                                                                            <?php echo e($patient->middlename); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Email:</td>
                                                                        <td><?php echo e($patient->email); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Gender:</td>
                                                                        <td><?php echo e($patient->gender); ?></td>
                                                                    </tr>
                                                                    <tr class="row">
                                                                        <td class="col-3">Age:</td>
                                                                        <td><?php echo e($patient->age); ?></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade " id="account-vertical-password" role="tabpanel"
                                                aria-labelledby="account-pill-password" aria-expanded="false">
                                                <form novalidate>
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-old-password">Name of
                                                                        Agency</label>
                                                                    <input disabled type="text" class="form-control"
                                                                        id="account-old-password" required
                                                                        placeholder="" value="<?php echo e($patientInfo->agency); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-new-password">Address of
                                                                        Agency</label>
                                                                    <input disabled type="text" name="password"
                                                                        id="account-new-password" class="form-control"
                                                                        placeholder="New Password" required
                                                                        value="<?php echo e($patientInfo->agency_address); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">
                                                                        Country of Destination</label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patientInfo->country_destination); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">
                                                                        Vessel</label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patientInfo->vessel); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">Passport
                                                                    </label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patientInfo->passportno); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">SSRB #
                                                                    </label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patientInfo->srbno); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">Medical
                                                                        Package Test
                                                                    </label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patientInfo->medical_package); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-6">
                                                            <div class="form-group">
                                                                <div class="controls">
                                                                    <label for="account-retype-new-password">Position
                                                                        Applied for
                                                                    </label>
                                                                    <input disabled type="text" name="con-password"
                                                                        class="form-control" required
                                                                        id="account-retype-new-password"
                                                                        value="<?php echo e($patient->position_applied); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane fade" id="account-vertical-connections" role="tabpanel"
                                                aria-labelledby="account-pill-connections" aria-expanded="false">
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-6">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Head and Neck Injury
                                                                    </td>
                                                                    <td><?php if($medicalHistory->head_and_neck_injury
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Frequent Headache
                                                                    </td>
                                                                    <td><?php if($medicalHistory->frequent_headache
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Frequent Dizziness
                                                                    </td>
                                                                    <td><?php if($medicalHistory->frequent_dizziness
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Fainting Spells, Fits
                                                                    </td>
                                                                    <td><?php if($medicalHistory->fainting_spells_fits
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Seizures
                                                                    </td>
                                                                    <td><?php if($medicalHistory->seizures
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Other neurological disorders
                                                                    </td>
                                                                    <td><?php if($medicalHistory->other_neurological_disorders
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Insomia or Sleep disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->insomia_or_sleep_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Depression, other mental disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->depression_other_mental_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Eye problems / Error of refraction
                                                                    </td>
                                                                    <td><?php if($medicalHistory->eye_problems_or_error_refraction
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Deafness / Ear disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->deafness_or_ear_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Nose or Throat disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->nose_or_throat_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Tuberculosis </td>
                                                                    <td><?php if($medicalHistory->tuberculosis
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Signed off as sick
                                                                    </td>
                                                                    <td><?php if($medicalHistory->signed_off_as_sick
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Repatriation form ship
                                                                    </td>
                                                                    <td><?php if($medicalHistory->repatriation_form_ship
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Declared Unfit for sea duty
                                                                    </td>
                                                                    <td><?php if($medicalHistory->declared_unfit_for_sea_duty
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Previous Hospitalization
                                                                    </td>
                                                                    <td><?php if($medicalHistory->previous_hospitalization
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Do you feel healthy /<br>Fit to perform
                                                                        duties of <br> designed position
                                                                    </td>
                                                                    <td><?php if($medicalHistory->feel_healthy
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>

                                                        </table>
                                                    </div>
                                                    <!-- SECOND TABLE -->
                                                    <div class="col-md-12  col-lg-6">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Other Lung disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->other_lung_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        High Blood Pressure
                                                                    </td>
                                                                    <td><?php if($medicalHistory->high_blood_pressure
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Heart Disease / Vascular
                                                                    </td>
                                                                    <td><?php if($medicalHistory->heart_disease_or_vascular
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Chest pain
                                                                    </td>
                                                                    <td><?php if($medicalHistory->chest_pain
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Rheumatic Fever
                                                                    </td>
                                                                    <td><?php if($medicalHistory->rheumatic_fever
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Diabetes Mellitus
                                                                    </td>
                                                                    <td><?php if($medicalHistory->diabetes_mellitus
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Endocrine disorders (goiter)
                                                                    </td>
                                                                    <td><?php if($medicalHistory->endocrine_disorders
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Cancer or Tumor
                                                                    </td>
                                                                    <td><?php if($medicalHistory->cancer_or_tumor
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Blood disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->blood_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Stomach pain, Gastritis
                                                                    </td>
                                                                    <td><?php if($medicalHistory->stomach_pain_or_gastritis
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Ulcer
                                                                    </td>
                                                                    <td><?php if($medicalHistory->ulcer
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Other Abdominal Disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->other_abdominal_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Medical certificate restricted
                                                                    </td>
                                                                    <td><?php if($medicalHistory->medical_certificate_restricted
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Medical certificate revoked
                                                                    </td>
                                                                    <td><?php if($medicalHistory->medical_certificate_revoked
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Aware of any medical problems
                                                                    </td>
                                                                    <td><?php if($medicalHistory->aware_of_any_medical_problems
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Aware of any disease / illness
                                                                    </td>
                                                                    <td><?php if($medicalHistory->aware_of_any_disease_or_illness
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Operation(s)
                                                                    </td>
                                                                    <td><?php if($medicalHistory->operations
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <!-- THIRD TABLE -->
                                                    <div class="col-md-12 col-lg-6">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Gynecological Disorders
                                                                    </td>
                                                                    <td><?php if($medicalHistory->gynecological_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Last Menstrual Period
                                                                    </td>
                                                                    <td><?php if($medicalHistory->last_menstrual_period
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Pregnancy
                                                                    </td>
                                                                    <td><?php if($medicalHistory->pregnancy
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Kidney or Bladder Disorder
                                                                    </td>
                                                                    <td><?php if($medicalHistory->kidney_or_bladder_disorder
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Back Injury / Joint pain
                                                                    </td>
                                                                    <td><?php if($medicalHistory->back_injury_or_joint_pain
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Arthritis </td>
                                                                    <td><?php if($medicalHistory->arthritis
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Genetic, Heredity or Familial Dis. </td>
                                                                    <td><?php if($medicalHistory->genetic_heredity_or_familial_dis
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Sexually Transmitted Disease (Syphilis)
                                                                    </td>
                                                                    <td><?php if($medicalHistory->sexually_transmitted_disease
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Tropical Disease - Malaria
                                                                    </td>
                                                                    <td><?php if($medicalHistory->tropical_disease_or_malaria
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Thypoid Fever
                                                                    </td>
                                                                    <td><?php if($medicalHistory->thypoid_fever
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Schistosomiasis
                                                                    </td>
                                                                    <td><?php if($medicalHistory->schistosomiasis
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Asthma
                                                                    </td>
                                                                    <td><?php if($medicalHistory->asthma
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Allergies </td>
                                                                    <td><?php if($medicalHistory->allergies
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Smoking </td>
                                                                    <td><?php if($medicalHistory->smoking
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Taking medication for Hypertension </td>
                                                                    <td><?php if($medicalHistory->taking_medication_for_hypertension
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Taking medication for Diabetes </td>
                                                                    <td><?php if($medicalHistory->taking_medication_for_diabetes
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12">
                                                                        Vaccination </td>
                                                                    <td><?php if($medicalHistory->vaccination
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="account-vertical-notifications"
                                                role="tabpanel" aria-labelledby="account-pill-notifications"
                                                aria-expanded="false">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-12">
                                                            <h4>Have you travelled abroad recently?</h4>
                                                        </div>
                                                        <div class="col-md-4 mt-1">
                                                            <?php if($declarationForm->travelled_abroad_recently
                                                            == 0): ?>
                                                            <span
                                                                class="btn btn-solid btn-warning isTravelAbroad">No</span>
                                                            <?php else: ?>
                                                            <span
                                                                class="btn btn-solid btn-success isTravelAbroad">Yes</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 travel mt-2">
                                                        <div class="form-group">
                                                            <label for="">Name of the area(s) visited
                                                                <span class="danger">*</span>
                                                            </label>
                                                            <fieldset>
                                                                <input disabled name="area_visited" type="text" id=""
                                                                    placeholder="Country, State, City"
                                                                    class="form-control"
                                                                    value="<?php echo e($declarationForm->area_visited); ?>" />
                                                            </fieldset>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 travel">
                                                        <div class="form-group ">
                                                            <label for="">Date of travel
                                                                <span class="danger">*</span>
                                                            </label>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <label class="font-weight-bold"
                                                                        for="">Arrival</label>
                                                                    <input disabled name="travel_arrival_date" id=""
                                                                        placeholder="" class="form-control" type="text"
                                                                        value="<?php echo e($declarationForm->travel_arrival); ?>" />
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label class="font-weight-bold"
                                                                        for="">Return</label>
                                                                    <input disabled name="travel_return_date" id=""
                                                                        placeholder="" class="form-control" type="text"
                                                                        value="<?php echo e($declarationForm->travel_return); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 my-2">
                                                        <div class="col-md-12">
                                                            <h4>Have you been in contact with people being infected,
                                                                suspected or diagnosed with COVID-19?</h4>
                                                        </div>
                                                        <div class="col-md-4 mt-1">
                                                            <?php if($declarationForm->contact_with_people_being_infected__suspected_diagnose_with_cov
                                                            == 0): ?>
                                                            <span
                                                                class="btn btn-solid btn-warning contact-with-cov">No</span>
                                                            <?php else: ?>
                                                            <span
                                                                class="btn btn-solid btn-success contact-with-cov">Yes</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 show-if-contact">
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <label class="font-weight-bold"
                                                                        for="">Relationship</label>
                                                                    <input disabled
                                                                        name="relationship_last_contact_people" id=""
                                                                        placeholder="" class="form-control" type="text"
                                                                        value="<?php echo e($declarationForm->relationship_with_last_people); ?>" />
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label class="font-weight-bold" for="">Last
                                                                        contact
                                                                        date</label>
                                                                    <input disabled name="last_contact_date" id=""
                                                                        placeholder="" class="form-control" type="text"
                                                                        value="<?php echo e($declarationForm->last_contact_date); ?>" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6 my-2">
                                                        <table class="table table-striped">
                                                            <tbody>
                                                                <tr>
                                                                    <td class="col-12 h4">Fever</td>
                                                                    <td>
                                                                        <?php if($declarationForm->fever
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12 h4">Cough</td>
                                                                    <td> <?php if($declarationForm->cough
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12 h4">Shortness of Breath</td>
                                                                    <td>
                                                                        <?php if($declarationForm->shortness_of_breath
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="col-12 h4">Persistent Pain in the
                                                                        Chest</td>
                                                                    <td>
                                                                        <?php if($declarationForm->persistent_pain_in_chess
                                                                        == 0): ?>
                                                                        <span
                                                                            class="btn btn-solid btn-warning">No</span>
                                                                        <?php else: ?>
                                                                        <span
                                                                            class="btn btn-solid btn-success">Yes</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                </section>
                <!-- account setting page end -->
            </div>
        </div>
    </div>
</div>
</div>
<script>
function hasTravelAbroad() {
    let isTravelAbroad = document.querySelectorAll('.isTravelAbroad');
    let travelElement = document.querySelectorAll('.travel');
    for (let index = 0; index < isTravelAbroad.length; index++) {
        const element = isTravelAbroad[index];
        if (element.innerHTML == "No") {
            travelElement[0].style.display = "none";
            travelElement[1].style.display = "none";
        } else {
            travelElement[0].style.display = "block";
            travelElement[1].style.display = "block";
        }
    }
}

function hasContactWithCovid() {
    let isContactWithCov = document.querySelectorAll('.contact-with-cov');
    let showIfContact = document.querySelector('.show-if-contact');
    for (let index = 0; index < isContactWithCov.length; index++) {
        const element = isContactWithCov[index];
        if (element.innerHTML == "No") {
            showIfContact.style.display = "none";
        } else {
            showIfContact.style.display = "block";
        }
    }
}
hasTravelAbroad();
hasContactWithCovid();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/patient-info.blade.php ENDPATH**/ ?>