

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Miscellaneous</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_misc" role="form">
                            <?php if(Session::get('status')): ?>
                                <?php $__env->startPush('scripts'); ?>
                                    <script>
                                        toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2" class="table">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td align="left"><b>EXAM</b></td>
                                        <td>
                                            <input name="exam" id="exam" type="text" value="<?php echo e($exam->exam); ?>"
                                                class="form-control">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="12%" align="left"><b>RESULT</b></td>
                                        <td width="88%"><textarea name="result" id="result" cols="50" rows="4"
                                                class="form-control"><?php echo e($exam->result); ?></textarea></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="4">
                                                <tbody>
                                                    <tr>
                                                        <td width="34%"><b>COLUMN1</b></td>
                                                        <td width="34%"><b>COLUMN2</b></td>
                                                        <td width="32%"><b>COLUMN3</b></td>
                                                    </tr>
                                                    <tr>
                                                        <td><textarea name="col1" id="result2" cols="38" rows="6"
                                                                class="form-control"><?php echo e($exam->col1); ?></textarea></td>
                                                        <td><textarea name="col2" id="col" cols="38" rows="6"
                                                                class="form-control"><?php echo e($exam->col2); ?></textarea></td>
                                                        <td><textarea name="col3" id="col2" cols="38" rows="6"
                                                                class="form-control"><?php echo e($exam->col3); ?></textarea></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $medical_techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med_tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($med_tech->id); ?> <?php echo e($med_tech->id == $exam->technician_id ? "selected" : null); ?>><?php echo e($med_tech->firstname); ?> <?php echo e($med_tech->lastname); ?>, <?php echo e($med_tech->title); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <?php $__currentLoopData = $pathologists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pathologist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($pathologist->id); ?> <?php echo e($pathologist->id == $exam->technician2_id ? "selected" : null); ?>><?php echo e($pathologist->firstname); ?> <?php echo e($pathologist->lastname); ?>, <?php echo e($pathologist->title); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Miscellaneous/edit-misc.blade.php ENDPATH**/ ?>