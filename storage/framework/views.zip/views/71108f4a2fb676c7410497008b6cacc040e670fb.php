<div class="row my-1">
    <div class="col-6">
        <a href="edit_visacuity?id=<?php echo e($exam_visacuity->admission_id); ?>"
            class="btn btn-solid btn-primary">Edit</a>
        <button
            onclick='window.open("/exam_visacuity_print?id=<?php echo e($exam_visacuity->admission_id); ?>", "width=800,height=650").print()'
            class="btn btn-dark btn-solid"
            title="Print">Print</button>
    </div>
</div>
<table width="100%" cellpadding="2"
    cellspacing="2" class="table no-border">
    <tbody>
        <tr>
            <td align="center" colspan="2"
                align="center">
                <b>VISUAL
                    ACUITY</b>
            </td>
            <td align="center" colspan="2"
                align="center"><b>FAR
                    VISION</b></td>
            <td colspan="2" align="center">
                <b>NEAR
                    VISION</b>
            </td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
            <td width="18%" align="center">
                <b>OD</b>
            </td>
            <td width="18%" align="center">
                <b>OS</b>
            </td>
            <td width="17%" align="center">
                <b>ODJ</b>
            </td>
            <td width="17%" align="center">
                <b>OSJ</b>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Uncorrected</b>
            </td>
            <td align="center">
                <?php echo e($exam_visacuity->ufvod); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->ufvos); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->unvodj); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->unvosj); ?>

            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Corrected</b>
            </td>
            <td align="center">
                <?php echo e($exam_visacuity->cfvod); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->cfvos); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->cnvodj); ?>

            </td>
            <td align="center">
                <?php echo e($exam_visacuity->cnvosj); ?>

            </td>
        </tr>
    </tbody>
</table>
<table class="table table-bordered">
    <tr>
        <td width="10%"><b>Remarks</b></td>
        <td><?php echo e($exam_visacuity->remarks); ?></td>
    </tr>
</table><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Visacuity/view-visacuity.blade.php ENDPATH**/ ?>