<html>

<head>
    <title>URINALYSIS</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
</head>

<body>
    <center>
        <table width="760" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                            <tbody>
                                <tr>
                                    <td width="80" rowspan="3" align="center"><img
                                            src="../../../app-assets/images/logo/logo.jpg" width="80" height="80"
                                            alt=""></td>
                                    <td width="356" rowspan="3" align="center" valign="middle">
                                        <span class="lblCompName">MERITA DIAGNOSTIC CLINIC INC.</span><br
                                            style="margin-bottom: 20px">
                                        <span class="lblCompDtl"><b>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave.
                                                Cor. San Antonio St. Malate, Manila<b><br>
                                                    Tel No.: (02) 5310-032 / 5310-0825 / 0917-8576942 / 0908-8908850<br>
                                                    Email: meritaclinic@gmail.com / meritadiagnosticclinic@yahoo.com<br>
                                                    Accredited: DOH * POEA * MARINA * TESDA * Oil &amp; Gas UK<br>Skuld
                                                    P&amp;I * West of England P&amp;I</b></b></span><b><b>
                                            </b></b>
                                    </td>
                                    <td width="218" valign="top" class="brdLeftBtm"><b>NAME:</b><br>
                                        <span style="font-size:15px">MAGNETICO,<br>ARNOLD CORDOVA</span>
                                    </td>
                                    <td width="39" valign="top" class="brdLeftBtm"><b>AGE:</b><br>
                                        <span style="font-size:15px">72</span>
                                    </td>
                                    <td width="45" valign="top" class="brdLeftBtm"><b>SEX:</b><br>
                                        <span style="font-size:15px">Male</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="27" colspan="3" align="left" valign="top" class="brdLeftBtm">
                                        <b>REQUESTED BY:</b><br>
                                        <span style="font-size:15px">Marlow Navigation Phils. Inc.</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="26" align="left" valign="top" class="brdLeft"><b>PEME DATE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->trans_date); ?></span>
                                    </td>
                                    <td colspan="2" align="left" valign="top" class="brdLeft"><b>PATIENT
                                            NO:</b><br><span style="font-size:15px">P19-000009</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50" align="center" class="lblReport">URINALYSIS</td>
                </tr>
                <tr>
                    <td>
                        <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
                        <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <table width="800" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                                            <tbody>
                                                <tr>
                                                    <td width="231" align="center" class="brdBtm"><b>MACROSCOPIC</b>
                                                    </td>
                                                    <td width="140" align="center" class="brdLeftBtm"><b>RESULTS</b>
                                                    </td>
                                                    <td width="206" align="center" class="brdLeftBtm"><b>MICROSCOPIC</b>
                                                    </td>
                                                    <td width="205" align="center" class="brdLeftBtm"><b>RESULTS</b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Color</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->color); ?>

                                                    </td>
                                                    <td valign="top" class="brdLeftBtm">Pus Cells</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->pus); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Transparency</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->transparency); ?></td>
                                                    <td valign="top" class="brdLeftBtm">RBC</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->rbc); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">pH</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->ph); ?></td>
                                                    <td valign="top" class="brdLeftBtm">Epithelial Cells</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->epithelial); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Specific Gravity</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->epithelial); ?></td>
                                                    <td valign="top" class="brdLeftBtm">Amorphous Urates</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->urates); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Sugar</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->sugar); ?>

                                                    </td>
                                                    <td valign="top" class="brdLeftBtm">Amorphous Phosphates</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->phosphates); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Protein/Albumin</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->albumin); ?>

                                                    </td>
                                                    <td valign="top" class="brdLeftBtm">Mucus Threads</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->mucus); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Ketone</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->ketone); ?>

                                                    </td>
                                                    <td valign="top" class="brdLeftBtm">Bacteria</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->bacteria); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Urobilinogen</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->urobilinogen); ?></td>
                                                    <td colspan="2" rowspan="5" align="left" valign="top"
                                                        class="brdLeft">OTHERS:
                                                        <?php echo e($exam->others); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Bilirubin</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->bilirubin); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Nitrite</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->nitrite); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" class="brdBtm">Leukocyte</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->leukocyte); ?></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top">Blood Cell</td>
                                                    <td align="left" valign="top" class="brdLeft"><?php echo e($exam->blood); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table width="760" border="0" cellpadding="2" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td height="120" align="center" valign="bottom">
                                                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                    </td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician1): ?>
                                                                            <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?><br>
                                                                            Medical Technologist<br>
                                                                            Lic. No. <?php echo e($technician1->license_no); ?> 
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td colspan="3" align="center" valign="bottom">
                                                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                    </td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician2): ?>
                                                                        <?php echo e($technician2->firstname . " " . $technician2->middlename . " " . $technician2->lastname . ", " . $technician2->title); ?><br>
                                                                        Pathologist<br>
                                                                        Lic. No. <?php echo e($technician2->license_no); ?>

                                                                        <?php endif; ?> 
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60"><span class="lblForm">FORM NO. 08<br>REV. 01 / 02-12-2019</span></td>
                </tr>
            </tbody>
        </table>
    </center>


</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/examlab_urinalysis_print.blade.php ENDPATH**/ ?>