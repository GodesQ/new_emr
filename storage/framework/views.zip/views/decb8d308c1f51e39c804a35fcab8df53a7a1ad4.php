

<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-body my-2">
            <div class="container">
                <div class="card">
                    <div class="card-header">
                        <h2>Transmittal</h2>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <section id="basic-form-layouts">
                                <form action="transmittal_print" method="GET" target="_blank">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="date_from">Date From :</label>
                                                <input required type="date" max="2050-12-31" name="date_from" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="date_to">Date To :</label>
                                                <input required type="date" max="2050-12-31" name="date_to" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="">Agency</label>
                                                <select name="agency_id" id="" class="select2">
                                                    <option value="">All</option>
                                                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($agency->id); ?>"><?php echo e($agency->agencyname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="">Patient Status</label>
                                                <select name="patientstatus" id="" class="select2">
                                                <option value="">All</option>
                                                <option value="Fit">Fit</option>
                                                <option value="Unfit">Unfit</option>
                                                <option value="Pending">Pending</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fa fa-print"></i> Print
                                        </button>
                                </div>
                                </form>
                                
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Transmittal/transmittal.blade.php ENDPATH**/ ?>