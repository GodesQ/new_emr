

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Edit Employee</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>

                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <?php if(Session::get('status')): ?>
                            <div class="success alert-success p-2 my-2 rounded">
                                <?php echo e(Session::get('status')); ?>

                            </div>
                            <?php endif; ?>
                            <form name="frm" method="POST" action="" id="update_employee" role="form"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal fade text-left" id="defaultSize" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel18" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel18"><i class="fa fa-camera"></i>
                                                    Take
                                                    Picture
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body d-flex justify-content-center align-items-center">
                                                <div class="camera"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn grey btn-outline-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-outline-primary"
                                                    onclick="snapShot()">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-body">
                                    <table width="100%" border="0" cellspacing="2" cellpadding="0"
                                        class="table table-responsive">
                                        <tbody>
                                            <tr>
                                                <td><b>Employee Code</b></td>
                                                <td><input name="employeecode" id="employeecode" type="text"
                                                        class="form-control" value="<?php echo e($employee->employeecode); ?>"
                                                        readonly=""></td>
                                                <td></td>
                                                <td align="right" valign="top">
                                                    <img src="<?php echo $employee->signature ?>" alt=""
                                                        class="signature-taken mt-4">
                                                    <?php if($employee->employee_image == null || $employee->employee_image
                                                    == " "): ?>
                                                    <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                                        alt="Profile Picture" data-toggle="modal"
                                                        data-target="#defaultSize"
                                                        class="users-avatar-shadow rounded open-camera image-taken"
                                                        onclick="openCamera()" height="64" width="64">
                                                    <?php else: ?>
                                                    <img src="../../../app-assets/images/employees/<?php echo e($employee->employee_image); ?>"
                                                        data-toggle="modal" data-target="#defaultSize"
                                                        alt="Profile Picture"
                                                        class="users-avatar-shadow open-camera image-taken"
                                                        onclick="openCamera()" height="64" width="64">
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <input type="hidden" name="id" value="<?php echo e($employee->id); ?>">
                                                <input type="hidden" name="old_image"
                                                    value="<?php echo e($employee->employee_image); ?>">
                                                <input type="hidden" name="employee_image" class="patient-image"
                                                    value="<?php echo e($employee->employee_image); ?>">
                                                <input type="hidden" name="signature" id="signature_data" value="">
                                                <input type="hidden" name="old_signature" id="old_signature"
                                                    value="<?php echo e($employee->signature); ?>">
                                                <td><b>Last Name</b></td>
                                                <td>
                                                    <input name="lastname" id="lastname" type="text"
                                                        class="form-control lastname" value="<?php echo e($employee->lastname); ?>">
                                                </td>
                                                <td><b>First Name</b></td>
                                                <td><input name="firstname" id="firstname" type="text"
                                                        class="form-control" value="<?php echo e($employee->firstname); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Middle Name</b></td>
                                                <td><input name="middlename" id="middlename" type="text"
                                                        class="form-control" value="<?php echo e($employee->middlename); ?>"></td>
                                                <td><b>Email</b></td>
                                                <td><input name="email" id="email" type="text" class="form-control"
                                                        value="<?php echo e($employee->email); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Username</b></td>
                                                <td>
                                                    <div id="uservalid"></div>
                                                    <input name="username" id="username" type="text"
                                                        class="form-control" value="<?php echo e($employee->username); ?>">
                                                </td>
                                                <td>
                                                    <b>Title</b>
                                                </td>
                                                <td><input name="title" id="title" type="text" class="form-control"
                                                        value="<?php echo e($employee->title); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Position</b></td>
                                                <td><input name="position" id="position" type="text"
                                                        class="form-control" value="<?php echo e($employee->position); ?>"></td>
                                                <td><b>License No./Certificate No./PRC No.</b></td>
                                                <td><input name="license_no" id="license_no" type="text"
                                                        class="form-control" value="<?php echo e($employee->license_no); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Address</b></td>
                                                <td><input name="address" id="address" type="text" class="form-control"
                                                        value="<?php echo e($employee->address); ?>"></td>
                                                <td> <b>Contact No.</b></td>
                                                <td><input name="contactno" id="address" type="text"
                                                        class="form-control" value="<?php echo e($employee->contactno); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Other Position</b></td>
                                                <td><input name="otherposition" id="address" type="text"
                                                        class="form-control" value="<?php echo e($employee->otherposition); ?>"></td>
                                                <td><b> Religion</b></td>
                                                <td><input name="religion" id="address" type="text" class="form-control"
                                                        value="<?php echo e($employee->religion); ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><b>Gender</b></td>
                                                <td>
                                                    <select name="gender" id="address" type="text" class="form-control">
                                                        <option value="Male" <?php echo e($employee->gender == "Male" ? "selected" : null); ?>>Male</option>
                                                        <option value="Female" <?php echo e($employee->gender == "Female" ? "selected" : null); ?>>Female</option>
                                                    </select>
                                                </td>
                                                <td><b> Marital Status</b></td>
                                                <td><select name="maritalstatus" id="address" type="text"
                                                        class="form-control">
                                                        <option value="">Select Civil Status</option>
                                                        <option value="Single" <?php echo $employee->maritalstatus ==
                                                            "Single" ? "selected=''" : "" ?> >Single</option>
                                                        <option value="Married" <?php echo $employee->maritalstatus ==
                                                            "Married" ? "selected=''" : "" ?> >Married</option>
                                                        <option value="Widowed" <?php echo $employee->maritalstatus ==
                                                            "Widowed" ? "selected=''" : "" ?> >Widowed</option>
                                                        <option value="Divorced" <?php echo $employee->maritalstatus ==
                                                            "Divorced" ? "selected=''" : "" ?> >Divorced</option>
                                                        <option value="Domestic Relationship" <?php echo $employee->
                                                            maritalstatus == "Domestic Relationship" ? "selected=''" :
                                                            "" ?> >Domestic
                                                            Relationship</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Birthdate</b></td>
                                                <td><input name="birthdate" id="address" type="date" max="2050-12-31"
                                                        class="form-control" value="<?php echo e($employee->birthdate); ?>"></td>
                                                <td><b>Birthplace</b></td>
                                                <td><input name="birthplace" id="address" type="text"
                                                        class="form-control" value="<?php echo e($employee->birthplace); ?>"></td>
                                            </tr>
                                            <!--<tr>-->
                                            <!--    <td><b>Password</b></td>-->
                                            <!--    <td><input name="password" id="password" type="password"-->
                                            <!--            class="form-control" value="<?php echo e($employee->password); ?>"></td>-->
                                            <!--</tr>-->
                                            <tr>
                                                <td valign="top"><b>Signature</b></td>
                                                <td>
                                                    <div class="d-flex flex-column my-2 mx-4">
                                                        <canvas class="signature"></canvas>
                                                        <button type='button'
                                                            class="btn btn-solid btn-primary clear-signature my-1">Clear</button>
                                                    </div>
                                                </td>

                                                <td><b>Department</b></td>
                                                <td>
                                                    <select name="dept" id="" class="form-control select2">
                                                        <option value="<?php echo e($employee->dept_id); ?>"><?php echo e($employee->dept_name); ?>

                                                        </option>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="box-footer">
                                    <button name="action" value="save" type="submit" onclick=""
                                        class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../../../app-assets/js/scripts/signature_pad-master/js/signature_pad.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script src="../../../app-assets/js/scripts/custom.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Employee/edit-employee.blade.php ENDPATH**/ ?>