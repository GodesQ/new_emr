<html>

<head>
    <title>2 DIMENSIONAL ECHOCARDIOGRAPHY PLAIN</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    .text-red {
        color: red;
    }
    </style>
</head>

<body>
    <center>
        <table width="760" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                            <tbody>
                                <tr>
                                    <td width="80" rowspan="3" align="center"><img
                                            src="../../../app-assets/images/logo/logo.jpg" width="80" height="80"
                                            alt=""></td>
                                    <td width="356" rowspan="3" align="center" valign="middle">
                                        <span class="lblCompName">MERITA DIAGNOSTIC CLINIC INC.</span><br
                                            style="margin-bottom: 20px">
                                        <span class="lblCompDtl"><b>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave.
                                                Cor. San Antonio St. Malate, Manila<b><br>
                                                    Tel No.: (02) 5310-032 / 5310-0825 / 0917-8576942 / 0908-8908850<br>
                                                    Email: meritaclinic@gmail.com / meritadiagnosticclinic@yahoo.com<br>
                                                    Accredited: DOH * POEA * MARINA * TESDA * Oil &amp; Gas UK<br>Skuld
                                                    P&amp;I * West of England P&amp;I</b></b></span><b><b>
                                            </b></b>
                                    </td>
                                    <td width="218" valign="top" class="brdLeftBtm"><b>NAME:</b><br>
                                        <span
                                            style="font-size:15px"><?php echo e($admission->lastname . ', ' . $admission->firstname . " " . $admission->middlename); ?></span>
                                    </td>
                                    <td width="39" valign="top" class="brdLeftBtm"><b>AGE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->age); ?></span>
                                    </td>
                                    <td width="45" valign="top" class="brdLeftBtm"><b>SEX:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->gender); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="27" colspan="3" align="left" valign="top" class="brdLeftBtm">
                                        <b>REQUESTED BY:</b><br>
                                        <span style="font-size:15px">Multinational Maritime Inc</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="26" align="left" valign="top" class="brdLeft"><b>PEME DATE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->trans_date); ?></span>
                                    </td>
                                    <td colspan="2" align="left" valign="top" class="brdLeft"><b>PATIENT
                                            NO:</b><br><span style="font-size:15px"><?php echo e($admission->patientcode); ?></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50" align="center" class="lblReport">2 DIMENSIONAL ECHOCARDIOGRAPHY PLAIN</td>
                </tr>
                <tr>
                    <td>
                        <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td<table width="100%" border="0" cellpadding="2" cellspacing="2"
                                        class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td width="15%" align="left"><b>Referring MD </b></td>
                                    <td width="24%" align="left"><input name="referring_md" type="text"
                                            id="referring_md" value="<?php echo e($exam->referring_md); ?>" class="brdNone"></td>
                                    <td width="8%" align="left"><b>Height</b></td>
                                    <td width="8%" align="left"><input name="height" type="text" id="height"
                                            value="<?php echo e($exam->height); ?>" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                    <td width="8%" align="left"><b>Weight</b></td>
                                    <td width="8%" align="left"><input name="weight" type="text" id="weight"
                                            value="<?php echo e($exam->weight); ?>" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                    <td width="7%" align="left"><b>BP</b></td>
                                    <td colspan="3" align="left"><input name="bp" type="text" id="bp"
                                            value="<?php echo e($exam->bp); ?> size=" 15" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                </tr>
                                <tr>
                                    <td width="15%" align="left"><b>Clinical Diagnostic</b></td>
                                    <td align="left"><input name="clinical_diagnostic" type="text"
                                            id="clinical_diagnostic" value="<?php echo e($exam->clinical_diagnostic); ?>"
                                            class="brdNone"></td>
                                    <td align="left"><b>Study No. </b></td>
                                    <td align="left"><input name="study_no" type="text" id="study_no"
                                            value="<?php echo e($exam->study_no); ?>" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                    <td align="left"><b>DVD No.</b></td>
                                    <td align="left"><input name="dvd_no" type="text" id="dvd_no"
                                            value="<?php echo e($exam->dvd_no); ?>" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                    <td align="left"><b>Rhythm</b></td>
                                    <td width="8%" align="left"><input name="rhythm" type="text" id="rhythm"
                                            value="<?php echo e($exam->rhythm); ?>" size="15" class="brdNone"
                                            style="width:50px;text-align:center;"></td>
                                    <td width="6%" align="left"><b>HR</b></td>
                                    <td width="8%" align="left"><input name="hr" type="text" id="hr"
                                            value="<?php echo e($exam->hr); ?>" class="brdNone" style="width:50px;text-align:center;">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" cellpadding="2" cellspacing="0" class="brdTable">
                            <tbody>
                            <tr>
                                <td colspan="10" align="center"><b
                                        style="font-size:17px">QUANTITATIVE MEASUREMENT</b></td>
                            </tr>
                            <tr>
                                <td width="11%" align="center"><b>Dimension</b></td>
                                <td width="11%" align="center"><b>Measurement</b></td>
                                <td width="13%" align="center"><b>Normal</b></td>
                                <td width="12%" align="center"><b>Dimension</b></td>
                                <td width="11%" align="center"><b>Measurement</b></td>
                                <td colspan="2" align="center"><b>Simposon's</b></td>
                                <td colspan="3" align="center"><b>Normal</b></td>
                            </tr>
                            <tr>
                                <td align="left">LV (ed)</td>
                                <td align="center"><input name="lved" type="text"
                                        class="brdNone <?php echo e($exam->lved < '3.9' ? 'text-red' : null); ?>"
                                        id="lved" style="width:50px;text-align:center;"
                                        value="<?php echo e($exam->lved); ?> <?php echo e($exam->lved < '3.9' ? 'L' : null); ?>"></td>
                                <td align="center">(3.9 - 5.2)</td>
                                <td align="left">LVEDV</td>
                                <td align="center"><input name="lvedv" type="text" id="lvedv"
                                        value="<?php echo e($exam->lvedv); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="lvedv_simp" type="text"
                                        id="lvedv_simp" value="<?php echo e($exam->lvedv_simp); ?>"
                                        class="brdNone" style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">LV (es)</td>
                                <td align="center"><input name="lves" type="text" id="lves"
                                        value="<?php echo e($exam->lves); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td align="left">LVESV</td>
                                <td align="center"><input name="lvesv" type="text" id="lvesv"
                                        value="<?php echo e($exam->lvesv); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="lvesv_simp" type="text"
                                        id="lvesv_simp" value="<?php echo e($exam->lvesv_simp); ?>"
                                        class="brdNone" style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">IVS (ed)</td>
                                <td align="center"><input name="ivsed" type="text" id="ivsed"
                                        value="<?php echo e($exam->lvesv_simp); ?> <?php echo e($exam->lvesv_simp < '0.8' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->lvesv_simp < '0.8' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(0.8 - 1.1)</td>
                                <td align="left">Stroke Volume</td>
                                <td align="center"><input name="sv" type="text" id="sv"
                                        value="<?php echo e($exam->sv); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="sv_simp" type="text"
                                        id="sv_simp" value="<?php echo e($exam->sv_simp); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">IVS (es)</td>
                                <td align="center"><input name="ivses" type="text" id="ivses"
                                        value="<?php echo e($exam->ivses); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td align="left">Cardiac Output</td>
                                <td align="center"><input name="co" type="text" id="co"
                                        value="<?php echo e($exam->co); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="co_simp" type="text"
                                        id="co_simp" value="<?php echo e($exam->co_simp); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">LVPW (ed)</td>
                                <td align="center"><input name="lvpwed" type="text" id="lvpwed"
                                        value="<?php echo e($exam->lvpwed); ?> <?php echo e($exam->lvpwed < '0.8' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->lvpwed < '0.8' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(0.8 - 1.1)</td>
                                <td align="left">EF</td>
                                <td align="center"><input name="ef" type="text" id="ef"
                                        value="<?php echo e($exam->ef); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="ef_simp" type="text"
                                        id="ef_simp" value="<?php echo e($exam->ef_simp); ?> <?php echo e($exam->ef_simp < '55' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->ef_simp < '55' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">(55 - 77)</td>
                            </tr>
                            <tr>
                                <td align="left">LVPW (es)</td>
                                <td align="center"><input name="lvpwes" type="text" id="lvpwes"
                                        value="<?php echo e($exam->lvpwes); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td align="left">FS</td>
                                <td align="center"><input name="fs" type="text" id="fs"
                                        value="<?php echo e($exam->fs); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="fs_simp" type="text"
                                        id="fs_simp" value="<?php echo e($exam->fs_simp); ?> <?php echo e($exam->fs_simp < '29' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->fs_simp < '29' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">(29 - 42)</td>
                            </tr>
                            <tr>
                                <td align="left">Aorta</td>
                                <td align="center"><input name="aorta" type="text" id="aorta"
                                        value="<?php echo e($exam->aorta); ?> <?php echo e($exam->aorta < '2.3' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->aorta < '2.3' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(2.3 - 3.5)</td>
                                <td align="left">VCF</td>
                                <td align="center"><input name="vcf" type="text" id="vcf"
                                        value="<?php echo e($exam->vcf); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="vcf_simp" type="text"
                                        id="vcf_simp" value="<?php echo e($exam->vcf_simp); ?> <?php echo e($exam->vcf_simp < '0.5' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->vcf_simp < '0.5' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">(0.5 - 1.0)</td>
                            </tr>
                            <tr>
                                <td align="left">LA (AP)</td>
                                <td align="center"><input name="laap" type="text" id="laap"
                                        value="<?php echo e($exam->laap); ?> <?php echo e($exam->laap < '2.6' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->laap < '2.6' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(2.6 - 3.8)</td>
                                <td align="left">LV Mass 1</td>
                                <td align="center"><input name="lmv" type="text" id="lmv"
                                        value="<?php echo e($exam->lmv); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center"><input name="lmv_simp" type="text"
                                        id="lmv_simp" value="<?php echo e($exam->lmv_simp); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="3" align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">MPA</td>
                                <td align="center"><input name="mpa" type="text" id="mpa"
                                        value="<?php echo e($exam->mpa); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td colspan="7" align="left">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">LVET</td>
                                <td align="center"><input name="lvet" type="text" id="lvet"
                                        value="<?php echo e($exam->lvet); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td colspan="2" align="center"><b>Diastolic Functions</b></td>
                                <td colspan="2" align="center"><b>Left Atrium</b></td>
                                <td width="12%" align="center">&nbsp;</td>
                                <td width="10%" colspan="2" align="center"><b>Normal</b></td>
                            </tr>
                            <tr>
                                <td align="left">EPSS</td>
                                <td align="center"><input name="epss" type="text" id="epss"
                                        value="<?php echo e($exam->epss); ?> <?php echo e($exam->epss > '1.0' ? 'H' : null); ?>"
                                        class="brdNone <?php echo e($exam->epss > '1.0' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">( &lt; 1.0)</td>
                                <td>DT</td>
                                <td align="center"><input name="dt" type="text" id="dt"
                                        value="<?php echo e($exam->dt); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td width="12%">L1</td>
                                <td width="8%">LVMI</td>
                                <td align="center"><input name="l1" type="text" id="l1"
                                        value="<?php echo e($exam->l1); ?> <?php echo e($exam->l1 < '49' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->l1 < '49' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2" align="center">(49-115)</td>
                            </tr>
                            <tr>
                                <td align="left">LVOT</td>
                                <td align="center"><input name="lvot" type="text" id="lvot"
                                        value="<?php echo e($exam->lvot); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td>IVRT</td>
                                <td align="center"><input name="ivrt" type="text" id="ivrt"
                                        value="<?php echo e($exam->ivrt); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td>L2</td>
                                <td>RWT</td>
                                <td align="center"><input name="l2" type="text" id="l2"
                                        value="<?php echo e($exam->l2); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">RV</td>
                                <td align="center"><input name="rv" type="text" id="rv"
                                        value="<?php echo e($exam->rv); ?> <?php echo e($exam->rv < '2.2' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->rv < '2.2' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(2.2 - 4.0)</td>
                                <td>PV Flow</td>
                                <td align="center"><input name="pvf" type="text" id="pvf"
                                        value="<?php echo e($exam->pvf); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td>A1</td>
                                <td>&nbsp;</td>
                                <td align="center"><input name="a1" type="text" id="a1"
                                        value="<?php echo e($exam->a1); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">RA</td>
                                <td align="center"><input name="ra" type="text" id="ra"
                                        value="<?php echo e($exam->ra); ?> <?php echo e($exam->ra < '3.5' ? 'L' : null); ?>"
                                        class="brdNone <?php echo e($exam->ra < '3.5' ? 'text-red' : null); ?>"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">(3.5 - 4.5)</td>
                                <td>PV E</td>
                                <td align="center"><input name="pve" type="text" id="pve"
                                        value="<?php echo e($exam->pve); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td>A2</td>
                                <td>&nbsp;</td>
                                <td align="center"><input name="a2" type="text" id="a2"
                                        value="<?php echo e($exam->a2); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">MV Annulus</td>
                                <td align="center"><input name="mva" type="text" id="mva"
                                        value="<?php echo e($exam->mva); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td>PV A</td>
                                <td align="center"><input name="pva" type="text" id="pva"
                                        value="<?php echo e($exam->pva); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td>LA Vol.</td>
                                <td>&nbsp;</td>
                                <td align="center"><input name="lav" type="text" id="lav"
                                        value="<?php echo e($exam->lav); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td colspan="2">&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="left">TV Annulus</td>
                                <td align="center"><input name="tva" type="text" id="tva"
                                        value="<?php echo e($exam->tva); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td align="center">&nbsp;</td>
                                <td>PV AR</td>
                                <td align="center"><input name="pvar" type="text" id="pvar"
                                        value="<?php echo e($exam->pvar); ?>" class="brdNone"
                                        style="width:50px;text-align:center;"></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td colspan="2">&nbsp;</td>
                            </tr>
                                <tr>
                                    <table width="100%" cellpadding="2" cellspacing="0" class="brdTable">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table id="brdTblNone" width="100%" border="0" cellspacing="0"
                                                        cellpadding="2">
                                                        <tbody>
                                                            <tr>
                                                                <td width="13%" valign="top"><b>Interpretation:</b></td>
                                                                <td width="87%" valign="top"><?php echo e($exam->interpretation); ?>

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <table id="brdTblNone" width="100%" border="0" cellspacing="0"
                                                        cellpadding="2">
                                                        <tbody>
                                                            <tr>
                                                                <td width="13%" valign="top"><b>Conclusion:</b></td>
                                                                <td width="87%" valign="top"><?php echo e($exam->conclusion); ?></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td height="120" align="right" valign="bottom">
                                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                                            <tbody>
                                                <tr>
                                                    <td align="center">
                                                    </td>
                                                </tr>
                                                <tr valign="bottom">
                                                    <td align="center" class="brdTop">
                                                        <?php echo e($technician1 ? $technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title : ""); ?>

                                                        <br>
                                                        Cardiologist
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>
        <tr>
            <td height="60"><span class="lblForm">FORM NO. 38<br>REV. 01 / 02-12-2019</span></td>
        </tr>
        </tbody>
        </table>
    </center>


</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/exam_echoplain_print.blade.php ENDPATH**/ ?>