

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Add Employee</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>

                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <span class="badge-danger rounded"><?php $__errorArgs = ['employee_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            <form name="frm" method="POST" action="/store_employees" role="form">
                                <?php echo csrf_field(); ?>
                                <div class="modal fade text-left" id="defaultSize" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel18" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel18"><i class="fa fa-camera"></i>
                                                    Take
                                                    Picture
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body d-flex justify-content-center align-items-center">
                                                <div class="camera"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn grey btn-outline-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-outline-primary"
                                                    onclick="snapShot()">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-body">
                                    <table width="100%" border="0" cellspacing="2" cellpadding="0"
                                        class="table table-responsive">
                                        <tbody>
                                            <tr>
                                                <td><b>Employee Code</b></td>
                                                <td><input name="employeecode" id="employeecode" type="text"
                                                        class="form-control" value="<?php echo e($employeeCode); ?>" readonly=""></td>
                                                <td></td>
                                                <td align="right" valign="top"><button type="button" data-toggle="modal"
                                                        data-target="#defaultSize" class="btn-solid btn open-camera"
                                                        onclick="openCamera()"><img
                                                            src="../../../app-assets/images/profiles/profilepic.jpg"
                                                            class="image-taken" alt="Employee Picture" width="150"
                                                            height="150"
                                                            style="border: 1px solid gray; margin-left: 10px"></button>
                                                </td>
                                            </tr>
                                            <tr>
                                                <input type="hidden" name="employee_image" class="patient-image">
                                                <input type="hidden" name="signature" id="signature_data">
                                                <td><b>Last Name</b></td>
                                                <td>
                                                    <input name="lastname" id="lastname" type="text"
                                                        class="form-control lastname" value="">
                                                </td>
                                                <td><b>First Name</b></td>
                                                <td>
                                                    <input name="firstname" id="firstname" type="text" class="form-control" value="">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Middle Name</b></td>
                                                <td><input name="middlename" id="middlename" type="text"
                                                        class="form-control" value=""></td>
                                                <td><b>Email</b></td>
                                                <td><input name="email" id="email" type="text" class="form-control" value="">
                                                    <span
                                                        class="danger text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Username</b></td>
                                                <td>
                                                    <div id="uservalid"></div>
                                                    <input name="username" id="username" type="text"
                                                        class="form-control" value="">
                                                </td>
                                                <td><b>Password</b></td>
                                                <td>
                                                    <input name="password" id="password" type="password"
                                                        class="form-control" value="">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Title</b></td>
                                                <td><input name="title" id="title" type="text" class="form-control" value="">
                                            </td>
                                            </tr>
                                            <tr>
                                                <td><b>Position</b></td>
                                                <td><input name="position" id="position" type="text"
                                                        class="form-control" value=""></td>
                                            </tr>
                                            <tr>
                                                <td><b>Old Code</b></td>
                                                <td><input name="oldcode" id="oldcode" type="oldcode"
                                                        class="form-control" value=""></td>
                                                <td><b>License No./Certificate No./PRC No.</b></td>
                                                <td><input name="license_no" id="license_no" type="number"
                                                        class="form-control" value=""></td>
                                            </tr>
                                            <tr>
                                                <td><b>Address</b></td>
                                                <td><input name="address" id="address" type="text" class="form-control"
                                                        value=""></td>
                                                <td> <b>Contact No.</b></td>
                                                <td><input name="contactno" id="address" type="text"
                                                        class="form-control" value=""></td>
                                            </tr>
                                            <tr>
                                                <td><b>Other Position</b></td>
                                                <td><input name="otherposition" id="address" type="text"
                                                        class="form-control" value=""></td>
                                                <td><b> Religion</b></td>
                                                <td><input name="religion" id="address" type="text" class="form-control"
                                                        value=""></td>
                                            </tr>
                                            <tr>
                                                <td><b>Gender</b></td>
                                                <td>
                                                    <select name="gender" id="address" type="text" class="form-control"
                                                        value="">
                                                        <option value="Male">Male</option>
                                                        <option value="Female">Female</option>
                                                    </select>
                                                </td>
                                                <td><b> Marital Status</b></td>
                                                <td><select name="maritalstatus" id="address" type="text"
                                                        class="form-control" value="">
                                                        <option value="">Select Civil Status</option>
                                                        <option value="Single">Single</option>
                                                        <option value="Married">Married</option>
                                                        <option value="Widowed">Widowed</option>
                                                        <option value="Divorced">Divorced</option>
                                                        <option value="Domestic Relationship">Domestic
                                                            Relationship</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Birthdate</b></td>
                                                <td><input name="birthdate" id="address" type="date" max="2050-12-31"
                                                        class="form-control" value=""></td>
                                                <td><b>Birthplace</b></td>
                                                <td><input name="birthplace" id="address" type="text"
                                                        class="form-control" value=""></td>
                                            </tr>
                                            <tr>
                                                <td valign="top"><b>Signature</b></td>
                                                <td>
                                                    <div class="d-flex flex-column my-2 mx-4">
                                                        <canvas class="signature"></canvas>
                                                        <button type='button'
                                                            class="btn btn-solid btn-primary clear-signature my-1">Clear</button>
                                                    </div>
                                                </td>

                                                <td><b>Department</b></td>
                                                <td>
                                                    <select name="dept" id="" class="form-control select2">
                                                        <option value="">Select Department</option>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="box-footer">
                                    <button name="action" value="save" type="submit" onclick=""
                                        class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../../../app-assets/js/scripts/signature_pad-master/js/signature_pad.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script src="../../../app-assets/js/scripts/custom.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Employee/add-employee.blade.php ENDPATH**/ ?>