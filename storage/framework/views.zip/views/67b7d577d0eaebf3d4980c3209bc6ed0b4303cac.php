

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Add ECG</h3>
                            <a href="patient_edit?id=<?php echo e($admission->patient_id); ?>&patientcode=<?php echo e($admission->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/store_ecg" role="form">
                            <?php if(Session::get('status')): ?>
                            <div class="success alert-success p-2 my-2">
                                <?php echo e(Session::get('status')); ?>

                            </div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input required required required type="hidden" name="id" value="<?php echo e($admission->id); ?>">
                            <input type="hidden" name="patient_id" value="<?php echo e($admission->patient_id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input required required required name="peme_date" type="text"
                                                id="peme_date" value="<?php echo e($admission->trans_date); ?>" class="form-control"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input required required required name="admission_id" type="text"
                                                    id="admission_id" value="<?php echo e($admission->id); ?>"
                                                    class="form-control input required required-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input required required required name="trans_date" type="text"
                                                id="trans_date" value="<?php echo date(
                                    'Y-m-d'
                                ); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input required required required name="patientname" id="patientname"
                                                type="text"
                                                value="<?php echo e($admission->lastname . ", " . $admission->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input required required required name="patientcode" id="patientcode"
                                                type="text" value="<?php echo e($admission->patientcode); ?>" class="form-control"
                                                readonly=""></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="12%"><b>Otoscopy:</b></td>
                                        <td width="88%">
                                            <input name="otoscopy" type="text" id="otoscopy" value="" size="15"
                                                class="form-control" placeholder="Otoscopy">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Heart:</b></td>
                                        <td>
                                            <input name="heart" type="text" id="heart" value="" size="15"
                                                class="form-control" placeholder="Heart">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Lung:</b></td>
                                        <td>
                                            <input name="lung" type="text" id="lung" value="" size="15"
                                                class="form-control" placeholder="Lung">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><b>ECG Result:</b></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input required type="radio" name="ecg" id="radio" value="Normal">
                                            Normal
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input required type="radio" name="ecg" id="radio" value="Significant Findings">
                                            Significant Findings
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input required type="radio" name="ecg" id="radio" value="Not Required">
                                            Not Required
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input required type="radio" name="ecg" id="radio"
                                                value="Clinically Not Significant">
                                            Clinically Not Significant
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal">Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings">With Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td><b>Nurse: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option value="">--SELECT--</option>
                                                                    <option value="11" selected="">Pinky Jay C. Junio,
                                                                        R.N.</option>
                                                                    <option value="17">Jennifer Joy C. Velete, RN
                                                                    </option>
                                                                    <option value="52">Nanette D. Cabiserano</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="24%"><b>Physician</b></td>
                                                        <td width="76%">
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option value="15">Charisse Nicole F. Gonzales, M.D.
                                                                    </option>
                                                                    <option value="26">Alexander Cabungcal, MD</option>
                                                                    <option value="27">Emma Y. Chua, MD</option>
                                                                    <option value="28">Erick A. Ho, MD</option>
                                                                    <option value="29">Ana Maria Luisa Javier, MD
                                                                    </option>
                                                                    <option value="30">Ethel . Mabbagu, M.D.</option>
                                                                    <option value="32">Elizabeth C. Paulo, M.D.</option>
                                                                    <option value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                    <option value="34">Ricardo Tabinga, MD</option>
                                                                    <option value="39">Renelene Macabeo, MD</option>
                                                                    <option value="40">Mary Christine G. Fillarca, MD
                                                                    </option>
                                                                    <option value="46">admin a. admin, DR.</option>
                                                                    <option value="49">Renelene A. Macabeo, M.D.
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/ECG/add-ecg.blade.php ENDPATH**/ ?>