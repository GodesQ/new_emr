

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('exam'); ?>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .table td {
        font-size: 11px;
    }
    .table th,
    .table td {
        padding: 0.5rem;
    }
</style>
<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <!-- users view start -->
            <?php if(Session::get('yellow_card_success')): ?>
                <script>
                    window.open('/yellow_card_print?id=<?php echo e($patient->id); ?>','wp','width=1000,height=800');
                </script>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-9 order-lg-2 order-xl-1 order-sm-2 order-xs-2 col-lg-12 col-sm-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="account-vertical-general"
                            aria-labelledby="account-pill-general" aria-expanded="true">
                            <section class="users-view">
                                <!-- users view media object start -->
                                <div class="row bg-white p-2">
                                    <?php if(Session::get('status')): ?>
                                    <?php $__env->startPush('scripts'); ?>
                                    <script>
                                    toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                    <?php $__env->stopPush(); ?>
                                    <?php endif; ?>
                                    <div class="col-md-6">
                                        <h3>Medical Records</h3>
                                        <?php $__currentLoopData = $patientRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <button
                                            onclick="location.href = 'patient_edit?id=<?php echo e($record->id); ?>&patientcode=<?php echo e($record->patientcode); ?>'"
                                            class="btn btn-outline-secondary mr-1"><?php echo e($record->created_date); ?></button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php echo $__env->yieldContent('content'); ?>
                                <div class="modal fade text-left" id="defaultSize" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel18" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel18"><i class="fa fa-camera"></i>
                                                    Take
                                                    Picture
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body d-flex justify-content-center align-items-center">
                                                <div class="camera"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn grey btn-outline-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-outline-primary"
                                                    onclick="snapShot()">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="largeSize" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel18" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content modal-lg">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel18"><i class="fa fa-camera"></i>
                                                    Take
                                                    Picture
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body d-flex justify-content-center align-items-center">
                                                <div class="camera"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn grey btn-outline-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-outline-primary"
                                                    onclick="snapShot()">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="card">
                                        <div class="card-content">
                                            <div class="card-body">
                                                <ul class="nav nav-tabs nav-linetriangle" role="tablist">
                                                    <li class="nav-item">
                                                        <a class="nav-link <?php echo session()->get('dept_id') == " 1"
                                                            || session()->get('dept_id') == "17"
                                                            ? "active" : "" ?>" id="baseIcon-tab31"
                                                            data-toggle="tab" aria-controls="tabIcon31"
                                                            href="#tabIcon31" role="tab"><i class="fa fa-user"></i>User
                                                            Info</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" id="baseIcon-tab32" data-toggle="tab"
                                                            aria-controls="tabIcon32" href="#tabIcon32" role="tab"><i
                                                                class="fa fa-globe"></i>
                                                            Agency Info</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" id="baseIcon-tab33" data-toggle="tab"
                                                            aria-controls="tabIcon33" href="#tabIcon33" role="tab"><i
                                                                class="fa fa-list-alt"></i>Medical History</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" id="baseIcon-tab34" data-toggle="tab"
                                                            aria-controls="tabIcon34" href="#tabIcon34" role="tab"><i
                                                                class="fa fa-bars"></i>Declaration Form</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link <?php echo session()->get('dept_id') != " 1"
                                                            && session()->get('dept_id') != "17"
                                                            ? "active" : "" ?>" id="baseIcon-tab35"
                                                            data-toggle="tab" aria-controls="tabIcon35"
                                                            href="#tabIcon35" role="tab"><i class="fa fa-file"></i>Basic
                                                            Exams</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" id="baseIcon-tab36" data-toggle="tab"
                                                            aria-controls="tabIcon36" href="#tabIcon36" role="tab"><i
                                                                class="fa fa-file"></i>Lab
                                                            Exams</a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content px-1 pt-1">
                                                    <div class="tab-pane <?php echo session()->get('dept_id') == " 1" ||
                                                        session()->get('dept_id') == "17"
                                                        ? "active" : "" ?>" id="tabIcon31" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab31">
                                                        <fieldset class="my-2">
                                                            <form action="#" id="update_patient_basic" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="old_signature"
                                                                    id="old_signature"
                                                                    value="<?php echo e($patient->patient_signature); ?>">
                                                                <input type="hidden" name="signature"
                                                                    id="signature_data">
                                                                <input type="hidden" name="main_id"
                                                                    value="<?php echo e($patient->id); ?>">
                                                                <input type="hidden" name="old_image"
                                                                    value="<?php echo e($patient->patient_image); ?>">
                                                                <input type="hidden" name="patientcode"
                                                                    value="<?php echo e($patient->patientcode); ?>">
                                                                <input type="hidden" class="patient-image"
                                                                    name="patient_image"
                                                                    value="<?php echo e($patient->patient_image); ?>">
                                                                <div
                                                                    class="col-md-8 d-flex justify-content align-items-center">
                                                                    <img class=" image-taken"
                                                                        src="../../../app-assets/images/profiles/profilepic.jpg" />
                                                                    <div class="d-flex flex-column my-2 mx-4">
                                                                        <canvas class="signature"></canvas>
                                                                        <button type='button'
                                                                            class="btn btn-solid btn-primary clear-signature">Clear</button>
                                                                    </div>
                                                                </div>
                                                                <div class="modal fade text-left" id="xlarge" tabindex="-1" role="dialog" aria-labelledby="myModalLabel16" aria-hidden="true">
                                                                    <div class="modal-dialog modal-xl" role="document">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <h4 class="modal-title" id="myModalLabel16">Signature</h4>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                    <span aria-hidden="true">&times;</span>
                                                                                </button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <canvas class="signature" width="939" height="400" style="margin: 0px; padding: 0px; border: 1px solid black; height: 400px; width: 100%;"></canvas>
                                                                                <!-- <button type='button' class="btn btn-solid btn-primary clear-signature">Clear</button> -->
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type='button' class="btn btn-solid btn-primary clear-signature">Clear</button>
                                                                                <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
                                                                                <button type="button" class="btn btn-outline-primary">Save changes</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class=" row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="firstName3">
                                                                                First Name :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" id="firstName3"
                                                                                name="firstName"
                                                                                value="<?php echo e($patient->firstname); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="lastName3">
                                                                                Last Name :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control lastname"
                                                                                id="lastName3" name="lastName"
                                                                                value="<?php echo e($patient->lastname); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="lastName3">
                                                                                Middle Name :
                                                                            </label>
                                                                            <input type="text" class="form-control"
                                                                                name="middleName"
                                                                                value="<?php echo e($patient->middlename); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Home Address (Street, Municipality) :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="homeAddress"
                                                                                value="<?php echo e($patientInfo->address); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Email :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="email"
                                                                                value="<?php echo e($patient->email); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class=" col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Age :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="number"
                                                                                class="form-control" name="age"
                                                                                value="<?php echo e($patient->age); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class=" col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Birthdate :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="date" max="2050-12-31"
                                                                                class="form-control" name="birthdate"
                                                                                value="<?php echo e($patientInfo->birthdate); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Birthplace :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="birthplace"
                                                                                value="<?php echo e($patientInfo->birthplace); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Civil Status :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <select required class="form-control"
                                                                                name="civilStatus">
                                                                                <option
                                                                                    value="<?php echo e($patientInfo->maritalstatus); ?>">
                                                                                    <?php echo e($patientInfo->maritalstatus); ?>

                                                                                </option>
                                                                                <option value="Single">Single</option>
                                                                                <option value="Married">Married</option>
                                                                                <option value="Widowed">Widowed</option>
                                                                                <option value="Divorced">Divorced
                                                                                </option>
                                                                                <option value="Domestic Relationship">
                                                                                    Domestic
                                                                                    Relationship</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Occupation :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="occupation"
                                                                                value="<?php echo e($patientInfo->occupation); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Gender :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <select required class="form-control"
                                                                                name="gender">
                                                                                <option value="<?php echo e($patient->gender); ?>">
                                                                                    <?php echo e($patient->gender); ?></option>
                                                                                <option value="Male">Male</option>
                                                                                <option value="Female">Female</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Nationality :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="nationality"
                                                                                value="<?php echo e($patientInfo->nationality); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Religion :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="religion"
                                                                                value="<?php echo e($patientInfo->religion); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Phone Number :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="tel"
                                                                                class="form-control" name="phoneNumber"
                                                                                value="<?php echo e($patientInfo->contactno); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <input type="date" max="2050-12-31" name="date" id="" hidden value="<?php echo date('Y-m-d'); ?>">
                                                                    <div class="col-12">
                                                                        <button type="submit"
                                                                            class="btn btn-solid btn-primary">Submit</button>
                                                                    </div>
                                                                </fieldset>
                                                        </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabIcon32" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab32">
                                                        <form id="update_patient_agency" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="main_id"
                                                                value="<?php echo e($patient->id); ?>">
                                                            <fieldset>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="firstName3">
                                                                                Name of Agency :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <select class="form-control select2"
                                                                                name="agency_id">
                                                                                <?php if($patient_agency): ?>
                                                                                <option value="<?php echo e($patient_agency->id); ?>">
                                                                                    <?php echo e($patient_agency->agencyname); ?>

                                                                                </option>
                                                                                <?php endif; ?>
                                                                                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($row->id); ?>">
                                                                                    <?php echo e($row->agencyname); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="firstName3">
                                                                                Address of Agency :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control"
                                                                                name="address_of_agency"
                                                                                value="<?php echo e($patientInfo->agency_address); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="lastName3">
                                                                                Country of Destination :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control"
                                                                                name="countryDestination"
                                                                                value="<?php echo e($patientInfo->country_destination); ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Vessel :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control" name="vessel"
                                                                                value="<?php echo e($patientInfo->vessel); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Passport :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                value="<?php echo e($patientInfo->passportno); ?>"
                                                                                class="form-control" name="passportNo">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Passport Expiration Date :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="date" max="2050-12-31"
                                                                                value="<?php echo e($patientInfo->passport_expdate); ?>"
                                                                                class="form-control"
                                                                                name="passport_expdate">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                SSRB # :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                value="<?php echo e($patientInfo->srbno); ?>"
                                                                                class="form-control" name="ssrb">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                SSRB Expiration Date :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="date" max="2050-12-31"
                                                                                value="<?php echo e($patientInfo->srb_expdate); ?>"
                                                                                class="form-control" name="srb_expdate">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Medical Package Test :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <select name="medicalPackage" id=""
                                                                                class="form-control select2">
                                                                                <?php if($patient_package): ?>
                                                                                <option value="<?php echo e($patient_package->id); ?>"
                                                                                    selected>
                                                                                    <?php echo e($patient_package->packagename); ?>

                                                                                </option>
                                                                                <?php endif; ?>
                                                                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($package->id); ?>">
                                                                                    <?php echo e($package->packagename); ?>

                                                                                    (<?php echo e($package->agencyname); ?>)</option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Position Applied for :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <input required type="text"
                                                                                class="form-control"
                                                                                name="positionApplied"
                                                                                value="<?php echo e($patient->position_applied); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Category :
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <select id="projectInput6" name="category"
                                                                                class="form-control">
                                                                                <option value="none" selected=""
                                                                                    disabled="">Select
                                                                                    Category
                                                                                </option>
                                                                                <option value="DECK SERVICES" <?php echo
                                                                                    $patientInfo->
                                                                                    category == "DECK SERVICES" ?
                                                                                    "selected" : null
                                                                                    ?>>DECK SERVICES</option>
                                                                                <option value="ENGINE SERVICES" <?php
                                                                                    echo $patientInfo->
                                                                                    category == "ENGINE SERVICES" ?
                                                                                    "selected" : null
                                                                                    ?>>ENGINE SERVICES</option>
                                                                                <option value="CATERING SERVICES" <?php
                                                                                    echo $patientInfo->category ==
                                                                                    "CATERING SERVICES" ?
                                                                                    "selected" : null ?>>CATERING
                                                                                    SERVICES</option>
                                                                                <option value="OTHER SERVICES" <?php echo
                                                                                    $patientInfo->
                                                                                    category == "OTHER SERVICES" ?
                                                                                    "selected" : null
                                                                                    ?>>OTHER SERVICES</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label class="text-bold-600"
                                                                                for="projectinput2">Admission
                                                                                Type</label>
                                                                            <div class="container-fluid ">
                                                                                <div
                                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                                    <input type="radio"
                                                                                        class="custom-control-input"
                                                                                        id="admit_type3"
                                                                                        name="admit_type" value="Normal"
                                                                                        <?php echo
                                                                                        $patientInfo->admission_type ==
                                                                                    "Normal" ? "checked" : "" ?>>
                                                                                    <label class="custom-control-label"
                                                                                        for="admit_type3">Regular
                                                                                        Patient</label>
                                                                                </div>
                                                                                <div
                                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                                    <input type="radio"
                                                                                        class="custom-control-input"
                                                                                        id="admit_type4"
                                                                                        name="admit_type" value="Rush"
                                                                                        <?php echo
                                                                                        $patientInfo->admission_type ==
                                                                                    "Rush" ? "checked" : "" ?>>
                                                                                    <label class="custom-control-label"
                                                                                        for="admit_type4">Rush
                                                                                        Patient</label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label class="text-bold-600"
                                                                                for="projectinput2">Payment
                                                                                Type <span
                                                                                    class="danger">*</span></label>
                                                                            <div class="container-fluid ">
                                                                                <div
                                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                                    <input type="radio"
                                                                                        class="custom-control-input"
                                                                                        name="payment_type"
                                                                                        id="payment_type1"
                                                                                        value="Applicant Paid" <?php echo
                                                                                        $patientInfo->payment_type ==
                                                                                    "Applicant Paid" ? "checked" : ""
                                                                                    ?>>
                                                                                    <label class="custom-control-label"
                                                                                        for="payment_type1">Applicant
                                                                                        Paid
                                                                                    </label>
                                                                                </div>
                                                                                <div
                                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                                    <input type="radio"
                                                                                        class="custom-control-input"
                                                                                        id="payment_type2"
                                                                                        name="payment_type"
                                                                                        value="Billed" <?php echo
                                                                                        $patientInfo->payment_type ==
                                                                                    "Billed" ? "checked" : "" ?>>
                                                                                    <label class="custom-control-label"
                                                                                        for="payment_type2">Billed to
                                                                                        Agency</label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <button type="submit"
                                                                            class="btn btn-solid btn-primary">Submit</button>
                                                                    </div>
                                                                </div>

                                                            </fieldset>
                                                        </form>
                                                    </div>
                                                    <div class="tab-pane" id="tabIcon33" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab33">
                                                        <fieldset>
                                                            <form method="POST" id="update_patient_medical_history">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="main_id"
                                                                    value="<?php echo e($patient->id); ?>">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <table
                                                                            class="table table-striped medical-table">
                                                                            <tbody>
                                                                                <?php if($medicalHistory == null): ?>
                                                                                <td>
                                                                                    No Records Found
                                                                                </td>
                                                                                <?php else: ?>
                                                                                <tr>
                                                                                    <th>Head and Neck Injury</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="head_and_neck_injury"
                                                                                                    id="head_and_neck_injury1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->head_and_neck_injury
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="head_and_neck_injury1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="head_and_neck_injury"
                                                                                                    id="head_and_neck_injury2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->head_and_neck_injury
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="head_and_neck_injury2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Frequent Headache</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="frequent_head_ache"
                                                                                                    id="frequent_head_ache1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->frequent_headache
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="frequent_head_ache1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="frequent_head_ache"
                                                                                                    id="frequent_head_ache2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->frequent_headache
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="frequent_head_ache2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Frequent Dizziness</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="frequent_dizziness"
                                                                                                    id="frequent_dizziness1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->frequent_dizziness
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="frequent_dizziness1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="frequent_dizziness"
                                                                                                    id="frequent_dizziness2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->frequent_dizziness
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="frequent_dizziness2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Fainting Spells, Fits</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="fainting_spells"
                                                                                                    id="fainting_spells1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->fainting_spells_fits
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="fainting_spells1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="fainting_spells"
                                                                                                    id="fainting_spells2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->fainting_spells_fits
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="fainting_spells2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Seizures</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="seizures"
                                                                                                    id="seizures1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->seizures
                                                                                                ==
                                                                                                1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="seizures1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="seizures"
                                                                                                    id="seizures2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->seizures
                                                                                                ==
                                                                                                0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="seizures2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Other neurological disorders
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_neurological_disorders"
                                                                                                    id="other_neurological_disorders1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_neurological_disorders
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_neurological_disorders1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_neurological_disorders"
                                                                                                    id="other_neurological_disorders2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_neurological_disorders
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_neurological_disorders2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Insomia or Sleep disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="insomia_or_sleep_disorder"
                                                                                                    id="insomia_or_sleep_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->insomia_or_sleep_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="insomia_or_sleep_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="insomia_or_sleep_disorder"
                                                                                                    id="insomia_or_sleep_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->insomia_or_sleep_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="insomia_or_sleep_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Depression, other mental
                                                                                        disorder
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="depression_or_other_mental_disorder"
                                                                                                    id="depression_or_other_mental_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->depression_other_mental_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="depression_or_other_mental_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="depression_or_other_mental_disorder"
                                                                                                    id="depression_or_other_mental_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->depression_other_mental_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="depression_or_other_mental_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Eye problems / Error of
                                                                                        refraction
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="eye_problems_or_error_of_refraction"
                                                                                                    id="eye_problems_or_error_of_refraction1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->eye_problems_or_error_refraction
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="eye_problems_or_error_of_refraction1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="eye_problems_or_error_of_refraction"
                                                                                                    id="eye_problems_or_error_of_refraction2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->eye_problems_or_error_refraction
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="eye_problems_or_error_of_refraction2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Deafness / Ear disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="deafness_or_ear_disorder"
                                                                                                    id="deafness_or_ear_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->deafness_or_ear_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="deafness_or_ear_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="deafness_or_ear_disorder"
                                                                                                    id="deafness_or_ear_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->deafness_or_ear_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="deafness_or_ear_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Nose or Throat disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="nose_or_throat_disorder"
                                                                                                    id="nose_or_throat_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->nose_or_throat_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="nose_or_throat_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="nose_or_throat_disorder"
                                                                                                    id="nose_or_throat_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->nose_or_throat_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="nose_or_throat_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Tuberculosis</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="tuberculosis"
                                                                                                    id="tuberculosis1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->tuberculosis
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="tuberculosis1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="tuberculosis"
                                                                                                    id="tuberculosis2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->tuberculosis
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="tuberculosis2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Signed off as sick</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="signed_off_as_sick"
                                                                                                    id="signed_off_as_sick1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->signed_off_as_sick
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="signed_off_as_sick1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="signed_off_as_sick"
                                                                                                    id="signed_off_as_sick2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->signed_off_as_sick
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="signed_off_as_sick2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Repatriation form ship</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="repatriation_form_ship"
                                                                                                    id="repatriation_form_ship1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->signed_off_as_sick
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="repatriation_form_ship1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="repatriation_form_ship"
                                                                                                    id="repatriation_form_ship2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->signed_off_as_sick
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="repatriation_form_ship2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Declared Unfit for sea duty</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="declared_unfit_for_sea_duty"
                                                                                                    id="declared_unfit_for_sea_duty1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->declared_unfit_for_sea_duty
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="declared_unfit_for_sea_duty1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="declared_unfit_for_sea_duty"
                                                                                                    id="declared_unfit_for_sea_duty2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->declared_unfit_for_sea_duty
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="declared_unfit_for_sea_duty2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Previous Hospitalization</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="previous_hospitalization"
                                                                                                    id="previous_hospitalization1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->previous_hospitalization
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="previous_hospitalization1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="previous_hospitalization"
                                                                                                    id="previous_hospitalization2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->previous_hospitalization
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="previous_hospitalization2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Do you feel healthy /<br>Fit to
                                                                                        perform
                                                                                        duties of <br> designed position
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="feel_healthy"
                                                                                                    id="feel_healthy1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->feel_healthy
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="feel_healthy1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="feel_healthy"
                                                                                                    id="feel_healthy2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->feel_healthy
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="feel_healthy2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                        </table>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <table
                                                                            class="table table-striped col-md-12  medical-table">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <th>Other Lung disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_lung_disorder"
                                                                                                    id="other_lung_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_lung_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_lung_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_lung_disorder"
                                                                                                    id="other_lung_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_lung_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_lung_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>High Blood Pressure</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="high_blood_pressure"
                                                                                                    id="high_blood_pressure1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->high_blood_pressure
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="high_blood_pressure1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="high_blood_pressure"
                                                                                                    id="high_blood_pressure2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->high_blood_pressure
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="high_blood_pressure2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Heart Disease / Vascular</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="heart_disease_or_vascular"
                                                                                                    id="heart_disease_or_vascular1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->heart_disease_or_vascular
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="heart_disease_or_vascular1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="heart_disease_or_vascular"
                                                                                                    id="heart_disease_or_vascular2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->heart_disease_or_vascular
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="heart_disease_or_vascular2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Chest pain</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="chest_pain"
                                                                                                    id="chest_pain1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->chest_pain
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="chest_pain1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="chest_pain"
                                                                                                    id="chest_pain2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->chest_pain
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="chest_pain2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Rheumatic Fever</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="rheumatic_fever"
                                                                                                    id="rheumatic_fever1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->rheumatic_fever
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="rheumatic_fever1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="rheumatic_fever"
                                                                                                    id="rheumatic_fever2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->rheumatic_fever
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="rheumatic_fever2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Diabetes Mellitus</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="diabetes_mellitus"
                                                                                                    id="diabetes_mellitus1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->diabetes_mellitus
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="diabetes_mellitus1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="diabetes_mellitus"
                                                                                                    id="diabetes_mellitus2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->diabetes_mellitus
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="diabetes_mellitus2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Endocrine disorders (goiter)
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="endocrine_disorders"
                                                                                                    id="endocrine_disorders1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->endocrine_disorders
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="endocrine_disorders1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="endocrine_disorders"
                                                                                                    id="endocrine_disorders2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->endocrine_disorders
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="endocrine_disorders2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Cancer or Tumor</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="cancer_or_tumor"
                                                                                                    id="cancer_or_tumor1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->cancer_or_tumor
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="cancer_or_tumor1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="cancer_or_tumor"
                                                                                                    id="cancer_or_tumor2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->cancer_or_tumor
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="cancer_or_tumor2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Blood disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="blood_disorder"
                                                                                                    id="blood_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->blood_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="blood_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="blood_disorder"
                                                                                                    id="blood_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->blood_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="blood_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Stomach pain, Gastritis</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="stomach_pain_or_gastritis"
                                                                                                    id="stomach_pain_or_gastritis1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->stomach_pain_or_gastritis
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="stomach_pain_or_gastritis1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="stomach_pain_or_gastritis"
                                                                                                    id="stomach_pain_or_gastritis2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->stomach_pain_or_gastritis
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="stomach_pain_or_gastritis2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Ulcer</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="ulcer"
                                                                                                    id="ulcer1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->ulcer
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="ulcer1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="ulcer"
                                                                                                    id="ulcer2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->ulcer
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="ulcer2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Other Abdominal Disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_abdominal_disorder"
                                                                                                    id="other_abdominal_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_abdominal_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_abdominal_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="other_abdominal_disorder"
                                                                                                    id="other_abdominal_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->other_abdominal_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="other_abdominal_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Medical certificate restricted
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="medical_certificate_restricted"
                                                                                                    id="medical_certificate_restricted1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->medical_certificate_restricted
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="medical_certificate_restricted1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="medical_certificate_restricted"
                                                                                                    id="medical_certificate_restricted2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->medical_certificate_restricted
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="medical_certificate_restricted2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Medical certificate revoked</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="medical_certificate_revoked"
                                                                                                    id="medical_certificate_revoked1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->medical_certificate_revoked
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="medical_certificate_revoked1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="medical_certificate_revoked"
                                                                                                    id="medical_certificate_revoked2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->medical_certificate_revoked
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="medical_certificate_revoked2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Aware of any medical problems
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="aware_of_medical_problems"
                                                                                                    id="aware_of_medical_problems1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->aware_of_any_medical_problems
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="aware_of_medical_problems1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="aware_of_medical_problems"
                                                                                                    id="aware_of_medical_problems2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->aware_of_any_medical_problems
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="aware_of_medical_problems2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Aware of any disease / illness
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="aware_of_any_disease_or_illness"
                                                                                                    id="aware_of_any_disease_or_illness1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->aware_of_any_disease_or_illness
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="aware_of_any_disease_or_illness1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="aware_of_any_disease_or_illness"
                                                                                                    id="aware_of_any_disease_or_illness2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->aware_of_any_disease_or_illness
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="aware_of_any_disease_or_illness2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Operation(s)</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="operation"
                                                                                                    id="operation1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->operations
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="operation1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="operation"
                                                                                                    id="operation2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->operations
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="operation2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                        </table>
                                                                    </div>
                                                                    <div class="col-md-12">
                                                                        <table
                                                                            class="table table-striped col-md-12 medical-table">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <th>Gynecological Disorders</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="gynecological_disorder"
                                                                                                    id="gynecological_disorders1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->gynecological_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="gynecological_disorders1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="gynecological_disorder"
                                                                                                    id="gynecological_disorders2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->gynecological_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="gynecological_disorders2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Last Menstrual Period</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="last_menstrual_period"
                                                                                                    id="last_menstrual_period1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->last_menstrual_period
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="last_menstrual_period1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="last_menstrual_period"
                                                                                                    id="last_menstrual_period2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->last_menstrual_period
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="last_menstrual_period2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Pregnancy</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="pregnancy"
                                                                                                    id="pregnancy1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->pregnancy
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="pregnancy1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="pregnancy"
                                                                                                    id="pregnancy2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->pregnancy
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="pregnancy2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Kidney or Bladder Disorder</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="kidney_or_bladder_disorder"
                                                                                                    id="kidney_or_bladder_disorder1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->kidney_or_bladder_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="kidney_or_bladder_disorder1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="kidney_or_bladder_disorder"
                                                                                                    id="kidney_or_bladder_disorder2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->kidney_or_bladder_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="kidney_or_bladder_disorder2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Back Injury / Joint pain</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="back_injury_or_joint_pain"
                                                                                                    id="back_injury_or_joint_pain1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->back_injury_or_joint_pain
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="back_injury_or_joint_pain1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="back_injury_or_joint_pain"
                                                                                                    id="back_injury_or_joint_pain2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->back_injury_or_joint_pain
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="back_injury_or_joint_pain2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Arthritis</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="arthritis"
                                                                                                    id="arthritis1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->arthritis
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="arthritis1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="arthritis"
                                                                                                    id="arthritis2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->arthritis
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="arthritis2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Genetic, Heredity or Familial
                                                                                        Dis.
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="genetic_or_heredity_or_familial_dis"
                                                                                                    id="genetic_or_heredity_or_familial_dis1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->genetic_heredity_or_familial_dis
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>s>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="genetic_or_heredity_or_familial_dis1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="genetic_or_heredity_or_familial_dis"
                                                                                                    id="genetic_or_heredity_or_familial_dis2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->genetic_heredity_or_familial_dis
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="genetic_or_heredity_or_familial_dis2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Sexually Transmitted Disease
                                                                                        (Syphilis)
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="sexually_transmitted_disease"
                                                                                                    id="sexually_transmitted_disease1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->sexually_transmitted_disease
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="sexually_transmitted_disease1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="sexually_transmitted_disease"
                                                                                                    id="sexually_transmitted_disease2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->sexually_transmitted_disease
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="sexually_transmitted_disease2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Tropical Disease - Malaria</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="tropical_disease"
                                                                                                    id="tropical_disease1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->tropical_disease_or_malaria
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="tropical_disease1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="tropical_disease"
                                                                                                    id="tropical_disease2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->tropical_disease_or_malaria
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="tropical_disease2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Thypoid Fever</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="thypoid_fever"
                                                                                                    id="thypoid_fever1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->thypoid_fever
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="thypoid_fever1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="thypoid_fever"
                                                                                                    id="thypoid_fever2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->thypoid_fever
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="thypoid_fever2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Schistosomiasis</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="schistosomiasis"
                                                                                                    id="schistosomiasis1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->depression_other_mental_disorder
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="schistosomiasis1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="schistosomiasis"
                                                                                                    id="schistosomiasis2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->depression_other_mental_disorder
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="schistosomiasis2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Asthma</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="asthma"
                                                                                                    id="asthma1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->asthma
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="asthma1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="asthma"
                                                                                                    id="asthma2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->asthma
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="asthma2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Allergies</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="allergies"
                                                                                                    id="allergies1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->allergies
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="allergies1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="allergies"
                                                                                                    id="allergies2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->allergies
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="allergies2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Smoking</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="smoking"
                                                                                                    id="smoking1" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->smoking
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="smoking1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="smoking"
                                                                                                    id="smoking2" <?php
                                                                                                    echo
                                                                                                    $medicalHistory->smoking
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="smoking2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Taking medication for
                                                                                        Hypertension
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="taking_medication_for_hypertension"
                                                                                                    id="taking_medication_for_hypertension1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->taking_medication_for_hypertension
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="taking_medication_for_hypertension1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="taking_medication_for_hypertension"
                                                                                                    id="taking_medication_for_hypertension2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->taking_medication_for_hypertension
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="taking_medication_for_hypertension2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Taking medication for Diabetes
                                                                                    </th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="taking_medication_for_diabetes"
                                                                                                    id="taking_medication_for_diabetes1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->taking_medication_for_diabetes
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="taking_medication_for_diabetes1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="taking_medication_for_diabetes"
                                                                                                    id="taking_medication_for_diabetes2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->taking_medication_for_diabetes
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="taking_medication_for_diabetes2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Vaccination</th>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="1"
                                                                                                    class="custom-control-input required"
                                                                                                    name="vaccination"
                                                                                                    id="vaccination1"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->vaccination
                                                                                                == 1
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="vaccination1">YES</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                    <td>
                                                                                        <fieldset>
                                                                                            <div
                                                                                                class="custom-control custom-radio">
                                                                                                <input required
                                                                                                    type="radio"
                                                                                                    value="0"
                                                                                                    class="custom-control-input required"
                                                                                                    name="vaccination"
                                                                                                    id="vaccination2"
                                                                                                    <?php echo
                                                                                                    $medicalHistory->vaccination
                                                                                                == 0
                                                                                                ? "checked" : ""
                                                                                                ?>>
                                                                                                <label
                                                                                                    class="custom-control-label"
                                                                                                    for="vaccination2">NO</label>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </td>
                                                                                </tr>
                                                                                <?php endif; ?>
                                                                        </table>
                                                                    </div>
                                                                    <?php if($medicalHistory != null): ?>
                                                                    <div class="col-3">
                                                                        <button type="submit"
                                                                            class="btn btn-solid btn-primary">Submit</button>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </form>
                                                        </fieldset>
                                                    </div>
                                                    <div class="tab-pane" id="tabIcon34" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab34">
                                                        <?php if($declarationForm == null): ?>
                                                        <h3 class="text-center font-weight-regular my-2">
                                                            No Record Found
                                                        </h3>
                                                        <?php else: ?>
                                                        <fieldset>
                                                            <form id="update_patient_declaration_form" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="main_id"
                                                                    value="<?php echo e($patient->id); ?>">
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Have you travelled abroad recently?
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <fieldset>
                                                                                <div
                                                                                    class="custom-control custom-radio">
                                                                                    <input required type="radio"
                                                                                        class="custom-control-input required"
                                                                                        name="travelled_abroad_recently"
                                                                                        id="travelled_abroad_recently1"
                                                                                        value="1"
                                                                                        onchange="isTravelAbroadRecently(this)">
                                                                                    <label class="custom-control-label"
                                                                                        for="travelled_abroad_recently1">YES</label>
                                                                                </div>
                                                                            </fieldset>
                                                                            <fieldset>
                                                                                <div
                                                                                    class="custom-control custom-radio">
                                                                                    <input required type="radio"
                                                                                        value="0"
                                                                                        class="custom-control-input required"
                                                                                        name="travelled_abroad_recently"
                                                                                        id="travelled_abroad_recently2"
                                                                                        onchange="isTravelAbroadRecently(this)">
                                                                                    <label class="custom-control-label"
                                                                                        for="travelled_abroad_recently2">No</label>
                                                                                </div>
                                                                            </fieldset>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 travel isTravel">
                                                                        <div class="form-group">
                                                                            <label for="">Name of the area(s) visited
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <fieldset>
                                                                                <input name="area_visited" type="text"
                                                                                    id=""
                                                                                    placeholder="Country, State, City"
                                                                                    class="form-control"
                                                                                    value="<?php echo e($declarationForm->area_visited); ?>" />
                                                                            </fieldset>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 travel isTravel">
                                                                        <div class="form-group ">
                                                                            <label for="">Date of travel
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <label class="font-weight-bold"
                                                                                        for="">Arrival</label>
                                                                                    <input name="travel_arrival_date"
                                                                                        id="" placeholder=""
                                                                                        class="form-control" type="date" max="2050-12-31"
                                                                                        value="<?php echo e($declarationForm->travel_arrival); ?>" />
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <label class="font-weight-bold"
                                                                                        for="">Return</label>
                                                                                    <input name="travel_return_date"
                                                                                        id="" placeholder=""
                                                                                        class="form-control" type="date" max="2050-12-31"
                                                                                        value="<?php echo e($declarationForm->travel_return); ?>"
                                                                                        s />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    </hr>
                                                                    <div class="col-md-12 mt-2">
                                                                        <div class="form-group">
                                                                            <label for="">
                                                                                Have you been in contact with people
                                                                                being
                                                                                infected,
                                                                                suspected or diagnosed with COVID-19?
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <fieldset>
                                                                                <div
                                                                                    class="custom-control custom-radio">
                                                                                    <input required type="radio"
                                                                                        value="1"
                                                                                        class="custom-control-input required"
                                                                                        name="contact_with_people_being_infected_suspected_or_diagnosed_with_covid"
                                                                                        id="contact_with_people_being_infected_suspected_or_diagnosed_with_covid1"
                                                                                        onchange="hasContactWithPeopleInfected(this)">
                                                                                    <label class="custom-control-label"
                                                                                        for="contact_with_people_being_infected_suspected_or_diagnosed_with_covid1">YES</label>
                                                                                </div>
                                                                            </fieldset>
                                                                            <fieldset>
                                                                                <div
                                                                                    class="custom-control custom-radio">
                                                                                    <input required type="radio"
                                                                                        value="0"
                                                                                        class="custom-control-input required"
                                                                                        name="contact_with_people_being_infected_suspected_or_diagnosed_with_covid"
                                                                                        id="contact_with_people_being_infected_suspected_or_diagnosed_with_covid2"
                                                                                        onchange="hasContactWithPeopleInfected(this)">
                                                                                    <label class=" custom-control-label"
                                                                                        for="contact_with_people_being_infected_suspected_or_diagnosed_with_covid2">No</label>
                                                                                </div>
                                                                            </fieldset>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 mt-2 show-if-contact hide">
                                                                        <div class="form-group">
                                                                            <label for="">Your relationship with the
                                                                                people
                                                                                and
                                                                                your
                                                                                last contact date with them
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <label class="font-weight-bold"
                                                                                        for="">Relationship</label>
                                                                                    <input
                                                                                        name="relationship_with_last_people"
                                                                                        id="" placeholder=""
                                                                                        class="form-control" type="text"
                                                                                        value="<?php echo e($declarationForm->relationship_with_last_people); ?>" />
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <label class="font-weight-bold"
                                                                                        for="">Last
                                                                                        contact
                                                                                        date</label>
                                                                                    <input name="last_contact_date"
                                                                                        id="" placeholder=""
                                                                                        class="form-control" type="date" max="2050-12-31"
                                                                                        value="<?php echo e($declarationForm->last_contact_date); ?>" />

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 mt-2">
                                                                        <div class="form-group">
                                                                            <label for="">Please state whether you've
                                                                                experienced/are
                                                                                experiencing the following
                                                                                <span class="danger">*</span>
                                                                            </label>
                                                                            <div class="row">
                                                                                <table class="table table-striped ml-1">
                                                                                    <tr>
                                                                                        <th>Fever</th>
                                                                                        <td>
                                                                                            <fieldset>

                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="1"
                                                                                                        class="custom-control-input required"
                                                                                                        name="fever"
                                                                                                        id="fever1" <?php
                                                                                                        echo
                                                                                                        $declarationForm->fever
                                                                                                    == 1
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="fever1">YES</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="0"
                                                                                                        class="custom-control-input required"
                                                                                                        name="fever"
                                                                                                        id="fever2" <?php
                                                                                                        echo
                                                                                                        $declarationForm->fever
                                                                                                    == 0
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="fever2">NO</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th>Cough</th>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="1"
                                                                                                        class="custom-control-input required"
                                                                                                        name="cough"
                                                                                                        id="cough1" <?php
                                                                                                        echo
                                                                                                        $declarationForm->cough
                                                                                                    == 1
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="cough1">YES</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="0"
                                                                                                        class="custom-control-input required"
                                                                                                        name="cough"
                                                                                                        id="cough2" <?php
                                                                                                        echo
                                                                                                        $declarationForm->cough
                                                                                                    == 0
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="cough2">NO</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th>Shortness of Breath</th>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="1"
                                                                                                        class="custom-control-input required"
                                                                                                        name="shortness_of_breath"
                                                                                                        id="shortness_of_breath1"
                                                                                                        <?php echo
                                                                                                        $declarationForm->shortness_of_breath
                                                                                                    == 1
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="shortness_of_breath1">YES</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="0"
                                                                                                        class="custom-control-input required"
                                                                                                        name="shortness_of_breath"
                                                                                                        id="shortness_of_breath2"
                                                                                                        <?php echo
                                                                                                        $declarationForm->shortness_of_breath
                                                                                                    == 0
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="shortness_of_breath2">NO</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <th>Persistent Pain in the Chest
                                                                                        </th>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="1"
                                                                                                        class="custom-control-input required"
                                                                                                        name="persistent_pain_in_the_chest"
                                                                                                        id="persistent_pain_in_the_chest1"
                                                                                                        <?php echo
                                                                                                        $declarationForm->persistent_pain_in_chest
                                                                                                    == 1
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="persistent_pain_in_the_chest1">YES</label>
                                                                                                </div>
                                                                                            </fieldset>
                                                                                        </td>
                                                                                        <td>
                                                                                            <fieldset>
                                                                                                <div
                                                                                                    class="custom-control custom-radio">
                                                                                                    <input required
                                                                                                        type="radio"
                                                                                                        value="0"
                                                                                                        class="custom-control-input required"
                                                                                                        name="persistent_pain_in_the_chest"
                                                                                                        id="persistent_pain_in_the_chest2"
                                                                                                        <?php echo
                                                                                                        $declarationForm->persistent_pain_in_chest
                                                                                                    == 0
                                                                                                    ? "checked" : ""
                                                                                                    ?>>
                                                                                                    <label
                                                                                                        class="custom-control-label"
                                                                                                        for="persistent_pain_in_the_chest2">NO</label>
                                                                                                </div>
                                                                                            </fieldset>

                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </div>
                                                                            <div class="col-2">
                                                                                <button type="submit"
                                                                                    class="btn btn-solid btn-primary">Submit</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </form>
                                                        </fieldset>
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="tab-pane <?php echo session()->get('dept_id') != " 1" &&
                                                        session()->get('dept_id') != "17" && session()->get('dept_id')
                                                        != "8"
                                                        ? "active" : "" ?>" id="tabIcon35" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab35">
                                                        <div class="col-12">
                                                            <?php if($patientCode == null): ?>
                                                            <div
                                                                class="container d-flex justify-content-center align-items-center flex-column">
                                                                <h3 class="text-center font-weight-regular my-2">
                                                                    Before entering this section, the patient needs to
                                                                    admit.
                                                                </h3>
                                                                <a href="create_admission?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($patient->patientcode); ?>"
                                                                    class="btn btn-solid btn-primary text-center">Admit
                                                                    Now</a>
                                                            </div>
                                                            <?php else: ?>
                                                            <div class="nav-vertical">
                                                                <ul class="nav nav-tabs nav-left nav-border-left"
                                                                    role="tablist">
                                                                    <?php if(session()->get('dept_id') == "15" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            15" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab1"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft1"
                                                                            href="#tabVerticalLeft1" role="tab"
                                                                            aria-selected="false">Audiometry</a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "9" ||
                                                                    session()->get('dept_id') ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            9" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab4"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft4"
                                                                            href="#tabVerticalLeft4" role="tab"
                                                                            aria-selected="false">Dental</a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "16" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            16" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab5"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft5"
                                                                            href="#tabVerticalLeft5" role="tab"
                                                                            aria-selected="false">ECG
                                                                        </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab6"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft6"
                                                                            href="#tabVerticalLeft6" role="tab"
                                                                            aria-selected="false">2D
                                                                            Echo Doppler </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab7"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft7"
                                                                            href="#tabVerticalLeft7" role="tab"
                                                                            aria-selected="false">2D
                                                                            Echo Plain </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab12"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft12"
                                                                            href="#tabVerticalLeft12" role="tab"
                                                                            aria-selected="false">Stress
                                                                            Echo </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab13"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft13"
                                                                            href="#tabVerticalLeft13" role="tab"
                                                                            aria-selected="false">Stress
                                                                            Test </a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "14" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            14" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab8"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft8"
                                                                            href="#tabVerticalLeft8" role="tab"
                                                                            aria-selected="false">Ishihara</a>

                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab16"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft16"
                                                                            href="#tabVerticalLeft16" role="tab"
                                                                            aria-selected="false">Visual
                                                                            Acuity </a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "5" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            5" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab10"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft10"
                                                                            href="#tabVerticalLeft10" role="tab"
                                                                            aria-selected="false">Psychological</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab11"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft11"
                                                                            href="#tabVerticalLeft11" role="tab"
                                                                            aria-selected="false">BPI
                                                                            Psycho </a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "4" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width <?php echo session()->get('dept_id') == "
                                                                            14" ? "active" : "" ?>"
                                                                            id="baseVerticalLeft1-tab14"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft14"
                                                                            href="#tabVerticalLeft14" role="tab"
                                                                            aria-selected="false">Ultrasound</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab17"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft17"
                                                                            href="#tabVerticalLeft17" role="tab"
                                                                            aria-selected="false">X-Ray
                                                                        </a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "16" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab2"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft2"
                                                                            href="#tabVerticalLeft2" role="tab"
                                                                            aria-selected="false">Cardiac
                                                                            Risk Factor </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab3"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft3"
                                                                            href="#tabVerticalLeft3" role="tab"
                                                                            aria-selected="false">Cardiovascular</a>
                                                                    </li>
                                                                    <?php endif; ?>

                                                                    <?php if(session()->get('dept_id') == "7" ||
                                                                    session()->get('dept_id')
                                                                    ==
                                                                    "1"): ?>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab9"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft9"
                                                                            href="#tabVerticalLeft9" role="tab"
                                                                            aria-selected="false">Physical
                                                                            Exam </a>
                                                                    </li>
                                                                    <?php endif; ?>
                                                                </ul>
                                                                <div class="tab-content px-1">
                                                                    <div class="tab-pane <?php echo session()->get('dept_id') == "
                                                                        15" ? "active" : "" ?>"
                                                                        id="tabVerticalLeft1" role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab1">
                                                                        <?php if(!$exam_audio): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_audiometry?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Audiometry.view-audiometry', [$exam_audio], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft2"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab2">
                                                                        <div class="row">
                                                                            <?php if(!$exam_crf): ?>
                                                                            <div class="container">
                                                                                <div
                                                                                    class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                    <h2 class="text-center">This patient
                                                                                        has
                                                                                        no
                                                                                        record
                                                                                        in
                                                                                        this exam. Do you want to add a
                                                                                        record?
                                                                                    </h2>
                                                                                    <a href="/add_crf?id=<?php echo e($patientCode->id); ?>"
                                                                                        class="btn btn-solid btn-primary te">Add</a>
                                                                                </div>
                                                                            </div>
                                                                            <?php else: ?>
                                                                                <?php echo $__env->make('CardiacRiskFactor.view-crf', [$exam_crf], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft3"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab3">
                                                                        <?php if(!$exam_cardio): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_cardiovascular?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('CardioVascular.view-cardiovascular', [$exam_cardio], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane <?php echo session()->get('dept_id') == "9" ? "active" : "" ?>"
                                                                        id="tabVerticalLeft4" role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab4">
                                                                        <?php if(!$exam_dental): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_dental?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Dental.view-dental', [$exam_dental], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane <?php echo session()->get('dept_id') == "
                                                                        16" ? "active" : "" ?>"
                                                                        id="tabVerticalLeft5" role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab5">
                                                                        <?php if(!$exam_ecg): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_ecg?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('ECG.view-ecg', [$exam_ecg], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane my-1" id="tabVerticalLeft6"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab6">
                                                                        <?php if(!$exam_echodoppler): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_echodoppler?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('EchoDoppler.view-echodoppler', [$exam_echodoppler], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane my-1" id="tabVerticalLeft7"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab7">
                                                                        <?php if(!$exam_echoplain): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_echoplain?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('EchoDoppler.view-echodoppler', [$exam_echoplain], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane my-1" id="tabVerticalLeft8"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab8">
                                                                        <?php if(!$exam_ishihara): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_ishihara?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Ishihara.view-ishihara', [$exam_ishihara], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <?php if(session()->get('dept_id') == "1"
                                                                    || session()->get('dept_id') == "7"): ?>
                                                                    <div class="tab-pane my-1" id="tabVerticalLeft9"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab9">
                                                                        <?php if(!$exam_physical): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_physical?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Physical.view-physical', [$exam_physical], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <div class="tab-pane <?php echo session()->get('dept_id') == "
                                                                        5" ? "active" : "" ?>"
                                                                        id="tabVerticalLeft10" role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab10">
                                                                        <?php if(!$exam_psycho): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_psycho?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Psychological.view-psycho', [$exam_psycho], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft11"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab11">
                                                                        <?php if(!$exam_psychobpi): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_psychobpi?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('PsychoBPI.view-psychobpi', [$exam_psychobpi], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft12"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab12">
                                                                        <?php if(!$exam_stressecho): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_stressecho?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('StressEcho.view-stressecho', [$exam_stressecho], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft13"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab13">
                                                                        <?php if(!$exam_stresstest): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_stresstest?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('StressTest.view-stresstest', [$exam_stresstest], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane <?php echo session()->get('dept_id') == "
                                                                        4" ? "active" : "" ?>"
                                                                        id="tabVerticalLeft14" role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab14">
                                                                        <?php if(!$exam_ultrasound): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_ultrasound?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Ultrasound.view-ultrasound', [$exam_ultrasound], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft16"
                                                                        role="tabpanel"
                                                                        varia-labelledby="baseVerticalLeft1-tab16">
                                                                        <?php if(!$exam_visacuity): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_visacuity?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Visacuity.view-visacuity', [$exam_visacuity], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft17"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab17">
                                                                        <?php if(!$exam_xray): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_xray?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('XRay.view-xray', [$exam_xray], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tabIcon36" role="tabpanel"
                                                        aria-labelledby="baseIcon-tab36">
                                                        <div class="col-md-12">
                                                            <?php if($patientCode == null): ?>
                                                            <div
                                                                class="container d-flex justify-content-center align-items-center flex-column">
                                                                <h3 class="text-center font-weight-regular my-2">
                                                                    Before entering this section, the patient needs to
                                                                    admit.
                                                                </h3>
                                                                <a href="create_admission?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($patient->patientcode); ?>"
                                                                    class="btn btn-solid btn-primary text-center">Admit
                                                                    Now</a>
                                                            </div>
                                                            <?php else: ?>
                                                            <div class="nav-vertical">
                                                                <?php if(session()->get('dept_id') == "3" ||
                                                                session()->get('dept_id') ==
                                                                "1"): ?>
                                                                <ul class="nav nav-tabs nav-left nav-border-left"
                                                                    role="tablist">
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width active"
                                                                            id="baseVerticalLeft1-tab21"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft21"
                                                                            href="#tabVerticalLeft21" role="tab"
                                                                            aria-selected="true">Blood/Serology</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab22"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft22"
                                                                            href="#tabVerticalLeft22" role="tab"
                                                                            aria-selected="false">HIV</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab23"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft23"
                                                                            href="#tabVerticalLeft23" role="tab"
                                                                            aria-selected="false">Drug
                                                                            Test</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab24"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft24"
                                                                            href="#tabVerticalLeft24" role="tab"
                                                                            aria-selected="false">Fecalysis</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab25"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft25"
                                                                            href="#tabVerticalLeft25" role="tab"
                                                                            aria-selected="false">Hematology
                                                                        </a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab26"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft26"
                                                                            href="#tabVerticalLeft26" role="tab"
                                                                            aria-selected="false">Hepatisis</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab27"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft27"
                                                                            href="#tabVerticalLeft27" role="tab"
                                                                            aria-selected="false">Pregnancy</a>
                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab28"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft28"
                                                                            href="#tabVerticalLeft28" role="tab"
                                                                            aria-selected="false">Urinalysis</a>

                                                                    </li>
                                                                    <li class="nav-item vertical-tab-border">
                                                                        <a class="nav-link nav-link-width"
                                                                            id="baseVerticalLeft1-tab29"
                                                                            data-toggle="tab"
                                                                            aria-controls="tabVerticalLeft29"
                                                                            href="#tabVerticalLeft29" role="tab"
                                                                            aria-selected="false">Miscellaneous</a>
                                                                    </li>
                                                                </ul>
                                                                <div class="tab-content px-1">
                                                                    <div class="tab-pane active" id="tabVerticalLeft21"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab21">
                                                                        <?php if(!$exam_blood_serology): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_bloodsero?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Blood_Serology.view-bloodserology', [$exam_xray], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft22"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab22">
                                                                        <?php if(!$examlab_hiv): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_hiv?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('HIV.view-hiv', [$examlab_hiv], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft23"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab23">
                                                                        <?php if(!$examlab_drug): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_drug?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Drug.view-drug', [$examlab_drug], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft24"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab24">
                                                                        <?php if(!$examlab_feca): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_fecalysis?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Fecalysis.view-fecalysis', [$examlab_feca], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft25"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab25">
                                                                        <?php if(!$examlab_hema): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_hematology?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Hematology.view-hematology', [$examlab_hema], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft26"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab26">
                                                                        <?php if(!$examlab_hepa): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_hepatitis?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Hepatitis.view-hepatitis', [$examlab_hepa], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft27"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab27">
                                                                        <?php if(!$examlab_pregnancy): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_pregnancy?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Pregnancy.view-pregnancy', [$examlab_pregnancy], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft28"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab28">
                                                                        <?php if(!$examlab_urin): ?>
                                                                        <div class="container">
                                                                            <div
                                                                                class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                <h2 class="text-center">This patient has
                                                                                    no
                                                                                    record in
                                                                                    this
                                                                                    exam. Do you want to add a record?
                                                                                </h2>
                                                                                <a href="/add_urinalysis?id=<?php echo e($patientCode->id); ?>"
                                                                                    class="btn btn-solid btn-primary te">Add</a>
                                                                            </div>
                                                                        </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Urinalysis.view-urinalysis', [$examlab_urin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="tab-pane" id="tabVerticalLeft29"
                                                                        role="tabpanel"
                                                                        aria-labelledby="baseVerticalLeft1-tab29">
                                                                        <?php if(!$examlab_misc): ?>
                                                                            <div class="container">
                                                                                <div
                                                                                    class="container d-flex justify-content-center align-items-center my-3 flex-column">
                                                                                    <h2 class="text-center">This patient has
                                                                                        no
                                                                                        record in
                                                                                        this
                                                                                        exam. Do you want to add a record?
                                                                                    </h2>
                                                                                    <a href="/add_misc?id=<?php echo e($patientCode->id); ?>"
                                                                                        class="btn btn-solid btn-primary te">Add</a>
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <?php echo $__env->make('Miscellaneous.view-misc', [$examlab_misc], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>


                        <div class="tab-pane fade" id="account-vertical-password" role="tabpanel"
                            aria-labelledby="account-pill-password" aria-expanded="false">
                            <div class="card">
                                <div class="card-body">
                                    <form action='/update_schedule' method="POST">
                                        <?php echo csrf_field(); ?>
                                        <h4 class="form-section"><i class="feather icon-user"></i>Re Schedule</h4>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <?php if($latest_schedule): ?>
                                                <input type="hidden" name="patient_id"
                                                    value="<?php echo e($latest_schedule->patient_id); ?>">
                                                <input type="hidden" name="patientcode"
                                                    value="<?php echo e($latest_schedule->patientcode); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($latest_schedule->id); ?>">
                                                <input type="date" max="2050-12-31" class="form-control"
                                                    value="<?php echo e($latest_schedule->date); ?>" name="schedule_date">
                                                <?php else: ?>
                                                <input type="hidden" name="patient_id" value="">
                                                <input type="hidden" name="id" value="">
                                                <input type="date" max="2050-12-31" class="form-control" value="" name="schedule_date">
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                            <button type="submit" class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                changes</button>
                                        </div>
                                        <input type="hidden" name="action" value="admin_update">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php if($patientCode): ?>
                        <div class="tab-pane fade" id="account-vertical-social" role="tabpanel"
                            aria-labelledby="account-pill-social" aria-expanded="false">
                            <div class="card">
                                <div class="card-header">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="card-title">
                                                <h3>Uploaded Files</h3>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__env->startPush('scripts'); ?>
                                            <script>
                                            let toaster = toastr.error('<?php echo e($error); ?>', 'Error');
                                            </script>
                                            <?php $__env->stopPush(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <form action="/store_patient_files" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                                                        <input type="file" class="form-control" id="upload_files"
                                                            name="upload_files[]" multiple />
                                                    </div>
                                                    <div class="col-md-4">
                                                        <button class="btn btn-solid btn-primary">Upload</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <?php if($patient_upload_files): ?>
                                        <?php $__currentLoopData = $patient_upload_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient_upload_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(pathinfo($patient_upload_file->file_name, PATHINFO_EXTENSION) == "pdf"): ?>
                                        <div class="col-md-2">
                                            <div class="upload-con">
                                                <img src="../../../app-assets/images/pdf.png" alt="">
                                                <div class="upload-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/app-assets/files/<?php echo e($patient_upload_file->file_name); ?>')"
                                                        class="btn-print">View</button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php else: ?>
                                        <div class="col-md-2">
                                            <div class="upload-con">
                                                <img src="../../../app-assets/files/<?php echo e($patient_upload_file->file_name); ?>"
                                                    alt="">
                                                <div class="upload-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/app-assets/files/<?php echo e($patient_upload_file->file_name); ?>')"
                                                        class="btn-print">View</button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <h4><b>CERTIFICATES</b></h4>
                                    <div class="row container my-1">
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/mlc.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/mlc_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print MLC</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/bahia.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/peme_bahia_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print PEME BAHIA</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/mer.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/mer_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print MER</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <h4><b>MEDICAL CERTIFICATE</b></h4>
                                    <div class="row container">
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/skuld.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/skuld_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Skuld</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/woe.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/west_england_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print WOE</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/cayman.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/cayman_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Cayman</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/liberian.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/liberian_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Liberian</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/croatian.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/croatian_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Croatian</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/danish.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/danish_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Danish</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/diamlemos.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/diamlemos_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Diamlemos</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/marshall.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/marshall_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Marshall</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/malta.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/malta_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Malta</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/dominican.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/dominican_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Dominican</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/bahamas.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/bahamas_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Bahamas</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/bermuda.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/bermuda_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Bermuda</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xl-3 col-sm-6 ">
                                            <div class="print-con">
                                                <img src="../../../app-assets/images/gallery/singapore_flag.png" alt="">
                                                <div class="print-btn-div">
                                                    <button type="button"
                                                        onclick="window.open('/singapore_flag_print?id=<?php echo e($patientCode->id); ?>','wp','width=1000,height=800').print();"
                                                        class="btn-print">Print Singapore</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="tab-pane fade" id="account-vertical-info" role="tabpanel"
                            aria-labelledby="account-pill-info" aria-expanded="false">
                            <?php if($patientCode): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="text-bold-500">Edit Admission</h2>
                                    <a class="heading-elements-toggle"><i
                                            class="fa fa-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="feather icon-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="feather icon-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="feather icon-x"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="card-title">
                                        <h6>
                                            PEME Date: <?php echo date('Y-m-d'); ?>
                                        </h6>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <?php if(Session::get('status')): ?>
                                        <div class="success alert-success p-2 my-2">
                                            <?php echo e(Session::get('status')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <form class="form" method="POST" action="/update_admission">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($patientCode->id); ?>" name="main_id">
                                            <div class="d-none">
                                                <input type="date" max="2050-12-31" name="trans_date" id="" hidden value="<?php echo date(
                                            'Y-m-d'
                                        ); ?>">
                                                <input type="hidden" name="package_id"
                                                    value="<?php echo e($patientInfo->medical_package); ?>">
                                                <input type="hidden" name="agency_id"
                                                    value="<?php echo e($patientInfo->agency_id); ?>">
                                                <input type="hidden" name="vessel" value="<?php echo e($patientInfo->vessel); ?>">
                                                <input type="hidden" name="country_destination"
                                                    value="<?php echo e($patientInfo->country_destination); ?>">
                                            </div>
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput1">Patient
                                                                Name</label>
                                                            <input type="text" id="projectinput1" class="form-control"
                                                                value="<?php echo e($patient->lastname); ?>, <?php echo e($patient->firstname); ?>"
                                                                name="fullname" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput1">Patient
                                                                Code</label>
                                                            <input type="text" id="projectinput1" class="form-control"
                                                                value="<?php echo e($patient->patientcode); ?>" name="patientcode"
                                                                readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600"
                                                                for="admission_category">Category</label>
                                                            <select id="admission_category" name="category"
                                                                class="form-control">
                                                                <option value="none" selected="" disabled="">Select
                                                                    Category
                                                                </option>
                                                                <option value="DECK SERVICES" <?php echo $patientCode->
                                                                    category ==
                                                                    "DECK SERVICES" ? "selected=''" : "" ?>>DECK
                                                                    SERVICES
                                                                </option>
                                                                <option value="ENGINE SERVICES" <?php echo $patientCode->
                                                                    category
                                                                    == "ENGINE SERVICES" ? "selected=''" : ""
                                                                    ?>>ENGINE
                                                                    SERVICES</option>
                                                                <option value="CATERING SERVICES" <?php echo
                                                                    $patientCode->
                                                                    category
                                                                    == "CATERING SERVICES" ? "selected=''" : ""
                                                                    ?>>CATERING
                                                                    SERVICES</option>
                                                                <option value="OTHER SERVICES" <?php echo $patientCode->
                                                                    category ==
                                                                    "OTHER SERVICES" ? "selected=''" : "" ?>>OTHER
                                                                    SERVICES
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <label class="text-bold-600"
                                                                    for="companyName">Position</label>
                                                                <input type="text" id="companyName" class="form-control"
                                                                    placeholder="Position" name="position"
                                                                    value="<?php echo e($patientCode->position); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Employment
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment1" value="Sea-Based"
                                                                        name="employment" <?php echo
                                                                        $patientCode->employment == "Sea-Based" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="employment1">Sea
                                                                        Based</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment2" name="employment"
                                                                        value="Land-Based" <?php echo
                                                                        $patientCode->employment == "Land-Based" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="employment2">Land
                                                                        Based
                                                                    </label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment3" name="employment"
                                                                        value="Local-Based" <?php echo
                                                                        $patientCode->employment == "Local-Based" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="employment3">Local
                                                                        Based
                                                                    </label>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Employment
                                                                Status</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="emp_status1" name="emp_status"
                                                                        value="New Crew" <?php echo
                                                                        $patientCode->emp_status == "New Crew" ?
                                                                    "checked"
                                                                    :
                                                                    "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="emp_status1">New
                                                                        Crew</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="emp_status2" name="emp_status"
                                                                        value="Ex-Crew" <?php echo
                                                                        $patientCode->emp_status
                                                                    == "Ex-Crew" ? "checked" :
                                                                    "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="emp_status2">Ex
                                                                        Crew</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Admission
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="admit_type1" name="admit_type"
                                                                        value="Normal" <?php echo
                                                                        $patientCode->admit_type
                                                                    == "Normal" ? "checked" : ""
                                                                    ?>>
                                                                    <label class="custom-control-label"
                                                                        for="admit_type1">Regular
                                                                        Patient</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="admit_type2" name="admit_type" value="Rush"
                                                                        <?php echo $patientCode->admit_type == "Rush" ?
                                                                    "checked" : ""
                                                                    ?>>
                                                                    <label class="custom-control-label"
                                                                        for="admit_type2">Rush
                                                                        Patient</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Payment
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        name="payment_type" id="payment_type3"
                                                                        value="Applicant Paid" <?php echo
                                                                        $patientCode->payment_type == "Applicant Paid" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="payment_type3">Applicant Paid</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="payment_type4" name="payment_type"
                                                                        value="Billed" <?php echo
                                                                        $patientCode->payment_type
                                                                    == "Billed" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="payment_type4">Billed to Agency</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="card border my-3">
                                                    <div class="card-header border bg-success text-white">
                                                        <h4>Exam List
                                                        </h4>
                                                        <h5>Note: All exams in the package cannot be deleted.</h5>
                                                    </div>
                                                    <div class="card-body">
                                                        <?php if(count($admission_exams) != 0): ?>
                                                        <div id="myRepeatingFields">
                                                            <?php $__currentLoopData = $admission_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="entry input-group row">
                                                                <div class="row">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <th>Exam</th>
                                                                            <th>Charge</th>
                                                                            <th></th>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <select name="exam[]" id=""
                                                                                        class="form-control select2">
                                                                                        <option
                                                                                            value="<?php echo e($admission_exam->exam_id); ?>">
                                                                                            <?php echo e($admission_exam->examname); ?>

                                                                                        </option>
                                                                                        <?php $__currentLoopData = $list_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($exam->id); ?>">
                                                                                            <?php echo e($exam->examname); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                </td>
                                                                                <td>
                                                                                    <input class="mx-1" name="charge[]"
                                                                                        id="charge" type="checkbox"
                                                                                        placeholder="Charge"
                                                                                        value="package" <?php echo
                                                                                        $admission_exam->charge ==
                                                                                    "package" ? "checked" : "" ?>/>
                                                                                </td>
                                                                                <td>
                                                                                    <span class="input-group-btn">
                                                                                        <button type="button"
                                                                                            class="btn btn-success btn-add">
                                                                                            <span class="fa fa-plus"
                                                                                                aria-hidden="true"></span>
                                                                                        </button>
                                                                                    </span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                        <?php else: ?>
                                                        <div id="myRepeatingFields">
                                                            <div class="entry input-group row">
                                                                <div class="row">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <th>Exam</th>
                                                                            <th>Charge</th>
                                                                            <th></th>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <select name="exam[]" id=""
                                                                                        class="form-control select2">
                                                                                        <option value="">Select Exam
                                                                                        </option>
                                                                                        <?php $__currentLoopData = $list_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($exam->id); ?>">
                                                                                            <?php echo e($exam->examname); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                </td>
                                                                                <td>
                                                                                    <input class="mx-1" name="charge[]"
                                                                                        type="checkbox"
                                                                                        placeholder="Charge"
                                                                                        value="package" />
                                                                                </td>
                                                                                <td>
                                                                                    <span class="input-group-btn">
                                                                                        <button type="button"
                                                                                            class="btn btn-success btn-add">
                                                                                            <span class="fa fa-plus"
                                                                                                aria-hidden="true"></span>
                                                                                        </button>
                                                                                    </span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions">
                                                <button type="reset" class="btn btn-warning mr-1">
                                                    <i class="feather icon-x"></i> Cancel
                                                </button>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-check-square-o"></i> Save
                                                </button>
                                            </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="text-bold-500">Add Admission</h2>
                                    <a class="heading-elements-toggle"><i
                                            class="fa fa-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="feather icon-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="feather icon-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="feather icon-x"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="card-title">
                                        <h6>
                                            PEME Date: <?php echo date('Y-m-d'); ?>
                                        </h6>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <form class="form" method="POST" action="/store_admission">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                                            <div class="d-none">
                                                <input type="date" max="2050-12-31" name="trans_date" id="" hidden value="<?php echo date(
                                                'Y-m-d'
                                            ); ?>">
                                                <input type="hidden" name="package_id"
                                                    value="<?php echo e($patientInfo->medical_package); ?>">
                                                <input type="hidden" name="agency_id"
                                                    value="<?php echo e($patientInfo->agency_id); ?>">
                                                <input type="hidden" name="vessel" value="<?php echo e($patientInfo->vessel); ?>">
                                                <input type="hidden" name="country_destination"
                                                    value="<?php echo e($patientInfo->country_destination); ?>">
                                            </div>
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput1">Patient
                                                                Name</label>
                                                            <input type="text" id="projectinput1" class="form-control"
                                                                value="<?php echo e($patient->lastname); ?>, <?php echo e($patient->firstname); ?>"
                                                                name="fullname" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput1">Patient
                                                                Code</label>
                                                            <input type="text" id="projectinput1" class="form-control"
                                                                value="<?php echo e($patient->patientcode); ?>" name="patientcode"
                                                                readonly>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600"
                                                                for="admission_category">Category</label>
                                                            <select id="admission_category" name="category"
                                                                class="form-control">
                                                                <option value="none" selected="" disabled="">Select
                                                                    Category
                                                                </option>
                                                                <option value="DECK SERVICES" <?php echo $patientInfo->
                                                                    category == "DECK SERVICES" ? "selected" : null
                                                                    ?>>DECK SERVICES</option>
                                                                <option value="ENGINE SERVICES" <?php echo $patientInfo->
                                                                    category == "ENGINE SERVICES" ? "selected" : null
                                                                    ?>>ENGINE SERVICES</option>
                                                                <option value="CATERING SERVICES" <?php echo
                                                                    $patientInfo->
                                                                    category == "CATERING SERVICES" ?
                                                                    "selected" : null ?>>CATERING SERVICES</option>
                                                                <option value="OTHER SERVICES" <?php echo $patientInfo->
                                                                    category == "OTHER SERVICES" ? "selected" : null
                                                                    ?>>OTHER SERVICES</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <label class="text-bold-600"
                                                                    for="companyName">Position</label>
                                                                <input type="text"
                                                                    value="<?php echo e($patient->position_applied); ?>"
                                                                    id="companyName" class="form-control"
                                                                    placeholder="Position" name="position">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Employment
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment1" value="Sea-Based"
                                                                        name="employment">
                                                                    <label class="custom-control-label"
                                                                        for="employment1">Sea
                                                                        Based</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment2" name="employment"
                                                                        value="Land-Based">
                                                                    <label class="custom-control-label"
                                                                        for="employment2">Land
                                                                        Based
                                                                    </label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="employment3" name="employment"
                                                                        value="Local-Based">
                                                                    <label class="custom-control-label"
                                                                        for="employment3">Local
                                                                        Based
                                                                    </label>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Employment
                                                                Status</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="emp_status1" name="emp_status"
                                                                        value="New Crew">
                                                                    <label class="custom-control-label"
                                                                        for="emp_status1">New
                                                                        Crew</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="emp_status2" name="emp_status"
                                                                        value="Ex-Crew">
                                                                    <label class="custom-control-label"
                                                                        for="emp_status2">Ex
                                                                        Crew</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Admission
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="admit_type1" name="admit_type"
                                                                        value="Normal" <?php echo
                                                                        $patientInfo->admission_type
                                                                    == "Normal" ? "checked" : ""
                                                                    ?>>
                                                                    <label class="custom-control-label"
                                                                        for="admit_type1">Regular
                                                                        Patient</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="admit_type2" name="admit_type" value="Rush"
                                                                        <?php echo $patientInfo->admission_type == "Rush"
                                                                    ?
                                                                    "checked" : ""
                                                                    ?>>
                                                                    <label class="custom-control-label"
                                                                        for="admit_type2">Rush
                                                                        Patient</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="text-bold-600" for="projectinput2">Payment
                                                                Type</label>
                                                            <div class="container-fluid ">
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        name="payment_type" id="payment_type3"
                                                                        value="Applicant Paid" <?php echo
                                                                        $patientInfo->payment_type == "Applicant Paid" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="payment_type3">Applicant Paid</label>
                                                                </div>
                                                                <div
                                                                    class="d-inline-block custom-control custom-radio mr-1">
                                                                    <input type="radio" class="custom-control-input"
                                                                        id="payment_type4" name="payment_type"
                                                                        value="Billed" <?php echo
                                                                        $patientInfo->payment_type
                                                                    == "Billed" ?
                                                                    "checked" : "" ?>>
                                                                    <label class="custom-control-label"
                                                                        for="payment_type4">Billed to Agency</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="card my-2">
                                                    <div class="card-header border bg-success text-white">
                                                        <h4>Exam List
                                                        </h4>
                                                        <h5>Note: All exams in the package cannot be deleted.</h5>
                                                    </div>
                                                    <div class="card-body">
                                                        <div id="myRepeatingFields">
                                                            <div class="entry input-group row">
                                                                <div class="row table-responsive">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <th>Exam</th>
                                                                            <th>Charge</th>
                                                                            <th></th>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <select name="exam[]" id=""
                                                                                        class="form-control select-2">
                                                                                        <option value="">Select Exam
                                                                                        </option>
                                                                                        <?php $__currentLoopData = $list_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($exam->id); ?>">
                                                                                            <?php echo e($exam->examname); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                </td>
                                                                                <td>
                                                                                    <input class="mx-1" name="charge[]"
                                                                                        type="checkbox"
                                                                                        placeholder="Charge"
                                                                                        value="package" />
                                                                                </td>
                                                                                <td>
                                                                                    <span class="input-group-btn">
                                                                                        <button type="button"
                                                                                            class="btn btn-success btn-add">
                                                                                            <span class="fa fa-plus"
                                                                                                aria-hidden="true"></span>
                                                                                        </button>
                                                                                    </span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions">
                                                <button type="reset" class="btn btn-warning mr-1">
                                                    <i class="feather icon-x"></i> Cancel
                                                </button>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-check-square-o"></i> Save
                                                </button>
                                            </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="account-vaccination-record" role="tabpanel"  aria-labelledby="account-vaccination-record" aria-expanded="false">
                            <div class="container">
                                <div class="card">
                                    <div class="card-header">
                                        <h2 class="card-title">Yellow Card Form</h2>
                                    </div>
                                    <div class="card-body">
                                        <form action="/store_yellow_card" method="POST" class="form table-responsive">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                                            <?php $count = 1; ?>
                                            <?php if(count($yellow_card_records) > 0): ?>
                                                <input type="hidden" name="action" value="update">
                                                <table class="table table-bordered">
                                                    <tbody id="repeating_yellow_form">
                                                        <tr>
                                                            <td><b>Vaccine</b></td>
                                                            <td><b>Date</b></td>
                                                            <td><b>Manufacturer and batch No. <br> of vaccine or prophylaxis</b></td>
                                                            <td><b>Certificate valid <br> from.....  Until......</b></td>
                                                            <td><b>Official Stamp of <br> administering centre</b></td>
                                                            <!-- <td><b>Action</b></td> -->
                                                        </tr>
                                                        <?php $__currentLoopData = $yellow_card_records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yellow_card_record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="<?php echo e($yellow_card_record->count); ?>" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="<?php echo e($yellow_card_record->vaccine); ?>" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="<?php echo e($yellow_card_record->date); ?>" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]"  value="<?php echo e($yellow_card_record->manufacturer); ?>" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]" value="<?php echo e($yellow_card_record->cert_valid); ?>" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="<?php echo e($yellow_card_record->official_stamp); ?>" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                             <?php else: ?>
                                                <input type="hidden" name="action" value="store">
                                                <table class="table table-bordered">
                                                    <tbody id="repeating_yellow_form">
                                                        <tr>
                                                            <td><b>Vaccine</b></td>
                                                            <td><b>Date</b></td>
                                                            <td><b>Manufacturer and batch No. <br> of vaccine or prophylaxis</b></td>
                                                            <td><b>Certificate valid <br> from.....  Until......</b></td>
                                                            <td><b>Official Stamp of <br> administering centre</b></td>
                                                            <!-- <td><b>Action</b></td> -->
                                                        </tr>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="1" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="Yellow Fever" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="2" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="COVID 19 FIRST DOSE" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]"   class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="3" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="COVID 19 SECOND DOSE" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="4" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="MMR" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                        <tr class="entry">
                                                            <td class="d-none">
                                                                <input type="hidden" name="count[]" value="5" id="count" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="vaccine[]" readonly value="VARCIELLA" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="date" name="date[]" max="2050-12-31" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="manufacturer[]" value="" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="cert_valid[]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="official_stamp[]" value="" class="form-control">
                                                            </td>
                                                            <!-- <td>
                                                                <button type="button" class="btn btn-success btn-add"><span class="fa fa-plus" aria-hidden="true"></span></button>
                                                            </td> -->
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                            <button class="btn btn-primary btn-solid">Submit and Print</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 order-lg-1 order-xl-2 order-sm-1 order-xs-1 col-lg-12 col-sm-12 position-relative right-sidebar">
                    <div class="row p-50 rounded" style="background: #091a3b">
                        <div class="col-lg-3 col-md-4 col-xl-12">
                            <div class="row my-1">
                                <div
                                    class="col-md-12 col-xl-5 col-lg-12 d-xl-flex align-items-center justify-content-center">
                                    <button class="btn btn-solid p-0 open-camera" onclick="openCamera()">
                                        <?php if($patient->patient_image == null || $patient->patient_image == "" ||
                                        !file_exists(public_path('app-assets/images/profiles/') .
                                        $patient->patient_image)): ?>
                                        <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                            alt="Profile Picture" data-toggle="modal" data-target="#defaultSize"
                                            class="users-avatar-shadow rounded" height="110" width="110">
                                        <?php else: ?>
                                        <img src="../../../app-assets/images/profiles/<?php echo e($patient->patient_image); ?>"
                                            data-toggle="modal" data-target="#defaultSize" alt="Profile Picture"
                                            class="users-avatar-shadow" height="110" width="110">
                                        <?php endif; ?>
                                    </button>
                                </div>
                                <div class="col-md-12 col-xl-6 col-lg-12 mx-50">
                                    <div class="pt-25">
                                        <div class="d-flex justify-content-start align-items-end my-25">
                                            <?php if($patient->patient_signature): ?>
                                            <img src="<?php echo base64_decode($patient->patient_signature) ?>" class="signature-taken" />
                                            <?php elseif($patient->signature): ?>
                                             <img src="data:image/jpeg;base64,<?php echo e($patient->signature); ?>" class="signature-taken"/>
                                            <?php else: ?> 
                                                <div style="width: 150px;height: 40px;" class="bg-white rounded"></div>
                                            <?php endif; ?>
                                        </div>
                                        <div> <span class="text-white font-weight-bold">
                                                <?php echo e($patient->firstname . ' ' . $patient->lastname); ?>

                                            </span>
                                        </div>
                                        <div class="users-view-id text-white">ID: <?php echo e($patient->patientcode); ?>

                                        </div>
                                        <div class="text-white">ADMISSION ID: <?php echo $patientCode ?
                                            $patientCode->id : "N /
                                            A" ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-xl-12 mt-sm-2">
                            <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white active" id="account-pill-general"
                                        data-toggle="pill" href="#account-vertical-general" aria-expanded="true">
                                        <i class="feather icon-globe"></i>
                                        General Info
                                    </a>
                                </li>
                                <?php if(session()->get('dept_id') == '1' || session()->get('dept_id') == '17'): ?>
                                <?php if($latest_schedule): ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-password" data-toggle="pill"
                                        href="#account-vertical-password" aria-expanded="false">
                                        <i class="feather icon-calendar"></i>
                                        Re Schedule
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php if($patientCode): ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-info" data-toggle="pill"
                                        aria-expanded="false" href="#account-vertical-info">
                                        <i class="feather icon-edit"></i>
                                        Edit Admission
                                    </a>
                                </li>
                                <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-info" data-toggle="pill"
                                        aria-expanded="false" href="#account-vertical-info">
                                        <i class="feather icon-edit"></i>
                                        Add Admission
                                    </a>
                                </li>
                                <?php endif; ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-vaccination-record" data-toggle="pill"
                                        aria-expanded="false" href="#account-vaccination-record">
                                        <i class="feather icon-edit"></i>
                                        Yellow Card
                                    </a>
                                </li>
                                <?php if($patientCode): ?>
                                <?php if(session()->get('dept_id') == '1' || session()->get('dept_id') == '8' || session()->get('dept_id') == '17'): ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-social" data-toggle="pill"
                                        href="#account-vertical-social" aria-expanded="false">
                                        <i class="fa fa-print"></i>
                                        Print Panel
                                    </a>
                                </li>
                                <?php endif; ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-connections"
                                        data-toggle="pill"
                                        onclick="window.open('/admission_print?id=<?php echo e($patientCode->id); ?>').print()"
                                        aria-expanded="false">
                                        <i class="fa fa-print"></i>
                                        Print Routing Slip
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(session()->get('dept_id') == '1'): ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-connections"
                                        data-toggle="pill"
                                        onclick="window.open('/referral_pdf?email=<?php echo e($patient->email); ?>').print()"
                                        aria-expanded="false">
                                        <i class="fa fa-print"></i>
                                        Print Referral Slip
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(session()->get('dept_id') == '1'): ?>
                                <li class="nav-item">
                                    <a class="nav-link d-flex text-white" id="account-pill-connections"
                                        data-toggle="pill"
                                        onclick="window.open('/requests_print?id=<?php echo e($patientInfo->medical_package); ?>&patient_id=<?php echo e($patient->id); ?>').print()"
                                        aria-expanded="false">
                                        <i class="fa fa-print"></i>
                                        Print Requests
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <?php if($complete_patient): ?>
                        <div class="col-lg-5 col-md-4 col-xl-12 my-1">
                            <h5 class="text-white">Laboratory Result Status:
                                <span><b>
                                        <?php if($patientCode->lab_status == 2): ?>
                                        <b><u>FIT TO WORK</u></b>
                                        <?php elseif($patientCode->lab_status == 1): ?>
                                        <b><u>RE ASSESSMENT</u></b>
                                        <?php endif; ?>
                                    </b></span>
                            </h5>
                            <div class="my-1">
                                <button type="button" class="btn btn-outline-warning btn-sm m-50 p-75" data-toggle="modal"
                                    data-target="#inlineForm">
                                    RE ASSESSMENT
                                </button>
                                <button <?php echo e(session()->get('dept_id') == 1 ? null : "disabled"); ?> type="button" class="btn btn-sm p-75 m-50 btn-outline-success medical-done"
                                    id="done-btn">FIT TO WORK</button>
                            </div>
                            <div class="form-group">
                                <textarea name="" id="" cols="20" disabled rows="5"
                                    class="form-control"><?php echo e($patientCode->remarks); ?></textarea>
                            </div>
                            <div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog"
                                aria-labelledby="myModalLabel33" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <label class="modal-title text-text-bold-600" id="myModalLabel33">Laboratory
                                                Result</label>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="container my-2 border p-1">
                                            <h2>Findings</h2>
                                            <div class="row my-1">
                                                <?php if($exam_audio): ?>
                                                <?php if($exam_audio->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Audiometry</b></h5>
                                                    <span style="font-size: 12px; "><?php echo
                                                        nl2br($exam_audio->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_cardio): ?>
                                                <?php if($exam_cardio->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Cardiovascular</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_cardio->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_crf): ?>
                                                <?php if($exam_crf->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Cardiac Risk Factor</b></h5>
                                                    <span style="font-size: 12px;"><?php echo nl2br($exam_crf->remarks)
                                                        ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_ecg): ?>
                                                <?php if($exam_ecg->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>ECG</b></h5>
                                                    <span style="font-size: 12px;"><?php echo nl2br($exam_ecg->remarks)
                                                        ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_echodoppler): ?>
                                                <?php if($exam_echodoppler->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>2D Echo Doppler</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_echodoppler->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_echoplain): ?>
                                                <?php if($exam_echoplain->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>2D Echo Plain</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_echoplain->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_ishihara): ?>
                                                <?php if($exam_ishihara->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Ishihara</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_ishihara->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_psycho): ?>
                                                <?php if($exam_psycho->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Psychological</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_psycho->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_physical): ?>
                                                <?php if($exam_physical->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Physical</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_physical->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_psychobpi): ?>
                                                <?php if($exam_psychobpi->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Psycho BPI</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_psychobpi->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_stressecho): ?>
                                                <?php if($exam_stressecho->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Stress Echo</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_stressecho->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_stresstest): ?>
                                                <?php if($exam_stresstest->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Stress Test</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_stresstest->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_ultrasound): ?>
                                                <?php if($exam_ultrasound->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Ultrasound</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_ultrasound->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_dental): ?>
                                                <?php if($exam_dental->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Dental</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_dental->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_xray): ?>
                                                <?php if($exam_xray->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>X Ray</b></h5>
                                                    <span style="font-size: 12px;"><?php echo nl2br($exam_xray->remarks)
                                                        ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($exam_blood_serology): ?>
                                                <?php if($exam_blood_serology->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Blood Serology</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($exam_blood_serology->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_hiv): ?>
                                                <?php if($examlab_hiv->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>HIV</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_hiv->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_drug): ?>
                                                <?php if($examlab_drug->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Drug Test</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_drug->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_feca): ?>
                                                <?php if($examlab_feca->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Fecalysis</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_feca->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_hema): ?>
                                                <?php if($examlab_hema->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Hematology</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_hema->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_hepa): ?>
                                                <?php if($examlab_hepa->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Hepatitis</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_hepa->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_pregnancy): ?>
                                                <?php if($examlab_pregnancy->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Pregnancy</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_pregnancy->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_urin): ?>
                                                <?php if($examlab_urin->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Urinalysis</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_urin->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($examlab_misc): ?>
                                                <?php if($examlab_misc->remarks_status == 'findings'): ?>
                                                <div class="col-md-6 my-75">
                                                    <h5><b>Miscellaneous</b></h5>
                                                    <span style="font-size: 12px;"><?php echo
                                                        nl2br($examlab_misc->remarks) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <form id="update_lab_result" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <input type="hidden" name="lab_status" id="lab_status" value="1">
                                                <input type="hidden" name="patientId" value="<?php echo e($patient->id); ?>">
                                                <input type="hidden" name="agency_id" value="<?php echo e($patientInfo->agency_id); ?>">
                                                <input type="hidden" name="id"
                                                    value="<?php echo $patientCode ? $patientCode->id : null ?>">
                                                <input type="hidden" name="schedule_id"
                                                    value="<?php echo $latest_schedule ? $latest_schedule->id : null ?>">
                                                <div class="form-group">
                                                    <label>Impression:</label>
                                                    <textarea type="text" col="10" row="10" name="impression"
                                                        placeholder="Impression"
                                                        class="form-control"><?php echo $patientCode ? $patientCode->impression : null ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Remarks/Recommendations:</label>
                                                    <textarea type="text" col="10" row="10" name="remarks"
                                                        placeholder="Remarks/Recommendations"
                                                        class="form-control"><?php echo $patientCode ? $patientCode->remarks : null ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Latest Schedule</label>
                                                    <input type="date" max="2050-12-31" name="schedule" class="form-control"
                                                        value="<?php echo e($latest_schedule ? $latest_schedule->date : null); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Doctor Prescription</label>
                                                    <select required name="doctor_prescription" id="" class="select2">
                                                        <option value="">Select Doctor</option>
                                                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($doctor->id); ?>">
                                                            <?php echo e($doctor->firstname. " " . $doctor->lastname . " " . "($doctor->position)"); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Prescription</label>
                                                    <textarea name="prescription" id="" cols="30" rows="7"
                                                        class="form-control"><?php echo e($patientCode ? $patientCode->prescription : ""); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="reset" class="btn btn-outline-secondary btn-lg"
                                                    data-dismiss="modal" value="close">
                                                <button <?php echo e(session()->get('dept_id') == 1 ? null : "disabled"); ?> type='submit'
                                                    class='submit-reassessment btn btn-primary btn-lg'>Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-lg-12 col-xl-12 my-1">
                            <div class="container-fluid">
                                <ul class="nav nav-tabs nav-top-border no-hover-bg" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link primary active" id="home-tab1" data-toggle="tab"
                                            href="#home1" aria-controls="home1" role="tab"
                                            aria-selected="true">Completed Exams</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link primary" id="profile-tab1" data-toggle="tab" href="#profile1"
                                            aria-controls="profile1" role="tab" aria-selected="false">On Going Exams</a>
                                    </li>
                                </ul>
                                <div class="tab-content px-1 pt-1">
                                    <div class="tab-pane active" id="home1" aria-labelledby="home-tab1" role="tabpanel">
                                        <div class="row">
                                            <?php if($completed_exams): ?>
                                            <?php $__currentLoopData = $completed_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 col-lg-6 col-xl-6 my-50">
                                                <fieldset>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            name="customCheck" id="customCheck1" checked disabled>
                                                        <label class="custom-control-label text-white"
                                                            for="customCheck1"><?php echo e($key); ?></label>
                                                    </div>
                                                </fieldset>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <div class="white">No Exams Found</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="tab-pane in" id="profile1" aria-labelledby="profile-tab1"
                                        role="tabpanel">
                                        <div class="row">
                                            <?php if($on_going_exams): ?>
                                            <?php $__currentLoopData = $on_going_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 col-xl-6 col-lg-6 my-50">
                                                <fieldset>
                                                    <div class="custom-control custom-checkbox ">
                                                        <input type="checkbox" class="custom-control-input"
                                                            name="customCheck" id="customCheck1" disabled>
                                                        <label class="custom-control-label text-white"
                                                            style="word-break: break-all;"
                                                            for="customCheck1"><?php echo e($key); ?></label>
                                                    </div>
                                                </fieldset>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <div class="white">No Exams Found</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>


<?php if($latestRecord -> created_date != $patient -> created_date): ?>
<script type="text/javascript">
let formControl = document.querySelectorAll('input');
let select = document.querySelectorAll('select');
let submitButton = document.querySelectorAll('button[type=submit]');

select.forEach(element => {
    element.disabled = true;
});

formControl.forEach(element => {
    element.disabled = true;
});

submitButton.forEach(element => {
    element.disabled = true;
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../../../app-assets/js/scripts/signature_pad-master/js/signature_pad.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script src="../../../app-assets/js/scripts/custom.js"></script>
<script>
$(".medical-done").click(function() {
    let id = "<?php echo $patientCode ? $patientCode->id : null ?>";
    let csrf = '<?php echo e(csrf_token()); ?>';
    Swal.fire({
        title: 'Are you sure you want to change it?',
        text: "",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, change it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $(this).html(
                "<button type='button' class='btn btn-solid btn-success'><i class='fa fa-refresh spinner'></i>FIT TO WORK</button>"
            );
            $.ajax({
                url: '/update_lab_result',
                method: 'POST',
                data: {
                    id: id,
                    lab_status: 2,
                    remarks: "Cleared",
                    schedule: null,
                    impression: null,
                    agency_id: '<?php echo e($patientInfo->agency_id); ?>',
                    prescription: null,
                    doctor_prescription: null,
                    _token: csrf
                },
                success: function(response) {
                    if (response.status == 200) {
                        Swal.fire(
                            'Updated!',
                            'Record has been updated.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed) {
                                location.reload();
                            }
                        })
                    } else {
                        Swal.fire(
                            'Error Occured!',
                            'Internal Server Error.',
                            'error'
                        ).then((result) => {
                            if (result.isConfirmed) {
                                location.reload();
                            }
                        })
                    }
                }
            }).done(function(data) {
                $(this).html(
                    "<button type='button' class='btn btn-solid btn-success'>FIT TO WORK</button>"
                )
            });
        }
    })
})

// $(function() {
//     $(document).on('click', '.btn-add', function(e) {
//         e.preventDefault();
//         var controlForm = $('#repeating_yellow_form:first'),
//             currentEntry = $(this).parents('.entry:first'),
//             newEntry = $(currentEntry.clone()).appendTo(controlForm);
//         newEntry.find('input').val('');
//         newEntry.find('#count').val('<?php echo e($count); ?>');
//         controlForm.find('.entry:not(:last) .btn-add')
//             .removeClass('btn-add').addClass('btn-remove')
//             .removeClass('btn-success').addClass('btn-danger')
//             .html('<i class="fa fa-trash"></i>');
//     }).on('click', '.btn-remove', function(e) {
//         e.preventDefault();
//         $(this).parents('.entry:first').remove();
//         return false;
//     });
// });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Patient/edit-patient.blade.php ENDPATH**/ ?>