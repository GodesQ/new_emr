

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Edit Package</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>

                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <form class="form" id="update_package" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($package->id); ?>">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="feather icon-user"></i>Package</h4>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Agency</label>
                                                <select required name="agency" id="" class="form-control select2">
                                                    <option value="<?php echo e($package->agency_id); ?>"><?php echo e($package->agencyname); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($agency->id); ?>"><?php echo e($agency->agencyname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="form-group">
                                                    <label for="">Package Name</label>
                                                    <input type="text" class="form-control" name='package_name'
                                                        value="<?php echo e($package->packagename); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Price</label>
                                                <input type="text" class="form-control" name='price'
                                                    value="<?php echo e($package->price); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Updated at</label>
                                                <input class="form-control" type="text" name="updated_at" value="<?php echo date('Y-m-d');
                                    ?>" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class=" col-md-12">
                                            <div class="form-group">
                                                <div class="form-group">
                                                    <label for="">Exams</label>
                                                    <select name="exams[]" required class="select2 form-control"
                                                        multiple="multiple">
                                                        <?php $__currentLoopData = $selected_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option selected value="<?php echo e($selected_exam->exam_id); ?>">
                                                            <?php echo e($selected_exam->examname); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($exam->id); ?>"><?php echo e($exam->examname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="form-group">
                                                    <label for="">Requests</label>
                                                    <select name="requests[]" required class="select2 form-control"
                                                        multiple="multiple">
                                                        <?php $__currentLoopData = $selected_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected_req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option selected value="<?php echo e($selected_req->request_id); ?>">
                                                            <?php echo e($selected_req->title); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($request->id); ?>"><?php echo e($request->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions">
                                    <a href="/list_package" type="reset" class="btn btn-warning mr-1">
                                        <i class="feather icon-x"></i> Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-check-square-o"></i> Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$("#update_package").submit(function(e) {
    e.preventDefault();
    const fd = new FormData(this);
    $.ajax({
        url: '/update_package',
        method: 'POST',
        data: fd,
        cache: false,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function(response) {
            console.log(response);
            if (response.status == 200) {
                Swal.fire(
                    'Update!',
                    'Package Update Successfully!',
                    'success'
                ).then((result) => {
                    if (result.isConfirmed) {
                        location.reload();
                    }
                })
            } else {
                Swal.fire(
                    'Not Send!',
                    'Chart Account Added Failed!',
                    'warning'
                )
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Package/edit-package.blade.php ENDPATH**/ ?>