<!DOCTYPE html>
<html>

<head>
    <title>Referral Slip</title>
    <style>
    body,
    table,
    tr,
    td {
        font-family: serif;
        font-size: 21px;
        color: green;
    }

    .fontBoldLrg {
        font: bold 15px sans-serif;
    }

    .fontMed {
        font: normal 12px sans-serif;
    }

    .text-below {
        word-spacing: 1rem;
        font-weight: 600;
        font-size: 0.8rem;
        margin-top: 1rem;
    }

    @page  {
        size: letter;
    }
    </style>
</head>

<body>
    <table cellspacing="0" cellpadding="0" width="500">
        <tbody>
            <tr>
                <td>
                    <table width="100%" cellspacing="0" cellpadding="0"  style="margin: 20px 0;">
                        <tbody>
                            <tr>
                                <td>
                                    <div style='text-align: center;'>
                                        <h2 style="font-size: 25px; font-weight: 700; line-height: 10px;">MERITA DIAGNOSTIC CLINIC, INC
                                        </h2>
                                        <div>5th Flr. Jettac Bldg. 920 Pres Quirino Ave,</div>
                                        <div>Cor. San Antonio St. Malate Manila</div>
                                        <div>Tel No. (02) 310-05995 / 0917-8576-942</div>
                                        <div>Accredited: DOH &bull; POEA &bull; MARINA</div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="0" cellpadding="5">
                        <tbody>
                            <tr>
                                <td width="65%"></td>
                                <td width="35%">
                                    Date: <span style="border-bottom: 1px solid green;  color: black;">
                                        <?php echo e($data->prescription_date); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td>Name <span style="border-bottom: 1px solid green;  color: black;">
                                        <?php echo e($patient->firstname); ?> <?php echo e($patient->lastname); ?></span>
                                </td>
                                <td>Age <span style="border-bottom: 1px solid green;  color: black;">
                                        <?php echo e($patient->age); ?></span></td>
                            </tr>
                            <tr>
                                <td colspan="2">Address <span style="border-bottom: 1px solid green;  color: black;">
                                        <?php echo e($patient->address); ?></span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <h3 style="font-size: 50px; font-weight: 600;">Rx</h3>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="height: 440px;">
                        <div style="color: black; margin-left: 80px; font-size: 30px;">
                            <?php echo nl2br($data->prescription) ?>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="0">
                        <tbody>
                            <tr>
                                <td width="60%" rowspan="2"></td>
                            </tr>
                            <tr>
                                <td width="40%">
                                    <table width="100%" cellspacing="0">
                                        <tbody>
                                            <tr>

                                            </tr>
                                            <tr>
                                                <td width="80%">
                                                    <div>
                                                        <img src="<?php echo $doctor->signature ?>" style="width: 60%;object-fit:cover;" alt="">
                                                    </div>
                                                    <div
                                                        style="width: 100%; border-bottom: 1px solid green; color: black;">
                                                        <?php echo e($doctor->firstname . " " . $doctor->lastname); ?></div>
                                                </td>
                                                <td width="20%" style="vertical-align: bottom;">
                                                    <?php echo e($doctor->title); ?>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table width="100%" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td width="30%">
                                                    Lic. No.
                                                </td>
                                                <td width="70%">
                                                    <div style="border-bottom: 1px solid green; color: black;">
                                                        <?php echo e($doctor->license_no); ?></div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html><?php /**PATH C:\merita-app\resources\views/emails/prescription-pdf.blade.php ENDPATH**/ ?>