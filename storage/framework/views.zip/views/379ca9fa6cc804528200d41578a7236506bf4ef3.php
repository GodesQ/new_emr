

<?php $__env->startSection('name'); ?>
<?php echo e($data['firstname'] . " " . $data['lastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('patient_image'); ?>
<?php if($data['patient_image'] != null || $data['patient_image'] != ""): ?>
<img src="../../../app-assets/images/profiles/<?php echo e($data['patient_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .table th, .table td {
        padding: 1rem 0.5rem;
    }
</style>
<!-- BEGIN: Content-->
<div class="container-lg container-fluid">
    <?php if(Session::get('status')): ?>
    <div class="warning alert-warning p-2 my-2 rounded">
        <?php echo e(Session::get('status')); ?>

    </div>
    <?php endif; ?>
    <?php if(Session::get('status_schedule')): ?>
    <div class="success alert-success p-2 my-2 rounded">
        <?php echo e(Session::get('status_schedule')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::get('success')): ?>
    <div class="success alert-success p-2 my-2 rounded">
        <?php echo e(Session::get('success')); ?>

    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
    document.querySelector("#open-instruction").click();
    </script>
    <?php $__env->stopPush(); ?>
    <?php endif; ?>

    <?php if(Session::get('success_support')): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            toastr.success('<?php echo e(Session::get("success_support")); ?>', 'Success');
        </script>
    <?php $__env->stopPush(); ?>
    <?php endif; ?>

    <?php $__env->startSection('latest_schedule'); ?>
    <?php if($latest_schedule): ?>
    <?php echo e($latest_schedule->date); ?>

    <?php endif; ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('patient_info'); ?>
    <div class="row">
        <div class="col-md-12 my-25">
            Patient Name : <b><?php echo e($patient->firstname); ?> <?php echo e($patient->lastname); ?></b>
        </div>
        <div class="col-md-12 my-25">
            Patient Code : <b><?php echo e($patient->patientcode); ?> </b>
        </div>
        <div class="col-md-12 my-25">
            Agency : <b><?php echo e($patientInfo->agencyname); ?></b>
        </div>
        <div class="col-md-12 my-25">
            Medical Package : <b><?php echo e($patientInfo->packagename); ?> </b>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <div class="app-content content">
        <div class="container border p-1 my-1">
            <h6 class="primary float-lg-right">(Screenshot this as proof of schedule)</h6>
            <h6>You are now scheduled on : <b><?php echo e($latest_schedule ? $latest_schedule->date : null); ?></b></h6>
            <div class="row">
                <div class="col-md-12 my-25">
                    Patient Name : <b><?php echo e($patient->firstname); ?> <?php echo e($patient->lastname); ?></b>
                </div>
                <div class="col-md-12 my-25">
                    Patient Code : <b><?php echo e($patient->patientcode); ?> </b>
                </div>
                <div class="col-md-12 my-25">
                    Agency : <b><?php echo e($patientInfo->agencyname); ?></b>
                </div>
                <div class="col-md-12 my-25">
                    Medical Package : <b><?php echo e($patientInfo->packagename); ?> </b>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info alert-dismissible mb-2" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <?php if($latest_schedule): ?>
                    You are scheduled on: <strong><?php echo e($latest_schedule->date); ?></strong><a href="/edit_schedule"
                        class="alert-link ml-1 float-lg-right">Do you want to
                        re-schedule?</a>
                    <?php else: ?>
                    <span>No record of schedule</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-2"></div>
            <?php if($patientAdmission): ?>
            <div class="col-sm-12">
                <div class="alert alert-info alert-dismissible mb-2" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    Your Laboratory Result Status:
                    <strong>
                        <?php if($patientAdmission->lab_status == 2): ?>
                        <b><u>FIT TO WORK</u></b>
                        <?php elseif($patientAdmission->lab_status == 1): ?>
                        <b><u>RE ASSESSMENT</u></b>
                        <?php endif; ?>
                    </strong>
                    <a href="/laboratory_result" class="alert-link ml-1 float-lg-right">View Result</a>
                </div>
            </div>
            <?php else: ?>
            <div class="col-sm-12">
                <div class="alert alert-warning alert-dismissible mb-2" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <strong>You are not admitted</strong></a>.
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-8 col-lg-10 mb-2">
                    <h3 class="content-header-title mb-0">Patient Information</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/progress-patient-info">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="#">Patient</a>
                                </li>
                                <li class="breadcrumb-item active">Patient Information
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <?php if($complete_patient): ?>
                <div class="col-md-4 col-lg-2">
                    <a href="/remedical?patientcode=<?php echo e(session()->get('patientCode')); ?>"
                        class="btn btn-solid btn-primary">Re Medical</a>
                    <a class="btn btn-solid bg-success bg-darken-2 text-white"
                        href="/edit-patient-info?id=<?php echo e($patient->id); ?>">Edit</a>
                </div>
                <?php else: ?>
                <div class="col-md-1 col-lg-2 text-right">
                    <a class="btn btn-solid bg-success bg-darken-2 text-white"
                        href="/edit-patient-info?id=<?php echo e($patient->id); ?>">Edit</a>
                </div>
                <?php endif; ?>
            </div>
            <div class="content-body">
                <div class="content-body">
                    <!-- account setting page start -->
                    <section id="page-account-settings">
                        <div class="row">
                            <!-- left menu section -->
                            <div class="col-md-3 mb-2 mb-md-0">
                                <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                                    <li class="nav-item">
                                        <a class="nav-link d-flex active" id="account-pill-general" data-toggle="pill"
                                            href="#account-vertical-general" aria-expanded="true">
                                            <i class="feather icon-info"></i>
                                            Personal Information
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link d-flex" id="account-pill-connections" data-toggle="pill"
                                            href="#account-vertical-connections" aria-expanded="false">
                                            <i class="feather icon-feather"></i>
                                            Medical History
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link d-flex" id="account-pill-notifications" data-toggle="pill"
                                            href="#account-vertical-notifications" aria-expanded="false">
                                            <i class="feather icon-book"></i>
                                            Declaration Form
                                        </a>
                                    </li>
                                </ul>
                                <div class="col-md-12 my-1">
                                    <h3>Medical Records</h3>
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $patientRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patientRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item <?php echo session()->get('patientId') == $patientRecord->id ? "
                                            active" : " " ?>"><a
                                                class="<?php echo session()->get('patientId') == $patientRecord->id ? "
                                                text-white" : " " ?>"
                                                href="/see_record?created=<?php echo e($patientRecord->created_date); ?>"><?php echo e($patientRecord->created_date); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <!-- right content section -->
                            <div class="col-md-9">
                                <div class="card">
                                    <div class="card-content">
                                        <div class="card-body">
                                            <div class="tab-content">
                                                <div role="tabpanel" class="tab-pane active"
                                                    id="account-vertical-general" aria-labelledby="account-pill-general"
                                                    aria-expanded="true">
                                                    <div class="col-lg-8 col-md-10 col-md-12">
                                                        <h3 class="mt-1"><i class="feather icon-info"></i>
                                                            Personal Info</h3>
                                                        <table class="table table-borderless table-responsive">
                                                            <tbody>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Firstname:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patient->firstname); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Lastname:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patient->lastname); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Middlename:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patient->middlename); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Contact No :
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->contactno); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Email:</td>
                                                                    <td class="col-sm-2"><?php echo e($patient->email); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Address:</td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->address); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Gender:</td>
                                                                    <td class="col-sm-2"><?php echo e($patient->gender); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Age:</td>
                                                                    <td class="col-sm-2"><?php echo e($patient->age); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Occupation:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->occupation); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Nationality:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->nationality); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Religion:
                                                                    </td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->religion); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Marital
                                                                        Status:</td>
                                                                    <td class="col-sm-2">
                                                                        <?php echo e($patientInfo->maritalstatus); ?>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="col-lg-8 col-md-10 col-md-12 my-3">
                                                        <h3 class="mb-1"><i class="feather icon-globe"></i>
                                                            Agency Info</h3>
                                                        <table class="table table-borderless table-responsive">
                                                            <tbody>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Agency Name:
                                                                    </td>
                                                                    <td class="users-view-username col-sm-2">
                                                                        <?php echo e($patientInfo->agencyname); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Agency
                                                                        Address:</td>
                                                                    <td class="users-view-name col-sm-2">
                                                                        <?php echo e($patientInfo->agency_address); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Country
                                                                        Destination:</td>
                                                                    <td class="users-view-email col-sm-2">
                                                                        <?php echo e($patientInfo->country_destination); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Medical
                                                                        Package:</td>
                                                                    <td class="users-view-username col-sm-2">
                                                                        <?php echo e($patientInfo->packagename); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Vessel:</td>
                                                                    <td class="users-view-username col-sm-2">
                                                                        <?php echo e($patientInfo->vessel); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">Passport NO:
                                                                    </td>
                                                                    <td class="users-view-username col-sm-2">
                                                                        <?php echo e($patientInfo->passportno); ?></td>
                                                                </tr>
                                                                <tr class="col-12">
                                                                    <td class="col-md-6 col-lg-4 col-sm-6">SRB NO:</td>
                                                                    <td class="users-view-username col-sm-2">
                                                                        <?php echo e($patientInfo->srbno); ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="account-vertical-connections"
                                                    role="tabpanel" aria-labelledby="account-pill-connections"
                                                    aria-expanded="false">
                                                    <?php if($medicalHistory): ?>
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-6">
                                                            <table class="table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Head and Neck Injury
                                                                        </td>
                                                                        <td><?php if($medicalHistory->head_and_neck_injury
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Frequent Headache
                                                                        </td>
                                                                        <td><?php if($medicalHistory->frequent_headache
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Frequent Dizziness
                                                                        </td>
                                                                        <td><?php if($medicalHistory->frequent_dizziness
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Fainting Spells, Fits
                                                                        </td>
                                                                        <td><?php if($medicalHistory->fainting_spells_fits
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Seizures
                                                                        </td>
                                                                        <td><?php if($medicalHistory->seizures
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Other neurological disorders
                                                                        </td>
                                                                        <td><?php if($medicalHistory->other_neurological_disorders
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Insomia or Sleep disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->insomia_or_sleep_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Depression, other mental
                                                                            disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->depression_other_mental_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Eye problems / Error of
                                                                            refraction
                                                                        </td>
                                                                        <td><?php if($medicalHistory->eye_problems_or_error_refraction
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Deafness / Ear disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->deafness_or_ear_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Nose or Throat disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->nose_or_throat_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Tuberculosis </td>
                                                                        <td><?php if($medicalHistory->tuberculosis
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Signed off as sick
                                                                        </td>
                                                                        <td><?php if($medicalHistory->signed_off_as_sick
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Repatriation form ship
                                                                        </td>
                                                                        <td><?php if($medicalHistory->repatriation_form_ship
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Declared Unfit for sea duty
                                                                        </td>
                                                                        <td><?php if($medicalHistory->declared_unfit_for_sea_duty
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Previous Hospitalization
                                                                        </td>
                                                                        <td><?php if($medicalHistory->previous_hospitalization
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Do you feel healthy /<br>Fit to
                                                                            perform
                                                                            duties of <br> designed position
                                                                        </td>
                                                                        <td><?php if($medicalHistory->feel_healthy
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>

                                                            </table>
                                                        </div>
                                                        <!-- SECOND TABLE -->
                                                        <div class="col-md-12  col-lg-6">
                                                            <table class="table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Other Lung disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->other_lung_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            High Blood Pressure
                                                                        </td>
                                                                        <td><?php if($medicalHistory->high_blood_pressure
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Heart Disease / Vascular
                                                                        </td>
                                                                        <td><?php if($medicalHistory->heart_disease_or_vascular
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Chest pain
                                                                        </td>
                                                                        <td><?php if($medicalHistory->chest_pain
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Rheumatic Fever
                                                                        </td>
                                                                        <td><?php if($medicalHistory->rheumatic_fever
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Diabetes Mellitus
                                                                        </td>
                                                                        <td><?php if($medicalHistory->diabetes_mellitus
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Endocrine disorders (goiter)
                                                                        </td>
                                                                        <td><?php if($medicalHistory->endocrine_disorders
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Cancer or Tumor
                                                                        </td>
                                                                        <td><?php if($medicalHistory->cancer_or_tumor
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Blood disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->blood_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Stomach pain, Gastritis
                                                                        </td>
                                                                        <td><?php if($medicalHistory->stomach_pain_or_gastritis
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Ulcer
                                                                        </td>
                                                                        <td><?php if($medicalHistory->ulcer
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Other Abdominal Disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->other_abdominal_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Medical certificate restricted
                                                                        </td>
                                                                        <td><?php if($medicalHistory->medical_certificate_restricted
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Medical certificate revoked
                                                                        </td>
                                                                        <td><?php if($medicalHistory->medical_certificate_revoked
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Aware of any medical problems
                                                                        </td>
                                                                        <td><?php if($medicalHistory->aware_of_any_medical_problems
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Aware of any disease / illness
                                                                        </td>
                                                                        <td><?php if($medicalHistory->aware_of_any_disease_or_illness
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Operation(s) <br>
                                                                            <b><u><?php echo e($medicalHistory->operation_other); ?></u></b>
                                                                        </td>
                                                                        <td><?php if($medicalHistory->operations
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <!-- THIRD TABLE -->
                                                        <div class="col-md-12 col-lg-6">
                                                            <table class="table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Gynecological Disorders
                                                                        </td>
                                                                        <td><?php if($medicalHistory->gynecological_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Last Menstrual Period
                                                                        </td>
                                                                        <td><?php if($medicalHistory->last_menstrual_period
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Pregnancy
                                                                        </td>
                                                                        <td><?php if($medicalHistory->pregnancy
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Kidney or Bladder Disorder
                                                                        </td>
                                                                        <td><?php if($medicalHistory->kidney_or_bladder_disorder
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Back Injury / Joint pain
                                                                        </td>
                                                                        <td><?php if($medicalHistory->back_injury_or_joint_pain
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Arthritis </td>
                                                                        <td><?php if($medicalHistory->arthritis
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Genetic, Heredity or Familial
                                                                            Dis. </td>
                                                                        <td><?php if($medicalHistory->genetic_heredity_or_familial_dis
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Sexually Transmitted Disease
                                                                            (Syphilis)
                                                                        </td>
                                                                        <td><?php if($medicalHistory->sexually_transmitted_disease
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Tropical Disease - Malaria
                                                                        </td>
                                                                        <td><?php if($medicalHistory->tropical_disease_or_malaria
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Thypoid Fever
                                                                        </td>
                                                                        <td><?php if($medicalHistory->thypoid_fever
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Schistosomiasis
                                                                        </td>
                                                                        <td><?php if($medicalHistory->schistosomiasis
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Asthma
                                                                        </td>
                                                                        <td><?php if($medicalHistory->asthma
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Allergies <br>
                                                                            <b><u><?php echo e($medicalHistory->allergies_other); ?></u></b>
                                                                        </td>
                                                                        <td><?php if($medicalHistory->allergies
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Smoking </td>
                                                                        <td><?php if($medicalHistory->smoking
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Taking medication for
                                                                            Hypertension </td>
                                                                        <td><?php if($medicalHistory->taking_medication_for_hypertension
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Taking medication for Diabetes
                                                                        </td>
                                                                        <td><?php if($medicalHistory->taking_medication_for_diabetes
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12">
                                                                            Vaccination </td>
                                                                        <td><?php if($medicalHistory->vaccination
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="tab-pane fade" id="account-vertical-notifications"
                                                    role="tabpanel" aria-labelledby="account-pill-notifications"
                                                    aria-expanded="false">
                                                    <?php if($declarationForm): ?>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="col-md-12">
                                                                <h4>Have you travelled abroad recently?</h4>
                                                            </div>
                                                            <div class="col-md-4 mt-1">
                                                                <?php if($declarationForm->travelled_abroad_recently
                                                                == 0): ?>
                                                                <span
                                                                    class="btn btn-solid btn-warning isTravelAbroad">No</span>
                                                                <?php else: ?>
                                                                <span
                                                                    class="btn btn-solid btn-success isTravelAbroad">Yes</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 travel mt-2">
                                                            <div class="form-group">
                                                                <label for="">Name of the area(s) visited
                                                                    <span class="danger">*</span>
                                                                </label>
                                                                <fieldset>
                                                                    <input disabled name="area_visited" type="text"
                                                                        id="" placeholder="Country, State, City"
                                                                        class="form-control"
                                                                        value="<?php echo e($declarationForm->area_visited); ?>" />
                                                                </fieldset>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 travel">
                                                            <div class="form-group ">
                                                                <label for="">Date of travel
                                                                    <span class="danger">*</span>
                                                                </label>
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <label class="font-weight-bold"
                                                                            for="">Arrival</label>
                                                                        <input disabled name="travel_arrival_date" id=""
                                                                            placeholder="" class="form-control"
                                                                            type="text"
                                                                            value="<?php echo e($declarationForm->travel_arrival); ?>" />
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <label class="font-weight-bold"
                                                                            for="">Return</label>
                                                                        <input disabled name="travel_return_date" id=""
                                                                            placeholder="" class="form-control"
                                                                            type="text"
                                                                            value="<?php echo e($declarationForm->travel_return); ?>" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 my-2">
                                                            <div class="col-md-12">
                                                                <h4>Have you been in contact with people
                                                                    being infected,
                                                                    suspected or diagnosed with COVID-19?
                                                                </h4>
                                                            </div>
                                                            <div class="col-md-4 mt-1">
                                                                <?php if($declarationForm->contact_with_people_being_infected__suspected_diagnose_with_cov
                                                                == 0): ?>
                                                                <span
                                                                    class="btn btn-solid btn-warning contact-with-cov">No</span>
                                                                <?php else: ?>
                                                                <span
                                                                    class="btn btn-solid btn-success contact-with-cov">Yes</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 show-if-contact">
                                                            <div class="form-group">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <label class="font-weight-bold"
                                                                            for="">Relationship</label>
                                                                        <input disabled
                                                                            name="relationship_last_contact_people"
                                                                            id="" placeholder="" class="form-control"
                                                                            type="text"
                                                                            value="<?php echo e($declarationForm->relationship_with_last_people); ?>" />
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <label class="font-weight-bold" for="">Last
                                                                            contact
                                                                            date</label>
                                                                        <input disabled name="last_contact_date" id=""
                                                                            placeholder="" class="form-control"
                                                                            type="text"
                                                                            value="<?php echo e($declarationForm->last_contact_date); ?>" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 my-2">
                                                            <table class="table table-striped">
                                                                <tbody>
                                                                    <tr>
                                                                        <td class="col-12 h4">Fever</td>
                                                                        <td>
                                                                            <?php if($declarationForm->fever
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12 h4">Cough</td>
                                                                        <td> <?php if($declarationForm->cough
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12 h4">Shortness of
                                                                            Breath</td>
                                                                        <td>
                                                                            <?php if($declarationForm->shortness_of_breath
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="col-12 h4">Persistent
                                                                            Pain in the
                                                                            Chest</td>
                                                                        <td>
                                                                            <?php if($declarationForm->persistent_pain_in_chest
                                                                            == 0): ?>
                                                                            <span
                                                                                class="btn btn-solid btn-warning">No</span>
                                                                            <?php else: ?>
                                                                            <span
                                                                                class="btn btn-solid btn-success">Yes</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            </section>
            <!-- account setting page end -->
        </div>
    </div>
</div>
</div>
</div>
<script>
function hasTravelAbroad() {
    let isTravelAbroad = document.querySelectorAll('.isTravelAbroad');
    let travelElement = document.querySelectorAll('.travel');
    for (let index = 0; index < isTravelAbroad.length; index++) {
        const element = isTravelAbroad[index];
        if (element.innerHTML == "No") {
            travelElement[0].style.display = "none";
            travelElement[1].style.display = "none";
        } else {
            travelElement[0].style.display = "block";
            travelElement[1].style.display = "block";
        }
    }
}

function hasContactWithCovid() {
    let isContactWithCov = document.querySelectorAll('.contact-with-cov');
    let showIfContact = document.querySelector('.show-if-contact');
    for (let index = 0; index < isContactWithCov.length; index++) {
        const element = isContactWithCov[index];
        if (element.innerHTML == "No") {
            showIfContact.style.display = "none";
        } else {
            showIfContact.style.display = "block";
        }
    }
}
hasTravelAbroad();
hasContactWithCovid();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/ProgressInfo/patient-info.blade.php ENDPATH**/ ?>