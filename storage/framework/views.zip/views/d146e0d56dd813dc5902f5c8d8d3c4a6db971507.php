<html>

<head>
    <title>SCREENING DRUG TEST REPORT</title>
    <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
</head>

<body>
    <center>
        <table width="680" border="0" cellpadding="2" cellspacing="0" class="brdAll">
            <tbody>
                <tr>
                    <td colspan="3" align="left">
                        <table width="100%" border="0" cellspacing="0" cellpadding="4">
                            <tbody>
                                <tr>
                                    <td width="19%"><img src="../../../app-assets/images/logo/logo.jpg" width="80"
                                            height="80" alt=""> </td>
                                    <td width="62%" align="center" valign="top">
                                        <p><span style="font-family:times new roman; font-size:18px; font-weight:bold;">MERITA
                                                DIAGNOSTIC CLINIC, INC.</span> <br>
                                            <span class="lblCompDtl"> 5th &amp; 6th Floor Jettac Bldg. 920 Pres Quirino
                                                Ave, Cor. San Antonio St. Malate Manila <br>
                                                Tel No. (02) 310-0595 / 0917-8576-942 Email: meritaclinic@gmail.com
                                            </span>
                                        </p>
                                        <p><span class="lblCompDtl"><span class="lblReport">SCREENING DRUG TEST
                                                    REPORT</span><br>
                                                <br>
                                            </span></p>
                                    </td>
                                    <td width="19%"><img src="pics/patient/P22-007414.jpg" alt="Patient Picture"
                                            width="120" height="100" class="brdAll"></td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                    <td height="20" align="center" valign="bottom">&nbsp;</td>
                                    <td align="center"> </td>
                                </tr>
                                <tr>
                                    <td height="10" colspan="3">
                                        <hr>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="30" colspan="3" align="left" valign="middle">
                        <table width="678" border="0" cellspacing="0" cellpadding="3">
                            <tbody>
                                <tr>
                                    <td colspan="3"><b>Name:</b>
                                        <?php echo e($admission->lastname . ', ' . $admission->firstname . " " . $admission->middlename); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td width="85"><b>Age:</b>
                                        <?php echo e($admission->age); ?></td>
                                    <td width="249"><b>Sex:</b>
                                        <?php echo e($admission->gender); ?></td>
                                    <td width="248"><b>Occupation:</b>
                                        <?php echo e($gen_info->occupation); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><b>Date of Birth:</b>
                                        <?php echo e($gen_info->birthdate); ?></td>
                                    <td><b>Place of Birth:</b>
                                        <?php echo e($gen_info->birthplace); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><b>Address:</b>
                                        <?php echo e($gen_info->address); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><b>Purpose:</b>
                                        <?php echo e($exam->purpose_other); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><b>Date &amp; Time of Received:</b> <?php echo e($exam->trans_date); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><b>Requesting Party:</b> <?php echo e($agency->agencyname); ?></td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                    <td colspan="2">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="3" align="right">
                                        <table width="580" border="0" cellspacing="0" cellpadding="4">
                                            <tbody>
                                                <tr>
                                                    <td width="568" valign="top">
                                                        <table width="100%" border="0" cellpadding="4" cellspacing="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="3" align="left">FINDINGS: Screening
                                                                        Test by - <b>Test Kit</b></td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="3" align="left">Gave the following
                                                                        result:</td>
                                                                </tr>
                                                                <?php if($exam->methamphetamine != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Methamphetamine</b>
                                                                    </td>
                                                                    <td width="24%" align="left">
                                                                        <?php echo e($exam->methamphetamine); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->tetrahydrocannabinol != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left">
                                                                        <b>Tetrahydrocannabinol</b>
                                                                    </td>
                                                                    <td align="left"><?php echo e($exam->tetrahydrocannabinol); ?>

                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->morphine != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Morphine</b></td>
                                                                    <td align="left"><?php echo e($exam->morphine); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->cocaine != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" height="14" align="left">
                                                                        <b>Cocaine</b>
                                                                    </td>
                                                                    <td align="left"><?php echo e($exam->cocaine); ?></td>
                                                                </tr>
                                                                <?php endif; ?>


                                                                <?php if($exam->phencyclidine != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Phencyclidine</b>
                                                                    </td>
                                                                    <td align="left"><?php echo e($exam->phencyclidine); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->alcohol != ""): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Alcohol</b></td>
                                                                    <td align="left"><?php echo e($exam->alcohol); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->barbiturates): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Barbiturates</b>
                                                                    </td>
                                                                    <td align="left"><?php echo e($exam->barbiturates); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->ecstacy): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Ecstacy</b></td>
                                                                    <td align="left"><?php echo e($exam->ecstacy); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->benzodiazepine): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Benzodiazepine</b>
                                                                    </td>
                                                                    <td align="left"><?php echo e($exam->benzodiazepine); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->opiapes): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Opiapes</b></td>
                                                                    <td align="left"><?php echo e($exam->opiapes); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->methadone): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Methadone</b></td>
                                                                    <td align="left"><?php echo e($exam->methadone); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                                <?php if($exam->metaqualone): ?>
                                                                <tr>
                                                                    <td width="6%" align="left">&nbsp;</td>
                                                                    <td width="70%" align="left"><b>Metaqualone</b></td>
                                                                    <td align="left"><?php echo e($exam->metaqualone); ?></td>
                                                                </tr>
                                                                <?php endif; ?>

                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60" colspan="3" align="center" valign="middle">&nbsp;</td>
                </tr>
                <tr>
                    <td width="300" align="center" valign="top">
                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                            <tbody>
                                <tr valign="bottom">
                                    <td align="left">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="100" align="center" valign="bottom"></td>
                                </tr>
                                <tr valign="bottom">
                                    <td align="center" class="brdTop">
                                        <?php if($technician1): ?>
                                        <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?><br>
                                        Medical Technologist<br>
                                        Lic. No.
                                        <?php echo e($technician1->license_no); ?>       
                                        <?php endif; ?>    
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                    <td width="296" align="center" valign="top">
                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                            <tbody>
                                <tr valign="bottom">
                                    <td align="left">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="100" align="center" valign="bottom"></td>
                                </tr>
                                <tr valign="bottom">
                                    <td align="center" class="brdTop">
                                        <?php if($technician2): ?>
                                        <?php echo e($technician2->firstname . " " . $technician2->middlename . " " . $technician2->lastname . ", " . $technician2->title); ?><br>
                                        Pathologist<br>
                                        Lic. No.: <?php echo e($technician2->license_no); ?>                                       
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr style="margin-top: 2rem;">
                    <td colspan="3" valign="top"><span class="lblForm">FORM NO. 33 REV. 00 /
                            20-02-2018</span></td>
                </tr>
            </tbody>
        </table>
    </center>

</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/examlab_drug_print.blade.php ENDPATH**/ ?>