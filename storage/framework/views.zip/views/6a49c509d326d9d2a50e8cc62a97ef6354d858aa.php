

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts d-flex">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title" id="basic-layout-form">Daily Patient List</h4>
                                <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li><a data-action="collapse"><i class="feather icon-minus"></i></a></li>
                                        <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a></li>
                                        <li><a data-action="expand"><i class="feather icon-maximize"></i></a></li>
                                        <li><a data-action="close"><i class="feather icon-x"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                    <form class="form" action="/daily_patient" method="GET" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-12">
                                            <div class="form-body">
                                                <h4 class="form-section"><i class="feather icon-user"></i>Daily Patient List</h4>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="">Schedule Date</label>
                                                            <input type="date" required class="form-control"  value="" name="date">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions">
                                                <a href="/patient_info" class="btn btn-warning mr-1">
                                                    <i class="feather icon-x"></i> Cancel
                                                </a>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fa fa-check-square-o"></i> Save and Print
                                                </button>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintPanel/daily_patient_form.blade.php ENDPATH**/ ?>