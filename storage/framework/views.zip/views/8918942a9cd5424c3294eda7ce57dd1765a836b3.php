

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Ishihara</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_ishihara" role="form">
                            <?php if(Session::get('status')): ?>
                                <?php $__env->startPush('scripts'); ?>
                                    <script>
                                       toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2" class="table">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table">
                                <tbody>
                                    <tr>
                                        <td width="17%"><b>RESULT</b></td>
                                        <td width="83%">
                                            <input name="result" type="radio" id="result_0" value="Adequate" <?php echo
                                                $exam->result == 'Adequate' ? 'checked' : ''
                                            ?>>&nbsp;&nbsp;Adequate
                                            <input name="result" type="radio" id="result_1" value="Defective" <?php echo
                                                $exam->result == 'Defective' ? 'checked' : ''
                                            ?>>&nbsp;&nbsp;Defective
                                            <input name="result" type="radio" id="result_2" value="Reset" <?php echo
                                                $exam->result == 'Normal' ? 'Reset' : '' ?>>&nbsp;&nbsp;Reset
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="16%"><b>Optometrist: </b></td>
                                                        <td width="84%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "44" ? 'selected' : null); ?>

                                                                        value="44">Lea S. Genova, O.D.</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Ishihara/edit-ishihara.blade.php ENDPATH**/ ?>