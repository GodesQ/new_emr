

<?php $__env->startSection('name'); ?>
<?php echo e($data['firstname'] . " " . $data['lastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('patient_image'); ?>
<?php if($data['patient_image'] != null || $data['patient_image'] != ""): ?>
<img src="../../../app-assets/images/profiles/<?php echo e($data['patient_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts d-flex">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <?php if($latest_schedule): ?>
                                <h5>Your latest schedule is : <b><u> <?php echo e($latest_schedule->date); ?></u></b></h5>
                                <?php else: ?>
                                <h5>No records of schedule</h5>
                                <?php endif; ?>
                            </div>
                            <?php if(count($schedules) != 0): ?>
                            <div class="card-body">
                                <h4>Scheduled List</h4>
                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul class="list-group">
                                    <li
                                        class="list-group-item <?php echo $schedule->date == $latest_schedule->date ? 'active' : '' ?>">
                                        <?php echo e($schedule->date); ?></li>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title" id="basic-layout-form">Add Schedule</h4>
                                <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li><a data-action="collapse"><i class="feather icon-minus"></i></a></li>
                                        <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a></li>
                                        <li><a data-action="expand"><i class="feather icon-maximize"></i></a></li>
                                        <li><a data-action="close"><i class="feather icon-x"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body">
                                    <form class="form" action="/store_schedule" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-12">
                                            <div class="form-body">
                                                <h4 class="form-section"><i class="feather icon-user"></i>Schedule</h4>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="">Schedule Date</label>
                                                            <input readonly type="text" required class="form-control"
                                                                id="date-picker" value="" name="schedule_date"
                                                                <?php echo e(count($scheduled_patients) == 50 ? "disabled" : null); ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions">
                                                <a href="/patient_info" class="btn btn-warning mr-1">
                                                    <i class="feather icon-x"></i> Cancel
                                                </a>
                                                <button type="submit" class="btn btn-primary"
                                                    <?php echo e(count($scheduled_patients) == 50 ? "disabled" : null); ?>>
                                                    <i class="fa fa-check-square-o"></i> Save
                                                </button>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
<script>
$(function() {
    var dateToday = new Date();
    $("#date-picker").datepicker({
        minDate: dateToday,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'yy-mm-dd'
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/ProgressInfo/schedule.blade.php ENDPATH**/ ?>