

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Add Agency</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <form class="form" action="/store_agency" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="form-body">
                                        <h4 class="form-section"><i class="feather icon-user"></i>Agency</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Email Address</label>
                                                    <input required type="email" class="form-control" name="email">
                                                    <span class="danger text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Agency Name</label>
                                                    <input required type="text" class="form-control" name="agencyname">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <div class="form-group">
                                                        <label for="">Address</label>
                                                        <input required type="text" class="form-control" name='address'>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Principal</label>
                                                    <input required type="text" class="form-control" name='principal'>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="form-group">
                                                        <label for="">Telephone No.</label>
                                                        <input required type="tel" class="form-control" name="telno">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Fax No.</label>
                                                    <input required type="text" class="form-control" name='faxno'>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Contact Person</label>
                                                    <input required type="text" class="form-control"
                                                        name="contact_person">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Remarks</label>
                                                    <input required type="text" class="form-control" name="remarks">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Registered at</label>
                                                    <input class="form-control" type="text" name="registered_at" value="<?php echo date('Y-m-d');
                                    ?>" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-5">
                                                <div class="form-group">
                                                    <div class="form-group">
                                                        <label for="">Arrangement Type</label><br>
                                                        <div class="my-1">
                                                            <div
                                                                class="d-inline-block custom-control custom-radio mr-1">
                                                                <input required type="radio"
                                                                    class="custom-control-input" name="arrangement_type"
                                                                    id="radio1" value="Cash">
                                                                <label class="custom-control-label"
                                                                    for="radio1">Cash</label>
                                                            </div>
                                                            <div
                                                                class="d-inline-block custom-control custom-radio mr-1">
                                                                <input required type="radio"
                                                                    class="custom-control-input" name="arrangement_type"
                                                                    id="radio2" checked value="Charge">
                                                                <label class="custom-control-label"
                                                                    for="radio2">Charge</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1">
                                                <div class="form-group">
                                                    <label for="">Commission (%)</label>
                                                    <input type="number" class="form-control" name="commission">
                                                </div>
                                                <span
                                                    class="danger text-danger"><?php $__errorArgs = ['commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <a href="/agencies" type="reset" class="btn btn-warning mr-1">
                                            <i class="feather icon-x"></i> Cancel
                                        </a>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fa fa-check-square-o"></i> Save
                                        </button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Agency/add-agency.blade.php ENDPATH**/ ?>