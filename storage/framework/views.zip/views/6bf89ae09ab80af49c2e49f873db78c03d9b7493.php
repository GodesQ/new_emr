

<?php $__env->startSection('content'); ?>
<style>
.form-control {
    padding: 0.2rem;
}

.table th,
.table td {
    padding: 0.5rem;
}
</style>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Audiometry</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2 table-responsive">
                        <form name="frm" method="post" action="/update_audiometry" role="form">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input required name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input required name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input required required-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input required name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input required required required name="patientname" id="patientname"
                                                type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input required required required name="patientcode" id="patientcode"
                                                type="text" value="<?php echo e($exam->patientcode); ?>" class="form-control"
                                                readonly=""></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2" class="table table-bordered">
                                <tr>
                                    <td width="10%"><b><u>AIR</u></b></td>
                                    <td width="10%" align="center"><b>250</b></td>
                                    <td width="10%" align="center"><b>500</b></td>
                                    <td width="10%" align="center"><b>750</b></td>
                                    <td width="10%" align="center"><b>1000</b></td>
                                    <td width="10%" align="center"><b>2000</b></td>
                                    <td width="10%" align="center"><b>3000</b></td>
                                    <td width="10%" align="center"><b>4000</b></td>
                                    <td width="10%" align="center"><b>6000</b></td>
                                    <td width="10%" align="center"><b>8000 </b></td>
                                </tr>
                                <tr>
                                    <td><b>Right Ear:</b></td>
                                    <td align="center"><input name="air_right1" type="number" max="999"   class="form-control"
                                            id="air_right1" value="<?php echo e($exam->air_right1); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right2" type="number" max="999"   class="form-control"
                                            id="air_right2" value="<?php echo e($exam->air_right2); ?>" size="5" />
                                    <td align="center"><input name="air_right3" type="number" max="999"   class="form-control"
                                            id="air_right3" value="<?php echo e($exam->air_right3); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right4" type="number" max="999"   class="form-control"
                                            id="air_right4" value="<?php echo e($exam->air_right4); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right5" type="number" max="999"   class="form-control"
                                            id="air_right5" value="<?php echo e($exam->air_right5); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right6" type="number" max="999"   class="form-control"
                                            id="air_right6" value="<?php echo e($exam->air_right6); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right7" type="number" max="999"   class="form-control"
                                            id="air_right7" value="<?php echo e($exam->air_right7); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right8" type="number" max="999"   class="form-control"
                                            id="air_right8" value="<?php echo e($exam->air_right8); ?>" size="5" /></td>
                                    <td align="center"><input name="air_right9" type="number" max="999"   class="form-control"
                                            id="air_right9" value="<?php echo e($exam->air_right9); ?>" size="5" /></td>
                                </tr>
                                <tr>
                                    <td><b>Left Ear:</b></td>
                                    <td align="center"><input name="air_left1" type="number" max="999"   class="form-control"
                                            id="air_left1" value="<?php echo e($exam->air_left1); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left2" type="number" max="999"   class="form-control"
                                            id="air_left2" value="<?php echo e($exam->air_left2); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left3" type="number" max="999"   class="form-control"
                                            id="air_left3" value="<?php echo e($exam->air_left3); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left4" type="number" max="999"   class="form-control"
                                            id="air_left4" value="<?php echo e($exam->air_left4); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left5" type="number" max="999"   class="form-control"
                                            id="air_left5" value="<?php echo e($exam->air_left5); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left6" type="number" max="999"   class="form-control"
                                            id="air_left6" value="<?php echo e($exam->air_left6); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left7" type="number" max="999"   class="form-control"
                                            id="air_left7" value="<?php echo e($exam->air_left7); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left8" type="number" max="999"   class="form-control"
                                            id="air_left8" value="<?php echo e($exam->air_left8); ?>" size="5" /></td>
                                    <td align="center"><input name="air_left9" type="number" max="999"   class="form-control"
                                            id="air_left9" value="<?php echo e($exam->air_left9); ?>" size="5" /></td>
                                </tr>
                                <tr>
                                    <td colspan="10"><b><u>BONE</u></b></td>
                                </tr>
                                <tr>
                                    <td><b>Right Ear:</b></td>
                                    <td align="center"><input name="bone_right1" type="number" max="999"   class="form-control"
                                            id="bone_right1" value="<?php echo e($exam->bone_right1); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right2" type="number" max="999"   class="form-control"
                                            id="bone_right2" value="<?php echo e($exam->bone_right2); ?>" size="5" />
                                    <td align="center"><input name="bone_right3" type="number" max="999"   class="form-control"
                                            id="bone_right3" value="<?php echo e($exam->bone_right3); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right4" type="number" max="999"   class="form-control"
                                            id="bone_right4" value="<?php echo e($exam->bone_right4); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right5" type="number" max="999"   class="form-control"
                                            id="bone_right5" value="<?php echo e($exam->bone_right5); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right6" type="number" max="999"   class="form-control"
                                            id="bone_right6" value="<?php echo e($exam->bone_right6); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right7" type="number" max="999"   class="form-control"
                                            id="bone_right7" value="<?php echo e($exam->bone_right7); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right8" type="number" max="999"   class="form-control"
                                            id="bone_right8" value="<?php echo e($exam->bone_right8); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_right9" type="number" max="999"   class="form-control"
                                            id="bone_right9" value="<?php echo e($exam->bone_right9); ?>" size="5" /></td>
                                </tr>
                                <tr>
                                    <td><b>Left Ear:</b></td>
                                    <td align="center"><input name="bone_left1" type="number" max="999"   class="form-control"
                                            id="bone_left1" value="<?php echo e($exam->bone_left1); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left2" type="number" max="999"   class="form-control"
                                            id="bone_left2" value="<?php echo e($exam->bone_left2); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left3" type="number" max="999"   class="form-control"
                                            id="bone_left3" value="<?php echo e($exam->bone_left3); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left4" type="number" max="999"   class="form-control"
                                            id="bone_left4" value="<?php echo e($exam->bone_left4); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left5" type="number" max="999"   class="form-control"
                                            id="bone_left5" value="<?php echo e($exam->bone_left5); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left6" type="number" max="999"   class="form-control"
                                            id="bone_left6" value="<?php echo e($exam->bone_left6); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left7" type="number" max="999"   class="form-control"
                                            id="bone_left7" value="<?php echo e($exam->bone_left7); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left8" type="number" max="999"   class="form-control"
                                            id="bone_left8" value="<?php echo e($exam->bone_left8); ?>" size="5" /></td>
                                    <td align="center"><input name="bone_left9" type="number" max="999"   class="form-control"
                                            id="bone_left9" value="<?php echo e($exam->bone_left9); ?>" size="5" /></td>
                                </tr>
                                <tr>
                                    <td><b><u>FREE FIELD</u></b></td>
                                    <td align="center"><input name="free_field1" type="number" max="999"   class="form-control"
                                            id="free_field1" value="<?php echo e($exam->free_field1); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field2" type="number" max="999"   class="form-control"
                                            id="free_field2" value="<?php echo e($exam->free_field2); ?>" size="5" />
                                    <td align="center"><input name="free_field3" type="number" max="999"   class="form-control"
                                            id="free_field3" value="<?php echo e($exam->free_field3); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field4" type="number" max="999"   class="form-control"
                                            id="free_field4" value="<?php echo e($exam->free_field4); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field5" type="number" max="999"   class="form-control"
                                            id="free_field5" value="<?php echo e($exam->free_field5); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field6" type="number" max="999"   class="form-control"
                                            id="free_field6" value="<?php echo e($exam->free_field6); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field7" type="number" max="999"   class="form-control"
                                            id="free_field7" value="<?php echo e($exam->free_field7); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field8" type="number" max="999"   class="form-control"
                                            id="free_field8" value="<?php echo e($exam->free_field8); ?>" size="5" /></td>
                                    <td align="center"><input name="free_field9" type="number" max="999"   class="form-control"
                                            id="free_field9" value="<?php echo e($exam->free_field9); ?>" size="5" /></td>
                                </tr>
                                <tr>
                                    <td colspan="10"><b><u>Aided</u></b></td>
                                </tr>
                                <tr>
                                    <td><b>Right Ear:</b></td>
                                    <td align="center"><input name='aided_right1' type="number" max="999"   class="form-control"
                                            id="aided_right1" value="<?php echo e($exam->aided_right1); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right2" type="number" max="999"   class="form-control"
                                            id="aided_right2" value="<?php echo e($exam->aided_right2); ?>" size="5">
                                    </td>
                                    <td align="center"><input name="aided_right3" type="number" max="999"   class="form-control"
                                            id="aided_right3" value="<?php echo e($exam->aided_right3); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right4" type="number" max="999"   class="form-control"
                                            id="aided_right4" value="<?php echo e($exam->aided_right4); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right5" type="number" max="999"   class="form-control"
                                            id="aided_right5" value="<?php echo e($exam->aided_right5); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right6" type="number" max="999"   class="form-control"
                                            id="aided_right6" value="<?php echo e($exam->aided_right6); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right7" type="number" max="999"   class="form-control"
                                            id="aided_right7" value="<?php echo e($exam->aided_right7); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right8" type="number" max="999"   class="form-control"
                                            id="aided_right8" value="<?php echo e($exam->aided_right8); ?>" size="5"></td>
                                    <td align="center"><input name="aided_right9" type="number" max="999"   class="form-control"
                                            id="aided_right9" value="<?php echo e($exam->aided_right9); ?>" size="5"></td>
                                </tr>
                                <tr>
                                    <td><b>Left Ear:</b></td>
                                    <td align="center"><input name="aided_left1" type="number" max="999"   class="form-control"
                                            id="aided_left1" value="<?php echo e($exam->aided_left1); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left2" type="number" max="999"   class="form-control"
                                            id="aided_left2" value="<?php echo e($exam->aided_left2); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left3" type="number" max="999"   class="form-control"
                                            id="aided_left3" value="<?php echo e($exam->aided_left3); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left4" type="number" max="999"   class="form-control"
                                            id="aided_left4" value="<?php echo e($exam->aided_left4); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left5" type="number" max="999"   class="form-control"
                                            id="aided_left5" value="<?php echo e($exam->aided_left5); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left6" type="number" max="999"   class="form-control"
                                            id="aided_left6" value="<?php echo e($exam->aided_left6); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left7" type="number" max="999"   class="form-control"
                                            id="aided_left7" value="<?php echo e($exam->aided_left7); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left8" type="number" max="999"   class="form-control"
                                            id="aided_left8" value="<?php echo e($exam->aided_left8); ?>" size="5"></td>
                                    <td align="center"><input name="aided_left9" type="number" max="999"   class="form-control"
                                            id="aided_left9" value="<?php echo e($exam->aided_left9); ?>" size="5"></td>
                                </tr>
                                <tr>
                                    <td><b><u>FREE FIELD</u></b></td>
                                    <td align="center"><input name="aided_free_field1" type="number" max="999"   class="form-control"
                                            id="aided_free_field1" value="<?php echo e($exam->aided_free_field1); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field2" type="number" max="999"   class="form-control"
                                            id="aided_free_field2" value="<?php echo e($exam->aided_free_field2); ?>" size="5">
                                    </td>
                                    <td align="center"><input name="aided_free_field3" type="number" max="999"   class="form-control"
                                            id="aided_free_field3" value="<?php echo e($exam->aided_free_field3); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field4" type="number" max="999"   class="form-control"
                                            id="aided_free_field4" value="<?php echo e($exam->aided_free_field4); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field5" type="number" max="999"   class="form-control"
                                            id="aided_free_field5" value="<?php echo e($exam->aided_free_field5); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field6" type="number" max="999"   class="form-control"
                                            id="aided_free_field6" value="<?php echo e($exam->aided_free_field6); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field7" type="number" max="999"   class="form-control"
                                            id="aided_free_field7" value="<?php echo e($exam->aided_free_field7); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field8" type="number" max="999"   class="form-control"
                                            id="aided_free_field8" value="<?php echo e($exam->aided_free_field8); ?>" size="5"></td>
                                    <td align="center"><input name="aided_free_field9" type="number" max="999"   class="form-control"
                                            id="aided_free_field9" value="<?php echo e($exam->aided_free_field9); ?>" size="5"></td>
                                </tr>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2" class="table">
                                <tr>
                                    <td width="50%" align="center">
                                        <table width="80%" border="0" cellpadding="2" cellspacing="0" class="">
                                            <tr>
                                                <td colspan="4" align="center"><b>SPEECH AUDIOMETRY</b></td>
                                            </tr>
                                            <tr>
                                                <td width="68">&nbsp;</td>
                                                <td width="72" align="center">RIGHT</td>
                                                <td width="73" align="center">LEFT</td>
                                                <td width="71" align="center">FF</td>
                                            </tr>
                                            <tr>
                                                <td align="center">SRT</td>
                                                <td align="right"><input name="srt_right" type="number" max="999"  
                                                        class="form-control" id="srt_right"
                                                        value="<?php echo e($exam->srt_right); ?>" size="5" /></td>
                                                <td align="right"><input name="srt_left" type="number" max="999"  
                                                        class="form-control" id="srt_left" value="<?php echo e($exam->srt_left); ?>"
                                                        size="5" /></td>
                                                <td align="right"><input name="srt_ff" type="number" max="999"   class="form-control"
                                                        id="srt_ff" value="<?php echo e($exam->srt_ff); ?>" size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">SD</td>
                                                <td align="right"><input name="sd_right" type="number" max="999"  
                                                        class="form-control" id="sd_right" value="<?php echo e($exam->sd_right); ?>"
                                                        size="5" /></td>
                                                <td align="right"><input name="sd_left" type="number" max="999"   class="form-control"
                                                        id="sd_left" value="<?php echo e($exam->sd_left); ?>" size="5" /></td>
                                                <td align="right"><input name="sd_ff" type="number" max="999"   class="form-control"
                                                        id="sd_ff" value="<?php echo e($exam->sd_ff); ?>" size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">MCL</td>
                                                <td align="right"><input name="mcl_right" type="number" max="999"  
                                                        class="form-control" id="mcl_right"
                                                        value="<?php echo e($exam->mcl_right); ?>" size="5" /></td>
                                                <td align="right"><input name="mcl_left" type="number" max="999"  
                                                        class="form-control" id="mcl_left" value="<?php echo e($exam->mcl_left); ?>"
                                                        size="5" /></td>
                                                <td align="right"><input name="mcl_ff" type="number" max="999"   class="form-control"
                                                        id="mcl_ff" value="<?php echo e($exam->mcl_ff); ?>" size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">TOL</td>
                                                <td align="right"><input name="tol_right" type="number" max="999"  
                                                        class="form-control" id="tol_right"
                                                        value="<?php echo e($exam->tol_right); ?>" size="5" /></td>
                                                <td align="right"><input name="tol_left" type="number" max="999"  
                                                        class="form-control" id="tol_left" value="<?php echo e($exam->tol_left); ?>"
                                                        size="5" /></td>
                                                <td align="right"><input name="tol_ff" type="number" max="999"   class="form-control"
                                                        id="tol_ff" value="<?php echo e($exam->tol_ff); ?>" size="5" /></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="50%" align="center">
                                        <table width="80%" border="0" cellpadding="2" cellspacing="0">
                                            <tr>
                                                <td colspan="3" align="center"><b>TYMPANOMETRY TEST</b></td>
                                            </tr>
                                            <tr>
                                                <td width="68">&nbsp;</td>
                                                <td width="72" align="center">RIGHT</td>
                                                <td width="73" align="center">LEFT</td>
                                            </tr>
                                            <tr>
                                                <td align="center">TYPE</td>
                                                <td align="right"><input name="type_right" type="number" max="999"  
                                                        class="form-control" id="type_right"
                                                        value="<?php echo e($exam->type_right); ?>" size="5" /></td>
                                                <td align="right"><input name="type_left" type="number" max="999"  
                                                        class="form-control" id="type_left"
                                                        value="<?php echo e($exam->type_left); ?>" size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">ECV</td>
                                                <td align="right"><input name="ecv_right" type="number" max="999"  
                                                        class="form-control" id="ecv_right"
                                                        value="<?php echo e($exam->ecv_right); ?>" size="5" /></td>
                                                <td align="right"><input name="ecv_left" type="number" max="999"  
                                                        class="form-control" id="ecv_left" value="<?php echo e($exam->ecv_left); ?>"
                                                        size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">COMPLIANCE</td>
                                                <td align="right"><input name="comp_right" type="number" max="999"  
                                                        class="form-control" id="comp_right"
                                                        value="<?php echo e($exam->comp_right); ?>" size="5" /></td>
                                                <td align="right"><input name="comp_left" type="number" max="999"  
                                                        class="form-control" id="comp_left"
                                                        value="<?php echo e($exam->comp_left); ?>" size="5" /></td>
                                            </tr>
                                            <tr>
                                                <td align="center">PRESSURE</td>
                                                <td align="right"><input name="press_right" type="number" max="999"  
                                                        class="form-control" id="press_right"
                                                        value="<?php echo e($exam->press_right); ?>" size="5" /></td>
                                                <td align="right"><input name="press_left" type="number" max="999"  
                                                        class="form-control" id="press_left"
                                                        value="<?php echo e($exam->press_left); ?>" size="5" /></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <input name="hearing" type="radio" class="m-1" id="hearing_0"
                                                    value="aided" <?php echo $exam->hearing == "aided" ? "checked" : null
                                                ?>>Aided
                                                <input name="hearing" type="radio" class="m-1" id="hearing_1"
                                                    value="unaided" <?php echo $exam->hearing == "unaided" ? "checked" :
                                                null ?>>Unaided
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <label>Right Ear Result</label>
                                                <input name="left_ear_result" type="radio" class="m-1" id="left_ear_result_1"
                                                    value="Adequate" <?php echo e($exam->left_ear_result == 'Adequate' ? 'checked' : null); ?>>Adequate
                                                <input name="left_ear_result" type="radio" class="m-1" id="left_ear_result_0"
                                                    value="Inadequate" <?php echo e($exam->left_ear_result == 'Inadequate' ? 'checked' : null); ?>>Inadequate
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <label>Left Ear Result</label>
                                                <input name="right_ear_result" type="radio" class="m-1" id="right_ear_result_1"
                                                    value="Adequate" <?php echo e($exam->right_ear_result == 'Adequate' ? 'checked' : null); ?>>Adequate
                                                <input name="right_ear_result" type="radio" class="m-1" id="right_ear_result_0"
                                                    value="Inadequate" <?php echo e($exam->right_ear_result == 'Inadequate' ? 'checked' : null); ?>>Inadequate
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="16%"><b>Audiometrician: </b></td>
                                                        <td width="84%">
                                                            <div class="col-md-8">
                                                                <select name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $audiometricians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audiometrician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($audiometrician->id); ?>><?php echo e($audiometrician->lastname); ?>, <?php echo e($audiometrician->firstname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b><span class="brdTop">Otolaryngologist</span>:
                                                            </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select name="technician2_id" id="technician2_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $otolaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otolary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($otolary->id); ?>> <?php echo e($otolary->lastname); ?>, <?php echo e($otolary->firstname); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            </td>
                            </tr>
                            </table>
                            <div class="box-footer my-2">
                                <input type="hidden"  value="<?php echo date('Y-m-d') ?>" name="updated_date"/>
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </section>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Audiometry/edit-audiometry.blade.php ENDPATH**/ ?>