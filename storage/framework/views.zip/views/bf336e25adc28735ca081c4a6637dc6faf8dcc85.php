

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-body">
            <?php if(Session::get('fail')): ?>
            <div class="danger alert-danger p-2 my-2 rounded">
                <?php echo e(Session::get('fail')); ?>

            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-8 col-lg-12">
                    <?php if(session()->get('dept_id') == 1): ?>
                        <div class="container my-1">
                            <input type="date" max="2050-12-31" name="request_date" value="<?php echo e(session()->get('request_date')); ?>" id="request_date" class="form-control">
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card active-users">
                                    <div class="card-header border-0">
                                        <h4 class="card-title">Today's Patients</h4>
                                        <a class="heading-elements-toggle"><i
                                                class="fa fa-ellipsis-v font-medium-3"></i></a>
                                        <div class="heading-elements">
                                            <ul class="list-inline mb-0">
                                                <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="card-content">
                                            <div class="table-responsive dashboard-table">
                                                <table class="table">
                                                    <thead>
                                                        <th>#</th>
                                                        <th>Image</th>
                                                        <th>Patient Code</th>
                                                        <th>Patient Name</th>
                                                        <th>Package</th>
                                                        <th>Agency</th>
                                                        <th>Action</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php if(count($schedule_patients) != 0): ?>
                                                        <?php $__currentLoopData = $schedule_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $schedule_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($indexKey+1); ?></td>
                                                            <td class="text-truncate row">
                                                                <div class="dashboard-image">
                                                                    <?php if($schedule_patient->patient_image == null ||
                                                                    $schedule_patient->patient_image == " "): ?>
                                                                    <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                                                        alt="Profile Picture" class="" height="300"
                                                                        width="300">
                                                                    <?php else: ?>
                                                                    <img src="../../../app-assets/images/profiles/<?php echo e($schedule_patient->patient_image); ?>"
                                                                        alt="Profile Picture" class="" height="300"
                                                                        width="300">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <a class="link"
                                                                    href="/patient_edit?id=<?php echo e($schedule_patient->patient_id); ?>&patientcode=<?php echo e($schedule_patient->patientcode); ?>">
                                                                    <?php echo e($schedule_patient->patientcode); ?></a>
                                                            </td>
                                                            <td>
                                                                <h6 class="sub-heading">
                                                                    <?php echo e($schedule_patient->lastname . ', ' . $schedule_patient->firstname); ?>

                                                                </h6>
                                                            </td>
                                                            <td>
                                                                <span><?php echo e($schedule_patient->packagename); ?></span>
                                                            </td>
                                                            <td>
                                                                <span><?php echo e($schedule_patient->agencyname); ?></span>
                                                            </td>
                                                            <td>
                                                                <a href="/patient_edit?id=<?php echo e($schedule_patient->patient_id); ?>&patientcode=<?php echo e($schedule_patient->patientcode); ?>"
                                                                    class="btn btn-sm btn-primary"><i
                                                                        class="fa fa-eye"></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                        <tr>
                                                            <td colspan="3" class="text-center">No Record Found</td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                                <div class="float-right mx-1">
                                                    <?php echo $schedule_patients->links(); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-12">
                    <div class="card patient-status">
                        <div class="card-header pb-0">
                            <h5 class="primary"><i class="icon icon-user customize-icon"></i> QUEUE</h5>
                            <span class="sub-heading">PATIENT IS QUEUED IN
                                LOCATION
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table status-table">
                                    <thead>
                                        <th>#</th>
                                        <th>Full Name</th>
                                        <th>Package</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody class="table-striped">
                                        <?php $__currentLoopData = $queue_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $queue_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <!-- <?php if($queue_patient->patient_image == null ||
                                            $queue_patient->patient_image == ""): ?>
                                            <div class="avatar avatar-md mr-1">
                                                <img src="../../../app-assets/images/profiles/profilepic.jpg"
                                                    alt="Profile Picture" class="">
                                            </div>
                                            <?php else: ?>
                                            <img src="../../../app-assets/images/profiles/<?php echo e($queue_patient->patient_image); ?>"
                                                alt="Profile Picture" class="">
                                            <?php endif; ?> -->
                                                <?php echo e($indexKey+1); ?>

                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($queue_patient->patient_id); ?>&patientcode=<?php echo e($queue_patient->patientcode); ?>"
                                                    class="primary"><?php echo e($queue_patient->lastname . ", " . $queue_patient->firstname); ?></a>
                                            </td>
                                            <td>
                                                <span><?php echo e($queue_patient->packagename); ?></span>
                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($queue_patient->patient_id); ?>&patientcode=<?php echo e($queue_patient->patientcode); ?>"
                                                    class="btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                    <div class="card patient-status">
                        <div class="card-header pb-0">
                            <h5 class="warning"><i class="icon icon-user customize-icon"></i> ADMITTED</h5>
                            <span class="sub-heading">PATIENT IS IN THE
                                RECEPTION
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table status-table">
                                    <thead>
                                        <th>#</th>
                                        <th>Full Name</th>
                                        <th>Package</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody class="table-striped">
                                        <?php $__currentLoopData = $pending_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $pending_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($indexKey+1); ?>

                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($pending_patient->patient_id); ?>&patientcode=<?php echo e($pending_patient->patientcode); ?>"
                                                    class="warning"><?php echo e($pending_patient->lastname . ", " . $pending_patient->firstname); ?></a>
                                            </td>
                                            <td>
                                                <span><?php echo e($pending_patient->packagename); ?></span>
                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($pending_patient->patient_id); ?>&patientcode=<?php echo e($pending_patient->patientcode); ?>"
                                                    class="btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                    <div class="card patient-status">
                        <div class="card-header pb-0">
                            <h5 class="danger"><i class="icon icon-user customize-icon"></i> ON GOING</h5>
                            <span class="sub-heading">PATIENT IS TAKING THE
                                EXAMS</span>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table status-table">
                                    <thead>
                                        <th>#</th>
                                        <th>Full Name</th>
                                        <th>Package</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody class="table-striped">
                                        <?php $__currentLoopData = $ongoing_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $ongoing_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($indexKey+1); ?>

                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($ongoing_patient->patient_id); ?>&patientcode=<?php echo e($ongoing_patient->patientcode); ?>"
                                                    class="danger"><?php echo e($ongoing_patient->lastname . ", " . $ongoing_patient->firstname); ?></a>
                                            </td>
                                            <td>
                                                <span><?php echo e($ongoing_patient->packagename); ?></span>
                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($ongoing_patient->patient_id); ?>&patientcode=<?php echo e($ongoing_patient->patientcode); ?>"
                                                    class="btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                    <div class="card patient-status">
                        <div class="card-header pb-0">
                            <h5 class="success">
                                <i class="icon icon-user customize-icon"></i> MEDICAL DONE
                            </h5>
                            <span class="sub-heading"> PATIENT COMPLETED THE
                                EXAMS</span>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table status-table">
                                    <thead>
                                        <th>#</th>
                                        <th>Full Name</th>
                                        <th>Package</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody class="table-striped">
                                        <?php $__currentLoopData = $completed_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $completed_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($indexKey+1); ?>

                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($completed_patient->patient_id); ?>&patientcode=<?php echo e($completed_patient->patientcode); ?>"
                                                    class="success"><?php echo e($completed_patient->lastname . ", " . $completed_patient->firstname); ?></a>
                                            </td>
                                            <td>
                                                <span><?php echo e($completed_patient->packagename); ?></span>
                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($completed_patient->patient_id); ?>&patientcode=<?php echo e($completed_patient->patientcode); ?>"
                                                    class="btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card patient-status">
                        <div class="card-header pb-0">
                            <h5 class="success">
                                <i class="icon icon-user customize-icon"></i> FIT TO WORK
                            </h5>
                            <span class="sub-heading"> PATIENT COMPLETED THE
                                EXAMS</span>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table status-table">
                                    <thead>
                                        <th>#</th>
                                        <th>Full Name</th>
                                        <th>Package</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody class="table-striped">
                                        <?php $__currentLoopData = $fit_patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $fit_patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($indexKey+1); ?>

                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($fit_patient->patient_id); ?>&patientcode=<?php echo e($fit_patient->patientcode); ?>"
                                                    class="success"><?php echo e($fit_patient->lastname . ", " . $fit_patient->firstname); ?></a>
                                            </td>
                                            <td>
                                                <span><?php echo e($fit_patient->packagename); ?></span>
                                            </td>
                                            <td>
                                                <a href="patient_edit?id=<?php echo e($fit_patient->patient_id); ?>&patientcode=<?php echo e($fit_patient->patientcode); ?>"
                                                    class="btn btn-sm btn-primary"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(Session::get('success_support')): ?>
<?php $__env->startPush('scripts'); ?>
<script>
    toastr.success('<?php echo e(Session::get("success_support")); ?>', 'Success');
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    $("#request_date").change( function(e){
        $.ajax({
            url: "/dashboard",
            data: {
                "request_date" : e.target.value
            },
            success: function(result){
                console.log(result);
                location.reload();
            }
        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>