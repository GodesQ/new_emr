<html>

<head>
    <title>VACCINATION RECORD</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    * {
        font-size: 12px;
        font-family: sans-serif;
    }

    @page  {
        size: landscape;
    }
    </style>
</head>
<body>
        <table width="760" cellspacing="0" cellpadding="10" style="border: 1px solid rgb(0, 0, 0);">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="0" class="brdNone">
                            <tbody>
                                <tr>
                                    <td>
                                       <span style="border-bottom: 1px solid black; font-size: 20px; padding: 0.4rem 1rem; font-weight: 700;">COVID-19 Vaccination Record Card</span> <br>
                                       <div style="margin-top: 1rem; font-size: 12px;">Please keep your record card, which includes medical information <br> about the vaccines you have received.</div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table  width="100%" cellspacing="0" cellpadding="0" class="brdNone">
                            <tbody>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid black; padding: 0.4rem;">
                                            <div><?php echo e($patient->firstname); ?></div>
                                            <div><?php echo e($patient->lastname); ?></div>
                                            <div><?php echo e($patient->middlename); ?></div>
                                        </div>
                                        <div style="display: flex; align-items: center; justify-content: space-between;color: rgb(109, 109, 109); padding: 0 0.4rem;">
                                            <div>Firstname</div>
                                            <div>Lastname</div>
                                            <div>Middlename</div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" class="brdNone">
                            <tbody>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; justify-content: flex-start; border-bottom: 1px solid black; padding: 0.4rem;">
                                            <div style="margin: 0 7rem 0 0;"><?php echo e($patient->birthdate); ?></div>
                                            <div style="margin: 0 7rem 0 0;"><?php echo e($patient->patientcode); ?></div>
                                        </div>
                                        <div style="display: flex; align-items: center; justify-content: flex-start;color: rgb(109, 109, 109); padding: 0 0.7rem;">
                                            <div style="margin: 0 7rem 0 0;">Date of birth</div>
                                            <div style="margin: 0 7rem 0 0;">Patient number</div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="5" class="brdTable">
                            <tbody>
                                <tr>
                                    <td width="25%">
                                        <b>Vaccine</b>
                                    </td>
                                    <td width="30%">
                                        <b>Product Name / Manufacturer</b>
                                    </td>
                                    <td width="20%">
                                        <b>Date</b>
                                    </td>
                                    <td width="25%">
                                        <b>Healthcare Professional / Clinic Site</b>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>

</body>
</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/vaccination_print.blade.php ENDPATH**/ ?>