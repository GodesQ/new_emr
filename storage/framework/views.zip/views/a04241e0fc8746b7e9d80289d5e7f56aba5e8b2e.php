

<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="container">
            <div class="row">
            <div class="col-md-12 my-1">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Add Refferal Slip</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse"><i class="feather icon-minus"></i></a></li>
                                <li><a data-action="reload"><i class="feather icon-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="feather icon-maximize"></i></a></li>
                                <li><a data-action="close"><i class="feather icon-x"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <form class="form" method="POST" id="add_refferal">
                                <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput1">Name of Employer</label>
                                                <input type="text" id="projectinput1" class="form-control" placeholder="Name of Employer" name="employer">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput2">Country of Destination</label>
                                                <input type="text" id="projectinput2" class="form-control" placeholder="Country of Destination" name="country_destination">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput3">Lastname</label>
                                                <input type="text" id="projectinput3" class="form-control lastname" placeholder="Lastname" name="lastname">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Firstname</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Firstname" name="firstname">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Middlename</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Middlename" name="middlename">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="projectinput4">Home Address</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Home Address" name="address">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Age</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Age" name="age">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Civil Status</label>
                                                <select required name="maritalstatus" id="maritalstatus" class="form-control select2">
                                                    <option value="">Select Civil Status</option>
                                                    <option value="Single">Single</option>
                                                    <option value="Married">Married</option>
                                                    <option value="Widowed">Widowed</option>
                                                    <option value="Divorced">Divorced</option>
                                                    <option value="Domestic Relationship">Domestic
                                                        Relationship</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Position Applied For</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Home Address" name="position_applied">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Vessel</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Vessel" name="vessel">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">Passport</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Passport" name="passport">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="projectinput4">SSRB NO.</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="SSRB NO." name="ssrb">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput4">Medical Package</label>
                                                <select required name="package_id" id="" class="select2">
                                                    <option value=" ">-- SELECT PACKAGE --</option>
                                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($package->id); ?>"><?php echo e($package->packagename); ?> (<?php echo e($package->agencyname); ?>)</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput2">Email of Employee</label>
                                                <input type="email" id="projectinput2" class="form-control" placeholder="Email of Employee" name="email">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput4">Signature</label><br>
                                                <canvas class="signature"></canvas><br>
                                                <button type="button" class="btn btn-primary clear-signature">Clear</button>
                                                <input type="hidden" name="signature" class="signature-data">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="projectinput4">Agency</label>
                                                <input required type="text" id="projectinput4" class="form-control" placeholder="Agency / Company" value="<?php echo session()->get('agencyName') ?>" readonly>
                                                <input type="hidden" id="projectinput4" class="form-control" placeholder="Agency / Company" name="agency_id" value="<?php echo session()->get('agencyId') ?>" readonly>
                                            </div>
                                            <div class="form-group">
                                                <label for="projectinput4">Date</label>
                                                <input type="text" id="projectinput4" class="form-control" placeholder="Agency / Company" name="created_date" value="<?php echo date("Y-m-d") ?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                <div class="form-actions">
                                    <a href="/agency_dashboard" type="reset" class="btn btn-warning mr-1">
                                        <i class="feather icon-x"></i> Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-check-square-o"></i> Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../../../app-assets/js/scripts/signature_pad-master/js/signature_pad.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>

<script>
const canvas = document.querySelector(".signature");
const signaturePad = new SignaturePad(canvas, {
    penColour: '#fff',
    penWidth: 2,
});

document.querySelector('.clear-signature').addEventListener('click', () => {
    signaturePad.clear();
})
document.querySelector('.lastname').onchange = function() {
    let signatureData = signaturePad.toDataURL();
    let signatureInput = document.querySelector('.signature-data');
    signatureInput.value = signatureData;
}

$("#add_refferal").submit(function(e) {
    e.preventDefault();
    if (signaturePad._isEmpty) {
        Swal.fire(
            'Warning!',
            'Signature is required!',
            'warning'
        )
    } else {
        let signatureData = signaturePad.toDataURL();
        let signatureInput = document.querySelector('.signature-data');
        signatureInput.value = signatureData;
        if (signatureInput != "") {
            const fd = new FormData(this);
            $.ajax({
                url: '/store_refferal',
                method: 'POST',
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(response) {
                    console.log(response);
                    if (response.status == 200) {
                        Swal.fire(
                            'Added!',
                            'Refferal Slip Added Successfully!',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed) {
                                location.reload();
                            }
                        })
                    } else {
                        Swal.fire(
                            'Not Send!',
                            'Chart Account Added Failed!',
                            'warning'
                        )
                    }
                }
            });
        }
    }
});

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.agency-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Agency/add-refferal-slip.blade.php ENDPATH**/ ?>