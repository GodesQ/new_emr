

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .signature {
        width: 430px !important;
        height: 150px;
        border: 1px solid black;
    }
</style>
<div class="app-content content">
    <?php if(Session::get('success')): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                toastr.success('<?php echo e(Session::get("success")); ?>', 'Success');
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
    <div class="container">
        <section class="users-edit">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <ul class="nav nav-tabs mb-2" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link d-flex align-items-center active" id="account-tab" data-toggle="tab" href="#account" aria-controls="account" role="tab" aria-selected="true">
                                    <i class="feather icon-user mr-25"></i><span class="d-none d-sm-block">Account</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link d-flex align-items-center" id="password-tab" data-toggle="tab" href="#password" aria-controls="password" role="tab" aria-selected="false">
                                    <i class="feather icon-lock mr-25"></i><span class="d-none d-sm-block">Password Settings</span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="account" aria-labelledby="account-tab" role="tabpanel">
                                <!-- users edit media object start -->
                                <div class="row">
                                    <div class="col-md-10">
                                        <div class="media mb-2">
                                            <div class="media-body">
                                                <h4 class="media-heading"><?php echo e($employee->firstname); ?> <?php echo e($employee->lastname); ?></h4>
                                                <div class="col-12 px-0 d-flex">
                                                    <button href="#" class="btn btn-sm btn-primary mr-25 p-75" onclick="openCamera()" data-toggle="modal" data-target="#defaultSize">Change Profile</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade text-left" id="defaultSize" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel18" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel18"><i class="fa fa-camera"></i>
                                                    Take
                                                    Picture
                                                </h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body d-flex justify-content-center align-items-center">
                                                <div class="camera"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn grey btn-outline-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-outline-primary"
                                                    onclick="snapShot()">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <div class="col-md-2">
                                        <?php if($employee->employee_image == null || $employee->employee_image == " "): ?>
                                            <img src="../../../app-assets/images/profiles/profilepic.jpg" alt="Profile Picture" class="users-avatar-shadow rounded open-camera image-taken" height="64" width="64">
                                        <?php else: ?>
                                                <img src="../../../app-assets/images/employees/<?php echo e($employee->employee_image); ?>" class="users-avatar-shadow open-camera image-taken" height="64" width="64">
                                        <?php endif; ?>
                                        <img src="<?php echo $employee->signature ?>" alt="" class="signature-taken">
                                    </div>
                                </div>
                                <form id="update_profile" role="form" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($employee->id); ?>">
                                        <input type="hidden" name="old_image"
                                                    value="<?php echo e($employee->employee_image); ?>">
                                        <input type="hidden" name="employee_image" class="patient-image"
                                                    value="<?php echo e($employee->employee_image); ?>">
                                        <input type="hidden" name="signature" id="signature_data" value="">
                                        <input type="hidden" name="old_signature" id="old_signature"
                                            value="<?php echo e($employee->signature); ?>">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group d-none">
                                                <label for="">Employee Code</label>
                                                <input name="employeecode" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->employeecode); ?>"
                                                            readonly="">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Firstname</label>
                                                <input name="firstname" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->firstname); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Lastname</label>
                                                <input name="lastname" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->lastname); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Middle Name</label>
                                                <input name="middlename" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->middlename); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">User Name</label>
                                                <input name="username" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->username); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Email</label>
                                                <input name="email" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->email); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Address</label>
                                                <input name="address" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->address); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Gender</label>
                                                <select class="form-control" name="gender" id="">
                                                    <option value="" <?php echo e($employee->gender == "" ?  "selected" : null); ?>>SELECT</option>
                                                    <option value="Male" <?php echo e($employee->gender == "Male" ?  "selected" : null); ?>>Male</option>
                                                    <option value="Female" <?php echo e($employee->gender == "Female" ?  "selected" : null); ?>>Female</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Title</label>
                                                <input name="title" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->title); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="">Religion</label>
                                                <input name="religion" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->religion); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Marital Status</label>
                                                <select required name="maritalstatus" id="address" type="text"
                                                        class="form-control">
                                                        <option value="">Select Civil Status</option>
                                                        <option value="Single" <?php echo $employee->maritalstatus ==
                                                            "Single" ? "selected=''" : "" ?> >Single</option>
                                                        <option value="Married" <?php echo $employee->maritalstatus ==
                                                            "Married" ? "selected=''" : "" ?> >Married</option>
                                                        <option value="Widowed" <?php echo $employee->maritalstatus ==
                                                            "Widowed" ? "selected=''" : "" ?> >Widowed</option>
                                                        <option value="Divorced" <?php echo $employee->maritalstatus ==
                                                            "Divorced" ? "selected=''" : "" ?> >Divorced</option>
                                                        <option value="Domestic Relationship" <?php echo $employee->
                                                            maritalstatus == "Domestic Relationship" ? "selected=''" :
                                                            "" ?> >Domestic
                                                            Relationship</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Birth Date</label>
                                                <input name="birthdate" id="employeecode" type="date" max="2050-12-31"
                                                            class="form-control" value="<?php echo e($employee->birthdate); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Birth Place</label>
                                                <input name="birthplace" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->birthplace); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Position</label>
                                                <input name="position" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->position); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Address</label>
                                                <input name="address" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->address); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="">License No./Certificate No./PRC No.</label>
                                                <input name="license_no" id="employeecode" type="text"
                                                            class="form-control" value="<?php echo e($employee->license_no); ?>">
                                            </div>
                                            <div class="form-group">
                                                <div class=" my-2">
                                                    <canvas class="signature" width="430px" height="150px"></canvas> <br>
                                                    <button type='button' class="btn btn-solid btn-primary clear-signature">Clear</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1">
                                            <button type="submit" class="btn btn-primary glow mb-1 mb-sm-0 mr-0 mr-sm-1">Save
                                                changes</button>
                                            <button onclick="history.back()" type="button" class="btn btn-light">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                                <!-- users edit Info form ends -->
                            </div>
                            <div class="tab-pane" id="password" aria-labelledby="password-tab" role="tabpanel">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="employee_change_password" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($employee->id); ?>"/>
                                            <div class="form-group">
                                                <label>New Password</label>
                                                <input type="password" name="password" class="form-control" />
                                                <span class="danger text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div>
                                            <div class="form-group">
                                                <label>Confirm Password</label>
                                                <input type="password" name="password_confirmation" class="form-control" />
                                                <span class="danger text-danger"><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div>
                                            <button class="btn btn-primary btn-solid">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../../../app-assets/js/scripts/signature_pad-master/js/signature_pad.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script src="../../../app-assets/js/scripts/custom.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Employee/user-employee.blade.php ENDPATH**/ ?>