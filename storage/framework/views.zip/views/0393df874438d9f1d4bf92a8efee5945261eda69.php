<html>

<head>
    <title>MLC</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    body,
    table,
    tr,
    td {
        font-family: sans-serif;
        font-size: 13px;
    }

    .fontBoldLrg {
        font: bold 15px sans-serif;
    }

    .fontMed {
        font: normal 12px sans-serif;
    }
    </style>
</head>

<body>
    <center>
        <table width="760" cellspacing="0" cellpadding="5">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <b><u>Annex II - Medical Examination Form</u></b> <br>
                                        <span style="color: red; margin: 0.3rem;"><b>CONFIDENTIAL FORM</b></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="5" style="margin-top: 1rem;">
                            <tbody>
                                <tr>
                                    <td>
                                        Pre-sea Exam <span style="margin-right: 2rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"></span>
                                        Periodic Exam <span style="margin-right: 2rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Name (last, first, middle): <span
                                                style="margin-left: 0.5rem; border-bottom: 1px solid black;"><?php echo e($admission->lastname); ?>,
                                                <?php echo e($admission->firstname); ?> <?php echo e($admission->middlename); ?></span></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div
                                            style="display: flex; justify-content: space-between; align-items: center;">
                                            <div style="width: 50%"> Date of birth (day/month/year): <span
                                                    style="margin-left: 0.5rem; border-bottom: 1px solid black;"><?php echo e($patientInfo->birthdate); ?></span>
                                            </div>
                                            <div style="width: 50%">Sex: <span style="margin-left: 2rem;"><img
                                                        src="../../../app-assets/images/icoUnCheck.gif" width="10">Male
                                                    <span style="margin-left: 2rem;"><img
                                                            src="../../../app-assets/images/icoUnCheck.gif"
                                                            width="10">Female</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Nationality <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;"><?php echo e($patientInfo->nationality); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Home address: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;"><?php echo e($patientInfo->address); ?></span> Identity
                                        document No.: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Type of ship (e.g. container, tanker, passenger, fishing): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Trade area (e.g., coastal, tropical, worldwide): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><b>Examinee’s personal declaration</b></td>
                                </tr>
                                <tr>
                                    <td>(Assistance should be offered by medical staff)</td>
                                </tr>
                                <tr>
                                    <td>Have you ever had any of the following conditions:</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="5" style="margin-top: 1rem;">
                            <tbody>
                                <tr>
                                    <td width="50%">
                                        <table width="100%" cellspacing="0" cellpadding="5" style="margin-top: 1rem;">
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td><b> Condition</b></td>
                                                    <td><b> Yes</b></td>
                                                    <td><b>No</b></td>
                                                </tr>
                                                <tr>
                                                    <td>1. </td>
                                                    <td>Eye/vision problem</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick7 == "Yes" || $exam_physical->sick7 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick7 == "No" || $exam_physical->sick7 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>2. </td>
                                                    <td>High blood pressure</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick12 == "Yes" || $exam_physical->sick12 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick12 == "No" || $exam_physical->sick12 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>3. </td>
                                                    <td>Heart/vascular disease</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick13 == "Yes" || $exam_physical->sick13 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick13 == "No" || $exam_physical->sick13 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>4. </td>
                                                    <td>Heart surgery</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>5. </td>
                                                    <td>Varicose veins</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>6. </td>
                                                    <td>Asthma/bronchitis</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick27 == "Yes" || $exam_physical->sick27 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick27 == "No" || $exam_physical->sick27 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>7. </td>
                                                    <td>Blood disorder</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick18 == "Yes" || $exam_physical->sick18 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick18 == "No" || $exam_physical->sick18 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>8. </td>
                                                    <td>Diabetes</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick15 == "Yes" || $exam_physical->sick15 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick15 == "No" || $exam_physical->sick15 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>9. </td>
                                                    <td>Thyroid problem</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>10. </td>
                                                    <td>Digestive disorder</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>11. </td>
                                                    <td>Kidney problem</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick22 == "Yes" || $exam_physical->sick22 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick22 == "No" || $exam_physical->sick22 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>12. </td>
                                                    <td>Skin problem</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>13. </td>
                                                    <td>Allergies</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick30 == "Yes" || $exam_physical->sick30 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick30 == "No" || $exam_physical->sick30 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>14. </td>
                                                    <td>Infectious/contagious diseases</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>15. </td>
                                                    <td>Hernia</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>16. </td>
                                                    <td>Genital disorders</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick24 == "Yes" || $exam_physical->sick24 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick24 == "No" || $exam_physical->sick24 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>17. </td>
                                                    <td>Pregnancy</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </td>
                                    <td width="50%">
                                        <table width="100%" cellspacing="0" cellpadding="5" style="margin-top: 1rem;">
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td><b> Condition</b></td>
                                                    <td><b> Yes</b></td>
                                                    <td><b>No</b></td>
                                                </tr>
                                                <tr>
                                                    <td>18. </td>
                                                    <td>Sleeping problems</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick5 == "Yes" || $exam_physical->sick5 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick5 == "No" || $exam_physical->sick5 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>19. </td>
                                                    <td>Do you smoke?</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick5 == "Yes" || $exam_physical->sick5 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick5 == "No" || $exam_physical->sick5 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>20. </td>
                                                    <td>Operation/surgery</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick31 == "Yes" || $exam_physical->sick31 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick31 == "No" || $exam_physical->sick31 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>21. </td>
                                                    <td>Epilepsy/seizures</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick4 == "Yes" || $exam_physical->sick4 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick4 == "No" || $exam_physical->sick4 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>22. </td>
                                                    <td>Dizziness/fainting</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick3 == "Yes" || $exam_physical->sick3 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick3 == "No" || $exam_physical->sick3 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>23. </td>
                                                    <td>Loss of consciousness</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>24. </td>
                                                    <td>Psychiatric problems</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>25. </td>
                                                    <td>Depression</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick6 == "Yes" || $exam_physical->sick6 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick6 == "No" || $exam_physical->sick6 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>26. </td>
                                                    <td>Attempted suicide</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>27. </td>
                                                    <td>Loss of memory</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>28. </td>
                                                    <td>Balance problem</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>29. </td>
                                                    <td>Severe headaches</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick2 == "Yes" || $exam_physical->sick2 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick2 == "No" || $exam_physical->sick2 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>30. </td>
                                                    <td>Ear/nose/throat problems</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick9 == "Yes" || $exam_physical->sick9 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick9 == "No" || $exam_physical->sick9 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>31. </td>
                                                    <td>Restricted mobility</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>32. </td>
                                                    <td>Back problems</td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick23 == "Yes" || $exam_physical->sick23 == "1"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($exam_physical): ?>
                                                        <?php if($exam_physical->sick23 == "No" || $exam_physical->sick23 == "0"): ?>
                                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>33. </td>
                                                    <td>Amputation</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>34. </td>
                                                    <td>Fractures/dislocations</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div
                            style="width: 100%; border: 1px double black; margin-top: 1.5rem; padding: 0.5rem; height: 100px;">
                            If any of the above questions were answered “yes,” please give details. <br>
                            <span></span> <br>
                            <b>Operation:</b> <br>
                            <textarea name="co" type="text" id="co" rows="3" class="brdNone" style="width:100%;text-align:left;border: none;"></textarea>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div style="margin: 1rem"><b>Additional questions</b></div>
                        <table width="100%" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td><b>Yes</b></td>
                                    <td><b> No</b></td>
                                </tr>
                                <tr>
                                    <td>35. </td>
                                    <td>Have you ever been signed off as sick or repatriated from a ship?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question1 == "Yes" || $exam_physical->question1 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question1 == "No" || $exam_physical->question1 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>36. </td>
                                    <td>Have you ever been hospitalized?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question2 == "Yes" || $exam_physical->question2 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question2 == "No" || $exam_physical->question2 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>37. </td>
                                    <td>Have you ever been declared unfit for sea duty?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question3 == "Yes" || $exam_physical->question3 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question3 == "No" || $exam_physical->question3 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>38. </td>
                                    <td>Has your medical certificate ever been restricted or revoked?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question4 == "Yes" || $exam_physical->question4 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question4 == "No" || $exam_physical->question4 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>39. </td>
                                    <td>Are you aware that you have any medical problems, diseases or illnesses?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question5 == "Yes" || $exam_physical->question5 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question5 == "No" || $exam_physical->question5 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>40. </td>
                                    <td>Do you feel healthy and fit to perform the duties of your designated
                                        position/occupation?</td>
                                        <td>
                                            <?php if($exam_physical): ?>
                                            <?php if($exam_physical->question6 == "Yes" || $exam_physical->question6 == "1"): ?>
                                                <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($exam_physical): ?>
                                            <?php if($exam_physical->question6 == "No" || $exam_physical->question6 == "0"): ?>
                                                <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                        </td>
                                </tr>
                                <tr>
                                    <td>41. </td>
                                    <td>Are you allergic to any medications?</td>
                                        <td>
                                            <?php if($exam_physical): ?>
                                            <?php if($exam_physical->question7 == "Yes" || $exam_physical->question7 == "1"): ?>
                                                <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($exam_physical): ?>
                                            <?php if($exam_physical->question7 == "No" || $exam_physical->question7 == "0"): ?>
                                                <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                            <?php else: ?>
                                                <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                            <?php endif; ?>
                                        </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <div
                                            style="width: 100%; border: 1px double black; margin-top: 1.5rem; padding: 0.5rem; height: 80px;">
                                            <b>Comments</b><br>
                                            <textarea name="co" type="text" id="co" value="" rows="4" class="brdNone" style="width:100%;text-align:left;border: none;">
                                                <?php if($exam_physical): ?>
                                                <?php echo e($exam_physical->comments); ?>

                                                <?php endif; ?>
                                            </textarea>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>42. </td>
                                    <td>Are you taking any non-prescription or prescription medications?</td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question8 == "Yes" || $exam_physical->question8 == "1"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam_physical): ?>
                                        <?php if($exam_physical->question8 == "No" || $exam_physical->question8 == "0"): ?>
                                            <img src="../../../app-assets/images/icoCheck.gif" width="10">
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <div
                                            style="width: 100%; border: 1px double black; margin-top: 1.5rem; padding: 0.5rem; height: 80px;">
                                            <b>If yes, please list the medications taken and the purpose(s) and
                                                dosage(s).</b><br>
                                                <textarea name="co" type="text" id="co" value="" rows="4" class="brdNone" style="width:100%;text-align:left;border: none;"><?php if($exam_physical): ?><?php echo e($exam_physical->purpose); ?><?php endif; ?>
                                                </textarea>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4" height="50">I hereby certify that the personal declaration above is
                                        a true statement to the best of my knowledge.</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        Signature of examinee: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        Date (day/month/year): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        Witnessed by: (Signature) <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        Name: (Typed or printed) <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4" height="80">I hereby authorize the release of all my previous
                                        medical records from any health professionals,
                                        health institutions and public authorities to Dr. <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(the
                                        approved medical practitioner carrying out the medical examinations).</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        Signature of examinee: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        Date (day/month/year): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        Witnessed by: (Signature) <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        Name: (Typed or printed) <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="5" style="margin-top: 1rem;">
                            <tbody>
                                <tr>
                                    <td><b>Medical Examination</b></td>
                                </tr>
                                <tr>
                                    <td><span style="margin-right: 1rem; margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"> Pre-sea <span
                                                style="margin-right: 1rem; margin-left: 2rem;"><img
                                                    src="../../../app-assets/images/icoUnCheck.gif" width="10"> Periodic
                                                <span style="margin-right: 1rem; margin-left: 2rem;"><img
                                                        src="../../../app-assets/images/icoUnCheck.gif" width="10"> Other
                                    </td>
                                </tr>
                                <tr>
                                    <td height="50"><b>Sight</b></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="0" cellpadding="5">
                                            <tbody>
                                                <tr>
                                                    <td width="70%">
                                                        <table width="100%" cellspacing="0" cellpadding="5"
                                                            class="brdTable">
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td colspan="6">Visual acuity</td>
                                                                </tr>
                                                                <tr>
                                                                    <td></td>
                                                                    <td colspan="3">Unaided</td>
                                                                    <td colspan="3">Aided</td>
                                                                </tr>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>Right eye</td>
                                                                    <td>Left eye</td>
                                                                    <td>Binocular</td>
                                                                    <td>Right eye</td>
                                                                    <td>Left eye</td>
                                                                    <td>Binocular</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Distant</td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td>20/20</td>
                                                                    <td>20/20</td>
                                                                    <td></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Distant</td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td>.62M</td>
                                                                    <td>.62M</td>
                                                                    <td></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td width="30%">
                                                        <table width="100%" cellspacing="0" cellpadding="5"
                                                            class="brdTable">
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td colspan="2">Visual fields</td>
                                                                </tr>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>Normal</td>
                                                                    <td>Defective</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Right Eye</td>
                                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif"
                                                                            width="10"></td>
                                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif"
                                                                            width="10"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Left Eye</td>
                                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif"
                                                                            width="10"></td>
                                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif"
                                                                            width="10"></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><b>Color Vision:</b>
                                        <span style="margin-left: 2rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"> Not tested
                                            <span style="margin-left: 2rem;"><img
                                                    src="../../../app-assets/images/icoUnCheck.gif" width="10"> Normal
                                                <span style="margin-left: 2rem;"><img
                                                        src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    Doubtful
                                                    <span style="margin-left: 2rem;"><img
                                                            src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                        Defective
                                    </td>
                                </tr>
                                <tr>
                                    <td height="50"><b>Hearing</b></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="0" cellpadding="5">
                                            <tbody>
                                                <tr>
                                                    <td width="70%">
                                                        <span style="text-align: right;">Pure tone and audio metry
                                                            (threshold values in dB)</span> <br>
                                                        <table width="100%" cellspacing="0" cellpadding="5"
                                                            class="brdTable">
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>
                                                                        500 <br> Hz
                                                                    </td>
                                                                    <td>
                                                                        4,000 <br> Hz
                                                                    </td>
                                                                    <td>
                                                                        2,000 <br> Hz
                                                                    </td>
                                                                    <td>
                                                                        3,000 <br> Hz
                                                                    </td>
                                                                    <td>
                                                                        4,000 <br> Hz
                                                                    </td>
                                                                    <td>
                                                                        6,000 <br> Hz
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Right ear</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Left ear</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                    <td>20</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td width="30%">
                                                        Speech and whisper test (metres)
                                                        <table width="100%" cellspacing="0" cellpadding="5"
                                                            class="brdTable">
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>Normal</td>
                                                                    <td>Whisper</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Right ear</td>
                                                                    <td>N/A</td>
                                                                    <td>N/A</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Left ear</td>
                                                                    <td>N/A</td>
                                                                    <td>N/A</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="50">Height: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(cm)
                                        <span style="margin-left: 2rem;">Weight:</span> <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(kg)
                                    </td>
                                </tr>
                                <tr>
                                    <td height="50">Pulse rate: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(/minute)
                                        <span style="margin-left: 2rem;">Rhythm:</span> <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="50">Blood pressure: Systolic <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(mm
                                        Hg) <span style="margin-left: 2rem;">Diastolic:</span> <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>(mm
                                        Hg)</td>
                                </tr>
                                <tr>
                                    <td height="50">Urinalysis: Glucose: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <span style="margin-left: 2rem;">Protein:</span> <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="5">
                            <tbody>
                                <tr>
                                    <td width="50%">
                                        <table width="100%" cellspacing="0" cellpadding="5">
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td><b>Normal</b></td>
                                                    <td><b>Abnormal</b></td>
                                                </tr>
                                                <tr>
                                                    <td>Head</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Sinuses, nose, throat</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Mouth/teeth</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Ears (general)</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Tympanic membrane</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Eyes</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Opthalmoscopy</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Pupils</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Eye movement</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Lungs and chest</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Breast examination</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Heart</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td width="50%">
                                        <table width="100%" cellspacing="0" cellpadding="5">
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td><b>Normal</b></td>
                                                    <td><b>Abnormal</b></td>
                                                </tr>
                                                <tr>
                                                    <td>Skin</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Varicose veins</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Vascular (inc. pedal pulses)</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Abdomen and viscera</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Hernia</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Anus (not rectal exam.)</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>G-U system</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Upper and lower extremities</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Spine (C/S, T/S and L/S)</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Neurologic (full brief)</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Psychiatric</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>General appearance</td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="80">
                                        Chest X-ray: <span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10">Not
                                            Performed</span><span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10">Performed on
                                            (day/month/year): <span
                                                style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        Results: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="5" cellspacing="5" style="margin-top: 600px;">
                            <tbody>
                                <tr>
                                    <td colspan="2">Other diagnostic test(s) and result(s):</td>
                                </tr>
                                <tr height="70">
                                    <td>Test: <span></span></td>
                                    <td>Result: <span></span></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="100">
                                        <div style="padding: 0.5rem; border: 1px solid black; height: 100px;">
                                            Medical practitioner's comments:
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        Vaccination status recorded: <span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10">Yes</span>
                                        <span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10">No</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="50"><b>Assessment of fitness for service at sea</b></td>
                                </tr>
                                <tr>
                                    <td colspan="2">On the basis of the examinee’s personal declaration, my clinical
                                        examination and the diagnostic test results recorded above, I declare the
                                        examinee medically:</td>
                                </tr>
                                <tr>
                                    <td colspan="2"><span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"> Fit for
                                            look-out duty</span> <span style="margin-left: 1rem;"><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"> Not Fit for
                                            look-out duty</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="5" cellspacing="5">
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td>Deck service</td>
                                    <td>Engine service</td>
                                    <td>Catering service</td>
                                    <td>Other services</td>
                                </tr>
                                <tr>
                                    <td>Fit</td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                </tr>
                                <tr>
                                    <td>Unfit</td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                    <td><img src="../../../app-assets/images/icoUnCheck.gif" width="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="5" height="100">Without restrictions <span><img
                                                src="../../../app-assets/images/icoUnCheck.gif" width="10"></span> With
                                        restrictions <span><img src="../../../app-assets/images/icoUnCheck.gif"
                                                width="10"></span></td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <div style="padding: 0.5rem; border: 1px solid black; height: 80px;">Describe
                                            restrictions (e.g., specific positions, type of ship, trade area)</div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        Action taken by medical examiner (e.g., referral): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        Place of examination: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        Date of examination (day/month/year): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        Medical certificate’s date of expiration (day/month/year): <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5" height="100">Official stamp:</td>
                                </tr>
                                <tr>
                                    <td colspan="5">Signature of medical practitioner: <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">Name of medical practitioner: (Typed or printed) <span
                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">Authorized by: <b>PROFESSIONAL REGULATION COMMISSION</b></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="0" style="margin-top: 1rem;">
                            <tbody>
                                <tr>
                                    <td align="center"><b><u>Annex III: Draft Format of a Seafarer Medical
                                                Certificate</u></b></td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <div
                                            style="margin-top: 1rem; font-size: 19px; font-weight: 700; text-decoration: underline;">
                                            SEAFARER MEDICAL CERTIFICATE</div> (issued under the authority of
                                        authorising country details.)
                                    </td>
                                </tr>
                                <tr>
                                    <td height="100" style="font-style: italic;">This Medical Certificate has been
                                        issued in accordance with the provisions of the( International Convention on
                                        Standards of Training,
                                        Certification and Watch-keeping for Seafarers STCW 1978, as amended (STCW)
                                        Regulation I/9, Maritime Labour Convention 2006
                                        (MLC 2006) Regulation 1.2 and regulation xxx of the authorising country)*as
                                        applicable
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><b><u>SEAFARER INFORMATION</u></b></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="0" cellpadding="5" class="brdTable"
                                            style="margin-top: 1rem;">
                                            <tbody>
                                                <tr>
                                                    <td>Surname: <span></span></td>
                                                    <td colspan="2">Given Name(s): <span></span></td>
                                                </tr>
                                                <tr>
                                                    <td>Date of Birth (dd/mm/yyyy): <span></span></td>
                                                    <td>Nationality: <span></span> <br>
                                                        ID Document no: <span></span>
                                                    </td>
                                                    <td>Gender: <br>
                                                        Male / Female
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="3">
                                                        Capacity that the seafarer will serve onboard serve in:
                                                        <span></span> <br> <br>
                                                        <span style="margin-left: 1rem;">Deck:</span> <span
                                                            style="margin-left: 1rem;">Engineer</span> <span
                                                            style="margin-left: 1rem;">GMDSS</span> <span
                                                            style="margin-left: 1rem;">Rating</span> <span
                                                            style="margin-left: 1rem;">Catering</span> <span
                                                            style="margin-left: 1rem;">Other</span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><b><u>DECLARATION OF APPROVED** MEDICAL PRACTITIONER</u></b></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="0" cellpadding="10" class="brdTable"
                                            style="margin-top: 1rem;">
                                            <tbody>
                                                <tr>
                                                    <td>I confirm that identification documents were checked:
                                                        <span>Yes</span> / <span>No</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Does the seafarers hearing meet medical standards*?
                                                        <span>Yes</span> / <span>No</span> <br> <br>
                                                        Is unaided hearing satisfactory*? <span>Yes</span> /
                                                        <span>No</span> <br> <br>
                                                        Vision acuity meets medical standards*? <span>Yes</span> /
                                                        <span>No</span> <br> <br>
                                                        Colour vision meets standard*? <span>Yes</span> /
                                                        <span>No</span> <br> <br>
                                                        Date of last colour vision test? (dd/mm/yyyy) <span
                                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                        <br> <br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Is the seafarer fit for lookout duties: YES/NO/Not applicable
                                                        <br> <b><u>YES</u></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Is the seafarer free from any medical condition likely to be
                                                        aggravated by service at sea or render the seafarer unfit for
                                                        such service or to endanger the health of other persons on
                                                        board? YES/NO <br>
                                                        <b><u>YES</u></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Is the seafarer fit for service? YES/ NO <br> <b><u>YES</u></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="70" valign="top">Are there any limitations or
                                                        restrictions on fitness? If so specify the limitation.</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="5" cellpadding="0" class="brdAll"
                                            style="margin-top: 1rem;">
                                            <tbody>
                                                <tr>
                                                    <td>I hereby confirm that the medical examination has been carried
                                                        out in accordance with the ILO/IMO Guidelines on the
                                                        Medical Examinations of Seafarers and the national guidelines of
                                                        the authorising Administration.</td>
                                                </tr>
                                                <tr>
                                                    <td height="40">Name of Approved** Medical Practioner: <span
                                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="40">Signature of Approved** Medical Practitioner: <span
                                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="40">Date of Examination (dd/mm/yyyy): <span
                                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                        Stamp/Seal</td>
                                                </tr>
                                                <tr>
                                                    <td>Expiry date of certificate (dd/mm/yyyy): <span
                                                            style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="5" cellpadding="5" class="brdTable">
                                            <tbody>
                                                <tr>
                                                    <td align="center"><b>SEAFARER ACKNOWLEDGEMENT</b></td>
                                                </tr>
                                                <tr>
                                                    <td>I Name of seafarer confirm that I have been informed of the
                                                        content of certificate and the right to get a review***. <br>
                                                        <br>
                                                        <div
                                                            style="display: flex; align-items: center; justify-content: space-around;">
                                                            <div style="width: 50%">Signature: <span
                                                                    style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                            </div>
                                                            <div style="width: 50%">Date: (dd/mm/yyyy): <span
                                                                    style="margin-left: 0.5rem; border-bottom: 1px solid black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>* For persons who are assigned shipboard safety, security or environmental
                                        protection duties, the medical standards
                                        referenced on the certificate are the standards as specified in STCW Regulation
                                        I/9 and any other standards as specified
                                        by the authorizing Administration. For any other persons serving onboard, the
                                        medical standards shall be as specified by
                                        ILO and the authorizing Administration.
                                        ** The Medical Practitioner shall be approved by the national Administration,
                                        after inspection of medical
                                        facilities/recordkeeping, to carry out STCW/ILO medical examination.
                                        *** The review shall be carried out by a body/Medical Practitioner authorized by
                                        national Administration and this
                                        information should be made available to the seafarer
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="5" cellpadding="5" style="margin-top: 4rem;">
                                            <tbody>
                                                <tr>
                                                    <td><b><u>ANNEX IV: List of countries, whose seafarer medical
                                                                certificates that are issued by a qualified Medical
                                                                Practitioner
                                                                licensed by the national Administration , are accepted
                                                                by The Bahamas</u></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table width="100%" cellspacing="0" cellpadding="0"
                                                            style="margin-top: 1rem;">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Algeria</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Antigua and Barbuda</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Argentina</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Australia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Azerbaijan</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Bahamas (the)</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Bahrain</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Bangladesh</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Barbados</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Belgium</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Belize</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Brazil</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Brunei Darussalam</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Bulgaria</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Cambodia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Canada</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Cape Verde</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Chile</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>China: includes: Hong Kong,
                                                                                        China</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Colombia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Comoros</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Cook Islands (the)</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Côte d'Ivoire</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Croatia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Cuba</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Cyprus</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Czech Republic</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Democratic People’s</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Republic of Korea</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Denmark: includes Faroe Islands
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Greece</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Honduras</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Hungary</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Iceland</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>India</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Indonesia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Iran (Islamic Republic of)</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Ireland</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Italy</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Israel</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Jamaica</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Japan</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Jordan</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Kenya</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Kiribati</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Kuwait</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Latvia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Lebanon</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Liberia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Lithuania</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Luxembourg</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Libyan Arab Jamahiriya (the)
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Madagascar</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Malaysia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Malawi</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Maldives</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Malta</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Marshall Islands</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Mauritania</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Mauritius</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Panama</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Papua New Guinea</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Peru</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Philippines</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Poland</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Portugal</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Qatar</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Republic of Korea</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Romania</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Russian Federation</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Saint Vincent and the Grenadines
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Samoa</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Saudi Arabia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Senegal</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Serbia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Singapore</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Slovak Republic</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Slovenia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Solomon Islands</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>South Africa</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Spain</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Sri Lanka</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Sweden</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Switzerland</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Syrian Arab Republic</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Thailand</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Togo</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Tonga</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Trinidad & Tobago</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Tunisia</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table cellspacing="0" cellpadding="0"
                                                            style="margin-top: 1rem;">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Dominica</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Ecuador</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Egypt</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Eritrea</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Estonia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Ethiopia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Fiji</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Finland</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>France</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Georgia</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Germany</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Ghana</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Mexico</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Micronesia (Federated States of)
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Montenegro</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Morocco</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Mozambique</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Myanmar</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Netherlands: includes Aruba,
                                                                                        Curaca, St. Maarten</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>New Zealand</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Nigeria</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Norway</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Oman</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Pakistan</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                    <td width="33%">
                                                                        <table width="100%" cellspacing="5"
                                                                            cellpadding="5" class="brdAll">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>Turkey</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Tuvalu</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Ukraine</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>United Arab Emirates</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>United Kingdom: includes
                                                                                        Bermuda,</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>British Virgin Islands, Cayman
                                                                                        Islands</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Gibraltar, Isle of Man</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>United Republic of Tanzania</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>United States</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Uruguay</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Vanuatu</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Venezuela (Bolivarian Republic
                                                                                        of)</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>Viet Nam</td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </center>
</body>

</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintPanel/bahamas.blade.php ENDPATH**/ ?>