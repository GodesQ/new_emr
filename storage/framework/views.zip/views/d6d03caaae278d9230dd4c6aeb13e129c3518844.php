

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Add Hepatitis</h3>
                            <a href="patient_edit?id=<?php echo e($admission->patient_id); ?>&patientcode=<?php echo e($admission->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/store_hepatitis" role="form">
                            <?php if(Session::get('status')): ?>
                            <div class="success alert-success p-2 my-2">
                                <?php echo e(Session::get('status')); ?>

                            </div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input required required required type="hidden" name="id" value="<?php echo e($admission->id); ?>">
                            <input type="hidden" name="patient_id" value="<?php echo e($admission->patient_id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input required required required name="peme_date" type="text"
                                                id="peme_date" value="<?php echo e($admission->trans_date); ?>" class="form-control"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input required required required name="admission_id" type="text"
                                                    id="admission_id" value="<?php echo e($admission->id); ?>"
                                                    class="form-control input required required-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input required required required name="trans_date" type="text"
                                                id="trans_date" value="<?php echo date(
                                    'Y-m-d'
                                ); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input required required required name="patientname" id="patientname"
                                                type="text"
                                                value="<?php echo e($admission->lastname . ", " . $admission->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input required required required name="patientcode" id="patientcode"
                                                type="text" value="<?php echo e($admission->patientcode); ?>" class="form-control"
                                                readonly=""></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table no-border">
                                <tbody>
                                    <tr>
                                        <td align="left" class="brdBtm"><b>Examination</b></td>
                                        <td align="left" class="brdBtm"><b><b>Result</b></b></td>
                                        <td align="left" class="brdLeftBtm">
                                            <p><b>Cut-Off Value</b></p>
                                        </td>
                                        <td align="left" class="brdBtm"><b>Patient Count</b></td>
                                    </tr>
                                    <tr>
                                        <td width="22%" align="left" valign="top">HBsAg</td>
                                        <td width="38%" class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->hbsag_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_1" value="Reactive" <?php echo e($exam_bloodsero->hbsag_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_2" value="" <?php echo e($exam_bloodsero->hbsag_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_0" value="Non Reactive">Non Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_1" value="Reactive">Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="hbsag_cutoff" type="text" class="form-control" id="hbsag_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->hbsag_cov : null); ?>"></td>
                                        <td width="20%" class="brdLeft"><input name="hbsag_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->hbsag_pv : null); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBs</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihbs_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihbs_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_2" value="" <?php echo e($exam_bloodsero->antihbs_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_1" value="Reactive">Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbs_cutoff" type="text" class="form-control" id="hbsag_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbs_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbs_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbs_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">HBeAg</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->hbeag_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_1" value="Reactive" <?php echo e($exam_bloodsero->hbeag_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_2" value="" <?php echo e($exam_bloodsero->hbeag_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_0" value="Non Reactive">Non Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_1" value="Reactive">Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="hbeag_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->hbeag_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="hbeag_value" type="text" class="form-control" id="antihbs_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->hbeag_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBe</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihbe_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihbe_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_2" value="" <?php echo e($exam_bloodsero->antihbe_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_1" value="Reactive">Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbe_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbe_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbe_value" type="text" class="form-control" id="antihbs_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbe_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgM):</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihbclgm_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihbclgm_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_2" value="" <?php echo e($exam_bloodsero->antihbclgm_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_1" value="Reactive">Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1" id="antihbclgm_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbclgm_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbclgm_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbclgm_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbclgm_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgG)</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihbclgg_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihbclgg_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_2" value="" <?php echo e($exam_bloodsero->antihbclgg_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_1" value="Reactive">Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1" id="antihbclgg_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbclgg_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbclgg_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihbclgg_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihbclgg_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgM)</td>
                                         <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihavlgm_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihavlgm_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_2" value="" <?php echo e($exam_bloodsero->antihavlgm_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_1" value="Reactive">Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1" id="antihavlgm_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihavlgm_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigm_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihavlgm_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigm_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgG)</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihavlgg_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihavlgg_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_2" value="" <?php echo e($exam_bloodsero->antihavlgg_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_1" value="Reactive">Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1" id="antihavlgg_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihavlgg_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigg_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihavlgg_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigg_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HCV </td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->antihcv_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_1" value="Reactive" <?php echo e($exam_bloodsero->antihcv_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_2" value="" <?php echo e($exam_bloodsero->antihcv_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_0" value="Non Reactive">Non Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_1" value="Reactive">Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihcv_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigg_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihcv_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->antihavigg_pv : null); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Others</td>
                                        <td class="brdLeft">
                                            <?php if($exam_bloodsero): ?>
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_0" value="Non Reactive" <?php echo e($exam_bloodsero->sothers_result == "Non Reactive" ? "checked" : null); ?>>Non Reactive
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_1" value="Reactive" <?php echo e($exam_bloodsero->sothers_result == "Reactive" ? "checked" : null); ?>>Reactive
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_2" value="" <?php echo e($exam_bloodsero->sothers_result == "" ? "checked" : null); ?>>Reset
                                            <?php else: ?>
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_0" value="Non Reactive">Non Reactive
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_1" value="Reactive">Reactive
                                            <input name="others_result" type="radio" class="m-1" id="antihcv_result_2" value="">Reset
                                            <?php endif; ?>
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihcv_cutoff" type="text" class="form-control" id="antihbs_cutoff" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->sothers_cov : null); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft">
                                            <input name="antihcv_value" type="text" class="form-control" id="hbsag_value" value="<?php echo e($exam_bloodsero ? $exam_bloodsero->sothers_pv : null); ?>">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                            <td colspan="4">
                                            <div class="form-group">
                                                    <label for=""><b>Remarks</b></label>
                                                    <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal">Normal
                                                    <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings">With Findings
                                            </div>
                                            <div class="form-group">
                                                    <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"></textarea>
                                            </div>
                                            </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $medical_techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med_tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($med_tech->id); ?> <?php echo e($med_tech->id == "55" ? "selected" : null); ?>><?php echo e($med_tech->firstname); ?> <?php echo e($med_tech->lastname); ?>, <?php echo e($med_tech->title); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select name="technician2_id" id="technician2_id"
                                                                    class="form-control">
                                                                    <?php $__currentLoopData = $pathologists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pathologist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value=<?php echo e($pathologist->id); ?> <?php echo e($pathologist->id == "55" ? "selected" : null); ?>><?php echo e($pathologist->firstname); ?> <?php echo e($pathologist->lastname); ?>, <?php echo e($pathologist->title); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Hepatitis/add-hepatitis.blade.php ENDPATH**/ ?>