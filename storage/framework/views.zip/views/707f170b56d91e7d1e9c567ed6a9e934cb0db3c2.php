

<?php $__env->startSection('name'); ?>
<?php echo e($data['agencyName']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-content content">
    <div class="main-loader">
        <div class="loader">
            <span class="loader-span"><img src="../../../app-assets/images/icons/output-onlinegiftools.gif"
                    alt="Loading"></span>
        </div>
    </div>
    <div class="toaster bg-success"><i class="feather icon-check"></i></div>
    <div class="container my-4">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-11">
                        <h2 class="text-bold-600">Referral Slips</h2>
                    </div>
                </div>
            </div>
            <hr>
            <div class="card-body">
                <div class="table-responsive">
                    <table data-order='[[ 0, "desc" ]]' class="table table-bordered data-table">
                        <thead>
                            <tr>
                                <th>Package</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Position Applied</th>
                                <th>Vessel</th>
                                <th>SSRB</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    let table = $('.data-table').DataTable({
        processing: true,
        pageLength: 50,
        responsive: true,
        serverSide: true,
        ajax: '/refferal_slips',
        columns: [{
                data: 'packagename',
                name: 'packagename'
            },
            {
                data: 'lastname',
                name: 'lastname'
            },
            {
                data: 'firstname',
                name: 'firstname'
            },
            {
                data: 'position_applied',
                name: 'position_applied'
            },
            {
                data: 'vessel',
                name: 'vessel'
            },
            {
                data: 'ssrb',
                name: 'ssrb'
            },
            {
                data: 'action',
                name: 'action'
            },
        ],
        createdRow: function(row, data, dataIndex) {
            if (data.is_hold == 1) {
                $(row).css("background-color", "lightgray");
            }
        },

    });

    $(document).on('click', '.hold-btn', function(e) {
        e.preventDefault();
        let id = $(this).attr('id');
        let csrf = '<?php echo e(csrf_token()); ?>';
        Swal.fire({
            title: 'Are you sure you want to hold this employee?',
            text: "Please Confirm!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, hold it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $(".main-loader").css("display", "block");
                $.ajax({
                    url: '<?php echo e(route("hold_employee")); ?>',
                    method: 'get',
                    data: {
                        id: id,
                        _token: csrf
                    },
                    success: function(response) {
                        if(response.status == 200) {
                            toastr.success('The referral successfully hold.', 'Success');
                            let draw = table.draw();
                        } else {
                            Swal.fire(
                                'Error!',
                                'Error Occured. Please Try Again Later',
                                'error'
                            )
                        }
                    }
                }).done(function(data) {
                    $(".main-loader").css("display", "none");
                });
            }
        })
    })

    $(document).on('click', '.activate-btn', function(e) {
        e.preventDefault();
        let id = $(this).attr('id');
        let csrf = '<?php echo e(csrf_token()); ?>';
        Swal.fire({
            title: 'Are you sure you want to activate this employee?',
            text: "Please Confirm!",
            icon: 'info',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, activate it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $(".main-loader").css("display", "block");
                $.ajax({
                    url: '<?php echo e(route("activate_employee")); ?>',
                    method: 'get',
                    data: {
                        id: id,
                        _token: csrf
                    },
                    success: function(response) {
                        if(response.status == 200) {
                            toastr.success('The referral successfully activate.', 'Success');
                            let draw = table.draw();
                        } else {
                            Swal.fire(
                                'Error!',
                                'Error Occured. Please Try Again Later',
                                'error'
                            )
                        }
                    }
                }).done(function(data) {
                    $(".main-loader").css("display", "none");
                });;
            }
        })
    })


});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.agency-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Referral/referral.blade.php ENDPATH**/ ?>