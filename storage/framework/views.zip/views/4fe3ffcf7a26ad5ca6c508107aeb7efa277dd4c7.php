<html>

<head>
    <title>HEMATOLOGY</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
</head>

<body>
    <center>
        <table width="760" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                            <tbody>
                                <tr>
                                    <td width="80" rowspan="3" align="center"><img
                                            src="../../../app-assets/images/logo/logo.jpg" width="80" height="80"
                                            alt=""></td>
                                    <td width="356" rowspan="3" align="center" valign="middle">
                                        <span class="lblCompName">MERITA DIAGNOSTIC CLINIC INC.</span><br
                                            style="margin-bottom: 20px">
                                        <span class="lblCompDtl"><b>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave.
                                                Cor. San Antonio St. Malate, Manila<b><br>
                                                    Tel No.: (02) 5310-032 / 5310-0825 / 0917-8576942 / 0908-8908850<br>
                                                    Email: meritaclinic@gmail.com / meritadiagnosticclinic@yahoo.com<br>
                                                    Accredited: DOH * POEA * MARINA * TESDA * Oil &amp; Gas UK<br>Skuld
                                                    P&amp;I * West of England P&amp;I</b></b></span><b><b>
                                            </b></b>
                                    </td>
                                    <td width="218" valign="top" class="brdLeftBtm"><b>NAME:</b><br>
                                        <span
                                            style="font-size:15px; text-transform: uppercase;"><?php echo e($admission->lastname . ', ' . $admission->firstname . " " . $admission->middlename); ?></span>
                                    </td>
                                    <td width="39" valign="top" class="brdLeftBtm"><b>AGE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->age); ?></span>
                                    </td>
                                    <td width="45" valign="top" class="brdLeftBtm"><b>SEX:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->gender); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="27" colspan="3" align="left" valign="top" class="brdLeftBtm">
                                        <b>REQUESTED BY:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->agencyname); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="26" align="left" valign="top" class="brdLeft"><b>PEME DATE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->trans_date); ?></span>
                                    </td>
                                    <td colspan="2" align="left" valign="top" class="brdLeft"><b>PATIENT
                                            NO:</b><br><span style="font-size:15px"><?php echo e($admission->patientcode); ?></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50" align="center" class="lblReport">HEMATOLOGY</td>
                </tr>
                <tr>
                    <td>
                        <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
                        <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td align="center">
                                        <table width="600" border="0" cellpadding="10" cellspacing="0" class="brdAll">
                                            <tbody>
                                                <tr>
                                                    <td width="290" align="center" class="brdBtm"><b>EXAMINATION</b>
                                                    </td>
                                                    <td width="342" align="center" class="brdLeftBtm"><b>RESULTS</b>
                                                    </td>
                                                    <td align="center" class="brdLeftBtm"><b>NORMAL VALUES</b></td>
                                                </tr>

                                                <?php if($exam->hemoglobin != " "): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        <p>Hemoglobin</p>
                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->hemoglobin); ?></td>
                                                    <td width="156" align="left" valign="top" class="brdLeftBtm">120 -
                                                        170 g/L</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->hematocrit != ""): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        <p>Hematocrit</p>
                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->hematocrit); ?></td>
                                                    <td width="156" align="left" valign="top" class="brdLeftBtm">0.40 -
                                                        0.54</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->wbc != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">RBC</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->rbc); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">3.5 - 5.5
                                                        10<sup>12</sup> /L</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->wbc != ""): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">WBC</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->wbc); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">5 - 10 x
                                                        10<sup>9</sup> /L</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->neuthrophils != " "): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        <p>&nbsp;&nbsp;&nbsp;&nbsp;Neutrophil<br>
                                                        </p>
                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->neuthrophils); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.50 - 0.70</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->lymphocytes != ""): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        <p>&nbsp;&nbsp;&nbsp;&nbsp;Lymphocyte</p>
                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->lymphocytes); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.20 - 0.40</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->eosinophils != ""): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Eosinophil</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->eosinophils); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.00 - 0.05</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->monophils != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Monocyte</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->monophils); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.00 - 0.05</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->baspophils != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Basophil</td>
                                                    <td align="left" valign="top" class="brdLeftBtm">
                                                        <?php echo e($exam->baspophils); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.00 - 0.01</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->stabs != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Stabs</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->stabs); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">0.00 - 0.05</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->blood != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Blood Type</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->blood); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">&nbsp;</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->rhfactor != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Rh Factor</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->rhfactor); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">&nbsp;</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->platelet != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Platelet</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->platelet); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">150 - 450 X
                                                        10<sup>9</sup> /L</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->bleeding != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Bleeding Time </td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->bleeding); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">1-7 Minutes</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->clotting != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Clotting Time</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->clotting); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">5-15 Minutes</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->esr != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;ESR</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->esr); ?></td>
                                                    <td valign="top" class="brdLeftBtm">
                                                        <?= $admission->gender == 'Male'
                        ? '0 - 10 mm/hr'
                        : '0 - 20 mm/hr' ?>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->mcv != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;MCV</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->mcv); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">80 - 100 fL5</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->mch != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;MCH</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->mch); ?></td>
                                                    <td align="left" valign="top" class="brdLeftBtm">27 - 34 pg</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->mchc != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;MCHC</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->mchc); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">320 - 360 g/L</td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($exam->others != ''): ?>
                                                <tr>
                                                    <td align="left" valign="top" class="brdBtm">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;Others</td>
                                                    <td align="left" valign="top" class="brdLeftBtm"><?php echo e($exam->others); ?>

                                                    </td>
                                                    <td align="left" valign="top" class="brdLeftBtm">&nbsp;</td>
                                                </tr>
                                                <?php endif; ?>


                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="760" border="0" cellpadding="2" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td height="120" align="center" valign="bottom">
                                                        <table width="260" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <?php if($technician1): ?>
                                                                            <img src="<?php echo e($technician1->signature); ?>" width="100px" style="object-fit: cover;"/>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician1): ?>
                                                                        <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?><br>
                                                                        Medical Technologist<br>
                                                                        Lic. No.
                                                                        <?php echo e($technician1->license_no); ?>

                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td colspan="3" align="center" valign="bottom">
                                                        <table width="260" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"></td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician2): ?>
                                                                        <?php echo e($technician2->firstname . " " . $technician2->middlename . " " . $technician2->lastname . ", " . $technician2->title); ?><br>
                                                                        Pathologist<br>
                                                                        Lic. No.
                                                                        <?php echo e($technician2->license_no); ?>

                                                                        <?php endif; ?>
                                                                        </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60"><span class="lblForm">FORM NO. 07<br>REV. 01 / 02-12-2019</span></td>
                </tr>
            </tbody>
        </table>
    </center>


</body>

</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintTemplates/examlab_hematology_print.blade.php ENDPATH**/ ?>