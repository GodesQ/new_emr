

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Hepatitis</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_hepatitis" role="form">
                            <?php if(Session::get('status')): ?>
                                <?php $__env->startPush('scripts'); ?>
                                    <script>
                                       toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td align="left" class="brdBtm"><b>Examination</b></td>
                                        <td align="left" class="brdBtm"><b><b>Result</b></b></td>
                                        <td align="left" class="brdLeftBtm">
                                            <p><b>Cut-Off Value</b></p>
                                        </td>
                                        <td align="left" class="brdBtm"><b>Patient Count</b></td>
                                    </tr>
                                    <tr>
                                        <td width="22%" align="left" valign="top">HBsAg</td>
                                        <td width="38%" class="brdLeft">
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_0"
                                                value="Non Reactive" <?php echo $exam->hbsag_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_1"
                                                value="Reactive" <?php echo $exam->hbsag_result == 'Reactive' ? "checked"
                                            : "" ?>>Reactive
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_2"
                                                value="" <?php echo $exam->hbsag_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td width="20%" class="brdLeft"><input name="hbsag_cutoff" type="text"
                                                class="form-control" id="hbsag_cutoff"
                                                value="<?php echo e($exam->hbsag_cutoff); ?>">
                                        </td>
                                        <td width="20%" class="brdLeft"><input name="hbsag_value" type="text"
                                                class="form-control" id="hbsag_value"
                                                value="<?php echo e($exam->hbsag_value); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBs</td>
                                        <td class="brdLeft">
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_0"
                                                value="Non Reactive" <?php echo $exam->antihbs_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_1"
                                                value="Reactive" <?php echo $exam->antihbs_result == 'Reactive' ?
                                            "checked" : "" ?>>Reactive
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_2"
                                                value="" <?php echo $exam->antihbs_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbs_cutoff" type="text"
                                                class="form-control" id="antihbs_cutoff"
                                                value="<?php echo e($exam->antihbs_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihbs_value" type="text" class="form-control"
                                                id="antihbs_value" value="<?php echo e($exam->antihbs_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">HBeAg</td>
                                        <td class="brdLeft">
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_0"
                                                value="Non Reactive" <?php echo $exam->hbeag_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_1"
                                                value="Reactive" <?php echo $exam->hbeag_result == 'Reactive' ? "checked"
                                            : "" ?>>Reactive
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_2"
                                                value="" <?php echo $exam->hbeag_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="hbeag_cutoff" type="text" class="form-control"
                                                id="hbeag_cutoff" value="<?php echo e($exam->hbeag_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="hbeag_value" type="text" class="form-control"
                                                id="hbeag_value" value="<?php echo e($exam->hbeag_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBe</td>
                                        <td class="brdLeft">
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_0"
                                                value="Non Reactive" <?php echo $exam->antihbe_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_1"
                                                value="Reactive" <?php echo $exam->antihbe_result == 'Reactive' ?
                                            "checked" : "" ?>>Reactive
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_2"
                                                value="" <?php echo $exam->antihbe_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbe_cutoff" type="text"
                                                class="form-control" id="antihbe_cutoff"
                                                value="<?php echo e($exam->antihbe_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihbe_value" type="text" class="form-control"
                                                id="antihbe_value" value="<?php echo e($exam->antihbe_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgM):</td>
                                        <td class="brdLeft">
                                            <input name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_0" value="Non Reactive" <?php echo
                                                $exam->antihbclgm_result == 'Non Reactive' ? "checked" : "" ?>>Non
                                            Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_1" value="Reactive" <?php echo
                                                $exam->antihbclgm_result == 'Reactive' ? "checked" : "" ?>>Reactive
                                            <input name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_2" value="" <?php echo $exam->antihbclgm_result ==
                                            ' ' ? "checked" : "" ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbclgm_cutoff" type="text"
                                                class="form-control" id="antihbclgm_cutoff"
                                                value="<?php echo e($exam->antihbclgm_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihbclgm_value" type="text"
                                                class="form-control" id="antihbclgm_value"
                                                value="<?php echo e($exam->antihbclgm_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgG)</td>
                                        <td class="brdLeft">
                                            <input name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_0" value="Non Reactive" <?php echo
                                                $exam->antihbclgg_result == 'Non Reactive' ? "checked" : "" ?>>Non
                                            Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_1" value="Reactive" <?php echo
                                                $exam->antihbclgg_result == 'Reactive' ? "checked" : "" ?>>Reactive
                                            <input name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_2" value="" <?php echo $exam->antihbclgg_result ==
                                            '' ? "checked" : "" ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbclgg_cutoff" type="text"
                                                class="form-control" id="antihbclgg_cutoff"
                                                value="<?php echo e($exam->antihbclgg_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihbclgg_value" type="text"
                                                class="form-control" id="antihbclgg_value"
                                                value="<?php echo e($exam->antihbclgg_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgM)</td>
                                        <td class="brdLeft">
                                            <input name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_0" value="Non Reactive" <?php echo
                                                $exam->antihavlgm_result == 'Non Reactive' ? "checked" : "" ?>>Non
                                            Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_1" value="Reactive" <?php echo
                                                $exam->antihavlgm_result == 'Reactive' ? "checked" : "" ?>>Reactive
                                            <input name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_2" value="" <?php echo $exam->antihavlgm_result ==
                                            'Reactive' ? "checked" : "" ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihavlgm_cutoff" type="text"
                                                class="form-control" id="antihavlgm_cutoff"
                                                value="<?php echo e($exam->antihavlgm_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihavlgm_value" type="text"
                                                class="form-control" id="antihavlgm_value"
                                                value="<?php echo e($exam->antihavlgm_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgG)</td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_0" value="Non Reactive" <?php echo
                                                $exam->antihavlgg_result == 'Non Reactive' ? "checked" : "" ?>>Non
                                            Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_1" value="Reactive" <?php echo
                                                $exam->antihavlgg_result == 'Reactive' ? "checked" : "" ?>>Reactive
                                            <input name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_2" value="" <?php echo $exam->antihavlgg_result ==
                                            '' ? "checked" : "" ?>>Reset
                                        </td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_cutoff" type="text" class="form-control"
                                                id="antihavlgg_cutoff" value="<?php echo e($exam->antihavlgg_cutoff); ?>">
                                        </td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_value" type="text" class="form-control"
                                                id="antihavlgg_value" value="<?php echo e($exam->antihavlgg_value); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HCV </td>
                                        <td class="brdLeft">
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_0"
                                                value="Non Reactive" <?php echo $exam->antihcv_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_1"
                                                value="Reactive" <?php echo $exam->antihcv_result == 'Reactive' ?
                                            "checked" : "" ?>>Reactive
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_2"
                                                value="" <?php echo $exam->antihcv_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihcv_cutoff" type="text"
                                                class="form-control" id="antihcv_cutoff"
                                                value="<?php echo e($exam->antihcv_cutoff); ?>"></td>
                                        <td class="brdLeft"><input name="antihcv_value" type="text" class="form-control"
                                                id="antihcv_value" value="<?php echo e($exam->antihcv_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Others</td>
                                        <td valign="top" class="brdLeft">
                                            <input name="others_result" type="radio" class="m-1" id="others_result_0"
                                                value="Non Reactive" <?php echo $exam->others_result == 'Non Reactive' ?
                                            "checked" : "" ?>>Non Reactive
                                            <input name="others_result" type="radio" class="m-1" id="others_result_1"
                                                value="Reactive" <?php echo $exam->others_result == 'Reactive' ?
                                            "checked" : "" ?>>Reactive
                                            <input name="others_result" type="radio" class="m-1" id="others_result_2"
                                                value="" <?php echo $exam->others_result == '' ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td valign="top" class="brdLeft"><input name="others_cutoff" type="text"
                                                class="form-control" id="others_cutoff"
                                                value="<?php echo e($exam->others_cutoff); ?>"></td>
                                        <td valign="top" class="brdLeft"><input name="others_value" type="text"
                                                class="form-control" id="others_value"
                                                value="<?php echo e($exam->others_value); ?>">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "14" ? 'selected' : null); ?>

                                                                        value="14">Rowena P. Bondoc, RMT</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "16" ? 'selected' : null); ?>

                                                                        value="16">Audrey Dianne G. Partosa, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "53" ? 'selected' : null); ?>

                                                                        value="53">Audrey Dianne F. Gonzales, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "55" ? 'selected' : null); ?>

                                                                        value="55">GRACE JOY C. PEÑARANDA, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "56" ? 'selected' : null); ?>

                                                                        value="56">MA. LOURDES C. VELEÑA, RMT
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "33" ? 'selected' : null); ?>

                                                                        value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Hepatitis/edit-hepatitis.blade.php ENDPATH**/ ?>