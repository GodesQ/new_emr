

<?php $__env->startSection('name'); ?>
<?php echo e($data['agencyName']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
.nav-link {
    color: #009c9f;
}

.nav-link:hover {
    color: #009c9f;
}
</style>
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="container">
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title mb-0">Documentation</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="agency_dashboard">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="#">Users</a>
                                </li>
                                <li class="breadcrumb-item active">Documentation
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- account setting page start -->
                <section id="page-account-settings">
                    <div class="row">
                        <!-- left menu section -->
                        <div class="col-md-3 mb-2 mb-md-0">
                            <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                                <li class="nav-item">
                                    <a class="nav-link d-flex active" id="account-pill-general" data-toggle="pill"
                                        href="#account-vertical-general" aria-expanded="true">
                                        <i class="feather icon-globe"></i>
                                        Status of Employee
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" id="account-pill-password" data-toggle="pill"
                                        href="#account-vertical-password" aria-expanded="false">
                                        <i class="feather icon-square"></i>
                                        Hold / Activate Referral Slip
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" id="account-pill-info" data-toggle="pill"
                                        href="#account-vertical-info" aria-expanded="false">
                                        <i class="feather icon-info"></i>
                                        How to Add Referral Slip
                                    </a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link d-flex" id="account-pill-social" data-toggle="pill"
                                        href="#account-vertical-social" aria-expanded="false">
                                        <i class="feather icon-camera"></i>
                                        Social links
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" id="account-pill-connections" data-toggle="pill"
                                        href="#account-vertical-connections" aria-expanded="false">
                                        <i class="feather icon-feather"></i>
                                        Connections
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link d-flex" id="account-pill-notifications" data-toggle="pill"
                                        href="#account-vertical-notifications" aria-expanded="false">
                                        <i class="feather icon-message-circle"></i>
                                        Notifications
                                    </a>
                                </li> -->
                            </ul>
                        </div>
                        <!-- right content section -->
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane active" id="account-vertical-general"
                                                aria-labelledby="account-pill-general" aria-expanded="true">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-info">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-question white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>REGISTERED</h2>
                                                                                    <h6> Patient has already registered (but not yet admitted).</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-danger">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-info  white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>NO EXAMS</h2>
                                                                                    <h6>Patient does not have any registered exam.</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-warning">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-pin white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>ADMITTED</h2>
                                                                                    <h6>Patient is currently admitted at the clinic to undergo medical examinations</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-secondary">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-docs  white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>TAKING EXAMS</h2>
                                                                                    <h6>Patient is currently taking medical exams.</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-primary bg-darken-3">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-check white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>MEDICAL DONE</h2>
                                                                                    <h6>Patient has completed the medical examinations (but no result yet).</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-primary bg-darken-3">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-check white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>RE ASSESSMENT</h2>
                                                                                    <h6>Patient has completed the medical examinations but needs reassessment.</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-6 col-sm-12 col-12">
                                                                <div class="card bg-success">
                                                                    <div class="card-content">
                                                                        <div class="card-body">
                                                                            <div class="media d-flex">
                                                                                <div class="align-self-center">
                                                                                    <i
                                                                                        class="icon-check white font-large-2 float-left"></i>
                                                                                </div>
                                                                                <div
                                                                                    class="media-body white text-right">
                                                                                    <h2>FIT TO WORK</h2>
                                                                                    <h6>PATIENT COMPLETED THE EXAMS AND DONT NEED A RE-ASSESSMENT</h6>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade " id="account-vertical-password" role="tabpanel"
                                                aria-labelledby="account-pill-password" aria-expanded="false">

                                            </div>
                                            <div class="tab-pane fade" id="account-vertical-info" role="tabpanel"
                                                aria-labelledby="account-pill-info" aria-expanded="false">
                                                
                                            </div>
                                            <div class="tab-pane fade " id="account-vertical-social" role="tabpanel"
                                                aria-labelledby="account-pill-social" aria-expanded="false">
                                                <form>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-twitter">Twitter</label>
                                                                <input type="text" id="account-twitter"
                                                                    class="form-control" placeholder="Add link"
                                                                    value="https://www.twitter.com">
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-facebook">Facebook</label>
                                                                <input type="text" id="account-facebook"
                                                                    class="form-control" placeholder="Add link">
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-google">Google+</label>
                                                                <input type="text" id="account-google"
                                                                    class="form-control" placeholder="Add link">
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-linkedin">LinkedIn</label>
                                                                <input type="text" id="account-linkedin"
                                                                    class="form-control" placeholder="Add link"
                                                                    value="https://www.linkedin.com">
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-instagram">Instagram</label>
                                                                <input type="text" id="account-instagram"
                                                                    class="form-control" placeholder="Add link">
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="account-quora">Quora</label>
                                                                <input type="text" id="account-quora"
                                                                    class="form-control" placeholder="Add link">
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                            <button type="submit"
                                                                class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                                changes</button>
                                                            <button type="reset" class="btn btn-light">Cancel</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane fade" id="account-vertical-connections" role="tabpanel"
                                                aria-labelledby="account-pill-connections" aria-expanded="false">
                                                <div class="row">
                                                    <div class="col-12 mb-3">
                                                        <a href="javascript: void(0);" class="btn btn-info">Connect to
                                                            <strong>Twitter</strong></a>
                                                    </div>
                                                    <div class="col-12 mb-3">
                                                        <button
                                                            class=" btn btn-sm btn-secondary float-right">edit</button>
                                                        <h6>You are connected to facebook.</h6>
                                                        <span>Johndoe@gmail.com</span>
                                                    </div>
                                                    <div class="col-12 mb-3">
                                                        <a href="javascript: void(0);" class="btn btn-danger">Connect to
                                                            <strong>Google</strong>
                                                        </a>
                                                    </div>
                                                    <div class="col-12 mb-2">
                                                        <button
                                                            class=" btn btn-sm btn-secondary float-right">edit</button>
                                                        <h6>You are connected to Instagram.</h6>
                                                        <span>Johndoe@gmail.com</span>
                                                    </div>
                                                    <div
                                                        class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                        <button type="submit"
                                                            class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                            changes</button>
                                                        <button type="reset" class="btn btn-light">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="account-vertical-notifications"
                                                role="tabpanel" aria-labelledby="account-pill-notifications"
                                                aria-expanded="false">
                                                <div class="row">
                                                    <h6 class="ml-1 mb-2">Activity</h6>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                checked id="accountSwitch1">
                                                            <label class="ml-50" for="accountSwitch1">Email me when
                                                                someone
                                                                comments</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                checked id="accountSwitch2">
                                                            <label for="accountSwitch2" class="ml-50">Email me when
                                                                someone
                                                                answers
                                                                on</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                id="accountSwitch3">
                                                            <label for="accountSwitch3" class="ml-50">Email me hen
                                                                someone
                                                                follows
                                                                me</label>
                                                        </div>
                                                    </div>
                                                    <h6 class="ml-1 my-2">Application</h6>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                checked id="accountSwitch4">
                                                            <label for="accountSwitch4" class="ml-50">News and
                                                                announcements</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                id="accountSwitch5">
                                                            <label for="accountSwitch5" class="ml-50">Weekly product
                                                                updates</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <input type="checkbox" class="switchery" data-size="sm"
                                                                checked id="accountSwitch6">
                                                            <label for="accountSwitch6" class="ml-50">Weekly blog
                                                                digest</label>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                        <button type="submit"
                                                            class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                            changes</button>
                                                        <button type="reset" class="btn btn-light">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- account setting page end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Agency/documentation.blade.php ENDPATH**/ ?>