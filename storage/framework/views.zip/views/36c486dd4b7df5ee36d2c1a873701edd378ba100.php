

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .card {
        border-radius: 10px;
    }
    .card-header {
        background-color: #244681;
        color: white;
    }
</style>
<div class="app-content content">
    <div class="toaster bg-success "><i class="feather icon-check"></i> Successfully Deleted</div>
    <div class="container my-4">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-11">
                        <h2 class="text-bold-600">Agencies</h2>
                    </div>
                    <div class="col-md-1">
                        <a href="/add_agency" class="btn btn-solid btn-primary">Add
                        </a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="card-body">
                <?php if(Session::get('status')): ?>
                <div class="success alert-success p-2 my-2">
                    <?php echo e(Session::get('status')); ?>

                </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table data-order='[[ 0, "desc" ]]' class="table table-bordered table-hover data-table">
                        <thead>
                            <tr>
                                <th>Agency Code</th>
                                <th>Name</th>
                                <th>Contact Person</th>
                                <th>Email</th>
                                <th width="100px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
$(document).ready(function() {

    $(document).on('click', '.delete-agency', function(e) {
        e.preventDefault();
        let id = $(this).attr('id');
        let csrf = '<?php echo e(csrf_token()); ?>';
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '<?php echo e(route("agency.delete")); ?>',
                    method: 'delete',
                    data: {
                        id: id,
                        _token: csrf
                    },
                    success: function(response) {
                        document.querySelector('.toaster').classList.add(
                            'toaster-active');
                        Swal.fire(
                            'Deleted!',
                            'Record has been deleted.',
                            'success'
                        ).then((result) => {
                            if (result.isConfirmed) {
                                location.reload();
                            }
                        })
                    }
                });
            }
        })
    })

    let table = $('.data-table').DataTable({
        processing: true,
        pageLength: 50,
        responsive: true,
        serverSide: true,
        ajax: '<?php echo e(route("agencies.get")); ?>',
        columns: [{
                data: 'agencycode',
                name: 'agencycode'
            },
            {
                data: 'agencyname',
                name: 'agencyname'
            },
            {
                data: 'contactperson',
                name: 'contactperson'
            },
            {
                data: 'email',
                name: 'email'
            },
            {
                data: 'action',
                name: 'action',
                orderable: true,
                searchable: true
            },
        ],
    });

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Agency/agencies.blade.php ENDPATH**/ ?>