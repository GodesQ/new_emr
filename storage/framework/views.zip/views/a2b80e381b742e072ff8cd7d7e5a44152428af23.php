<?php
function initCheck($val,$chkval) {
return ($val==$chkval) ? "checked" : "";
}

function formatDate($val,$type=0,$kind=0) {
if ($val=="" || $val=="0000-00-00") {
if ($type==2)
return "null";
else
return "";
} else {
$time = ($kind==0) ? "" : " H:i:s";
if ($type==0) {
return date("m/d/Y".$time,strtotime($val));
} elseif ($type==1) {
return date("F d, Y".$time,strtotime($val));
} elseif ($type==2) {
return date("Y-m-d".$time,strtotime($val));
} elseif ($type==3) {
return date("d/M/Y".$time,strtotime($val));
} elseif ($type==4) {
return date("M. d, Y".$time,strtotime($val));
} elseif ($type==5){
return date("Y".$time,strtotime($val));
} elseif ($type==6){
return date("l(d)".$time,strtotime($val));
} elseif ($type==7){
return date("Y/m/d".$time,strtotime($val));
} elseif ($type==8){
return date("d/m/Y".$time,strtotime($val));
} elseif ($type==9){
return date("F".$time,strtotime($val));
} elseif ($type==10){
return date("mdy".$time,strtotime($val));
} elseif ($type==11){
return date("d M Y".$time,strtotime($val));
} elseif ($type==12){
return date("d F Y".$time,strtotime($val));
} elseif ($type==13){
return date("M/d/Y".$time,strtotime($val));
}
}
}

?>

<html>

<head>
    <title>HIV</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
</head>

<body>
    <center>
        <table width="680" border="0" cellpadding="2" cellspacing="0" class="">
            <tr>
                <td colspan="3" align="left">
                    <table width="100%" border="0" cellspacing="0" cellpadding="4">
                        <tr>
                            <td width="100%" colspan="3" align="center" valign="bottom">
                                <h3>HUMAN IMMUNODEFICIENCY VIRUS (HIV) <br>
                                    SCREENING TEST CERTIFICATE</h3>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3"><span style="margin-left:40px">This is to certify that
                                    <b><?php echo ($admission->gender=="Male") ? "Mr." : "Ms."?><u>
                                            <?php echo $admission->patientname?></u></b> has undergone screening test
                                    for HIV/Acquired Immunodeficiency Syndrome (AIDS),
                                    and was found to be <b><?php echo $exam->result?>*</b> based on laboratory test
                                    (HIV-1/HIV-2).</span></td>
                        </tr>
                        <tr>
                            <td height="80" colspan="3" align="center">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="60%" rowspan="6"><img src="" alt="Patient Picture" width="150"
                                                height="140" class="brdAll" style="margin:10px 0 0 10px" /></td>
                                        <td align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td style="">
                                            <table width="250" border="0" cellspacing="2" cellpadding="2">
                                                <tr valign="bottom">
                                                    <td>&emsp;&emsp;&emsp;</td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname); ?>

                                                    </td>
                                                </tr>
                                                <tr valign="bottom">
                                                    <td align="left" class="brdTop">
                                                        Examining Physician<br>
                                                        License No.: <b><?php echo e($technician1->license_no); ?></b><br>
                                                        Date of Medical Examination:
                                                        <b><?=formatDate($exam->trans_date,11)?></b>
                                                    </td>
                                                </tr>
                                            </table>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td valign="top"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td height="30" colspan="3" align="left" valign="middle">
                    <table width="680" border="0" cellspacing="0" cellpadding="3">
                        <tr>
                            <td valign="top">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td colspan="3" align="center">
                                            <h2>LABORATORY REPORT</h2>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="60%" align="right">&nbsp;</td>
                                        <td width="20%" align="right"> Date:</td>
                                        <td width="20%" align="center" style="border-bottom : 1px solid"><b>
                                                <?=formatDate($admission->trans_date,11)?>
                                            </b></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td width="497" valign="top"><br>
                                <table width="100%" border="0" cellspacing="0" cellpadding="3">
                                    <tr>
                                        <td width="6%">Name:</td>
                                        <td width="49%" class="brdBtm"><b>
                                                <?php echo $admission->lastname . ', ' . $admission->firstname . ' ' . $admission->middlename?>
                                            </b></td>
                                        <td width="5%">Age:</td>
                                        <td width="4%" class="brdBtm"><b>
                                                <?=$admission->age?>
                                            </b></td>
                                        <td width="5%">Sex:</td>
                                        <td width="7%" class="brdBtm"><b>
                                                <?=$admission->gender?>
                                            </b></td>
                                        <td width="12%">Civil Status:</td>
                                        <td width="12%" class="brdBtm"><b>
                                                <?=$gen_info->maritalstatus?>
                                            </b></td>
                                    </tr>
                                </table>
                                <table width="100%" border="0" cellspacing="0" cellpadding="3">
                                    <tr>
                                        <td width="6%">Address:</td>
                                        <td width class="brdBtm"><b>
                                                <?=$gen_info->address?>
                                            </b></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">Human Immunodeficiency Virus Types I (HIV-I) and (HIV-2) as a
                                            screening test for HIV/AIDS: <br>
                                            Screening Test Used:
                                            <p><span style="text-align: left">
                                                    <input name="exam" type="checkbox" id="exam" value="rapid"
                                                        <?=initCheck("rapid",$exam->exam)?> disabled />
                                                </span>RAPID</p>
                                            <p><span style="text-align: left">
                                                    <input name="exam" type="checkbox" id="exam" value="particle"
                                                        <?=initCheck("particle",$exam->exam)?> disabled />
                                                </span>Particle Agglutination</p>
                                            <p><span style="text-align: left">
                                                    <input name="exam" type="checkbox" id="exam" value="enzyme"
                                                        <?=initCheck("enzyme",$exam->exam)?> disabled />
                                                </span>EIA/CMIA/ELFA</p>
                                            <p><span style="text-align: left">
                                                    <input name="exam" type="checkbox" id="exam" value="others"
                                                        <?=initCheck("others",$exam->exam)?> disabled />
                                                </span>Others (specify) <u>
                                                    <?=$exam->others?>
                                                </u></p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td height="" colspan="2" align="center">
                    <h2>RESULT *
                        <?=$exam->result?>
                    </h2>
                </td>
            </tr>
            <tr>
                <td colspan="2" valign="bottom">
                    <table width="215" border="0" cellspacing="2" cellpadding="2">
                        <tr>
                            <td width="207">
                                <br>
                            </td>
                        </tr>
                        <tr valign="bottom">
                            <td align="left" class="brdTop"> Medical Technologist <br>
                                HIV Proficiency Cert. No.<b><u></u></b><br>
                                Expiry Date : <b><u><?=$exam->expiry_date?></u></b>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" valign="bottom">
                    <table width="215" border="0" cellspacing="2" cellpadding="2">
                        <tr>
                            <td>
                                <br>
                            </td>
                        </tr>
                        <tr valign="bottom">
                            <td align="left" class="brdTop">
                                <?php if($technician1): ?>
                                <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?>

                                Pathologist<br>
                                Lic. No. <?php echo e($technician1->license_no); ?>

                                <?php endif; ?>
                                <br>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" valign="bottom" class="smallfont">
                    <hr>
                    *A nonreactive result indicates that the tested sample does not contain detectable Human
                    Immunodeficiency Virus (HIV) antibody. This does not preclude the possibility of recent exposure to
                    an infection by HIV.
                </td>
            </tr>
            <tr>
                <td colspan="3" valign="top"><span class="lblForm">FORM NO. 32 REV. 00 / 20-02-2018</span></td>
            </tr>
        </table>
    </center>
</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/examlab_hiv_print.blade.php ENDPATH**/ ?>