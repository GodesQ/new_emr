<html>

<head>
    <title>BLOOD CHEMISTRY</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    @page  {
        font-family: sans-serif;
        font-size: 13px;
    }

    .red-text {
        color: red;
    }
    </style>
</head>

<body>
    <center>
        <table width="760" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                            <tbody>
                                <tr>
                                    <td width="80" rowspan="3" align="center"><img
                                            src="../../../app-assets/images/logo/logo.jpg" width="80" height="80"
                                            alt=""></td>
                                    <td width="356" rowspan="3" align="center" valign="middle">
                                        <span class="lblCompName">MERITA DIAGNOSTIC CLINIC INC.</span><br
                                            style="margin-bottom: 20px">
                                        <span class="lblCompDtl"><b>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave.
                                                Cor. San Antonio St. Malate, Manila<b><br>
                                                    Tel No.: (02) 5310-032 / 5310-0825 / 0917-8576942 / 0908-8908850<br>
                                                    Email: meritaclinic@gmail.com / meritadiagnosticclinic@yahoo.com<br>
                                                    Accredited: DOH * POEA * MARINA * TESDA * Oil &amp; Gas UK<br>Skuld
                                                    P&amp;I * West of England P&amp;I</b></b></span><b><b>
                                            </b></b>
                                    </td>
                                    <td width="218" valign="top" class="brdLeftBtm"><b>NAME:</b><br>
                                        <span
                                            style="font-size:15px"><?php echo e($admission->lastname . ', ' . $admission->firstname . " " . $admission->middlename); ?></span>
                                    </td>
                                    <td width="39" valign="top" class="brdLeftBtm"><b>AGE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->age); ?></span>
                                    </td>
                                    <td width="45" valign="top" class="brdLeftBtm"><b>SEX:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->gender); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="27" colspan="3" align="left" valign="top" class="brdLeftBtm">
                                        <b>REQUESTED BY:</b><br>
                                        <span style="font-size:15px">Technomar Crew Management Corp.</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="26" align="left" valign="top" class="brdLeft"><b>PEME DATE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->trans_date); ?></span>
                                    </td>
                                    <td colspan="2" align="left" valign="top" class="brdLeft"><b>PATIENT
                                            NO:</b><br><span style="font-size:15px"><?php echo e($admission->patientcode); ?></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50" align="center" class="lblReport">BLOOD CHEMISTRY</td>
                </tr>
                <tr>
                    <td>
                        <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
                        <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td>
                                        <table width="100%" border="0" cellpadding="5" cellspacing="5" class="">
                                            <tbody>
                                                <tr>
                                                    <td width="24%"><b>EXAMINATION</b></td>
                                                    <td width="26%"> <b>RESULTS</b></td>
                                                    <td width="50%"><b>NORMAL VALUE</b></td>
                                                </tr>
                                                <tr>
                                                    <td>HBA1C</td>
                                                    <td class="<?php echo e($exam->hba1c < 4.0 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->hba1c); ?> <?php echo e($exam->hba1c < 4.0 ? 'L': null); ?></td>
                                                    <td>4.0-6.4%</td>
                                                </tr>
                                                <tr>
                                                    <td>FBS</td>
                                                    <td class="<?php echo e($exam->fbs < 70 ? 'red-text': null); ?>"><?php echo e($exam->fbs); ?>

                                                        <?php echo e($exam->hba1c < 70 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        70-110 mg/dL
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>BUN</td>
                                                    <td class="<?php echo e($exam->bun < 5 ? 'red-text': null); ?>"><?php echo e($exam->bun); ?>

                                                        <?php echo e($exam->bun < 5 ? 'L': null); ?>

                                                    </td>
                                                    <td>5-20 mg/dL</td>
                                                </tr>
                                                <tr>
                                                    <td>CREATININE</td>
                                                    <td class="<?php echo e($exam->creatinine < 0.8 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->creatinine); ?> <?php echo e($exam->creatinine < 0.8 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        0.8-1.2 mg/dL
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>CHOLESTEROL</td>
                                                    <td class="<?php echo e($exam->cholesterol < 125 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->cholesterol); ?> <?php echo e($exam->cholesterol < 125 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        125-200 mg/dL
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>TRIGLYCERIDES</td>
                                                    <td class="<?php echo e($exam->triglycerides < 35 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->triglycerides); ?>

                                                        <?php echo e($exam->triglycerides < 35 ? 'L': null); ?></td>
                                                    <td>
                                                        M:40-160 F:35-130
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>HDL Chole</td>
                                                    <td class="<?php echo e($exam->hdl < 40 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->hdl); ?> <?php echo e($exam->hdl < 40 ? 'L': null); ?></td>
                                                    <td>
                                                        >40 mg/dL
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>LDL Chole</td>
                                                    <td class="<?php echo e($exam->ldl > 100 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ldl); ?> <?php echo e($exam->ldl > 100 ? 'H': null); ?>

                                                    </td>
                                                    <td>
                                                        < 100 mg/dL </td>
                                                </tr>
                                                <tr>
                                                    <td>VLDL Chole</td>
                                                    <td class="<?php echo e($exam->vldl < 7 ? 'red-text': null); ?>"><?php echo e($exam->vldl); ?>

                                                        <?php echo e($exam->vldl < 7 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        M:8-32 F:7-26
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>URIC ACID</td>
                                                    <td class="<?php echo e($exam->uricacid < 140 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->uricacid); ?> <?php echo e($exam->uricacid < 140 ? 'L': null); ?></td>
                                                    <td>
                                                        140-430 umol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>SGOT (AST)</td>
                                                    <td class="<?php echo e($exam->sgot < 0 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->sgot); ?> <?php echo e($exam->sgot < 0 ? 'L': null); ?></td>
                                                    <td>
                                                        0-38 u/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>SGPT (ALT) </td>
                                                    <td class="<?php echo e($exam->sgpt < 0 ? 'red-text': null); ?>"><?php echo e($exam->sgpt); ?>

                                                        <?php echo e($exam->sgpt < 0 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        0-41 u/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>GGT</td>
                                                    <td class="<?php echo e($exam->ggt < 7 ? 'red-text': null); ?>"><?php echo e($exam->ggt); ?>

                                                        <?php echo e($exam->ggt < 7 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        7-50 u/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>ALK. PHOS.</td>
                                                    <td class="<?php echo e($exam->alkphos < 35 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->alkphos); ?> <?php echo e($exam->alkphos < 35 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        35-129 u/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>TOTAL BILIRUBIN </td>
                                                    <td class="<?php echo e($exam->ttlbilirubin < 0 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ttlbilirubin); ?> <?php echo e($exam->ttlbilirubin < 0 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        0-17 umol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>DIRECT BILIRUBIN</td>
                                                    <td class="<?php echo e($exam->dirbilirubin < 0 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->dirbilirubin); ?> <?php echo e($exam->dirbilirubin < 0 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        0-4.3 umol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>INDIRECT BILIRUBIN</td>
                                                    <td class="<?php echo e($exam->indbilirubin < 0 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->indbilirubin); ?> <?php echo e($exam->indbilirubin < 0 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        0-12.7 umol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>TOTAL PROTEIN</td>
                                                    <td class="<?php echo e($exam->ttlprotein < 66 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ttlprotein); ?> <?php echo e($exam->ttlprotein < 66 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        66-87 g/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>ALBUMIN</td>
                                                    <td class="<?php echo e($exam->albumin < 66 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->albumin); ?> <?php echo e($exam->albumin < 66 ? 'L': null); ?></td>
                                                    <td>
                                                        35-52 g/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>GLOBULIN</td>
                                                    <td class="<?php echo e($exam->globulin < 31 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->globulin); ?> <?php echo e($exam->globulin < 31 ? 'L': null); ?></td>
                                                    <td>
                                                        31-35 g/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>SODIUM</td>
                                                    <td class="<?php echo e($exam->sodium < 31 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->sodium); ?> <?php echo e($exam->sodium < 31 ? 'L': null); ?></td>
                                                    <td>
                                                        31-35 g/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>POTASSIUM</td>
                                                    <td class="<?php echo e($exam->potassium < 135 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->potassium); ?> <?php echo e($exam->potassium < 135 ? 'L': null); ?></td>
                                                    <td>
                                                        135.0-148 mmol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>CHLORIDE</td>
                                                    <td class="<?php echo e($exam->chloride < 96 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->chloride); ?> <?php echo e($exam->chloride < 96 ? 'L': null); ?></td>
                                                    <td>
                                                        96.0-108 mmol/L
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>CALCIUM</td>
                                                    <td class="<?php echo e($exam->calcium < 2.10 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->calcium); ?> <?php echo e($exam->calcium < 2.10 ? 'L': null); ?></td>
                                                    <td>
                                                        2.10-2.90 mmol/L
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="30" align="center"><span class="lblReport">SEROLOGY</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="">
                                            <tbody>
                                                <tr>
                                                    <td width="196" align="left" class=""><b>EXAMINATION</b></td>
                                                    <td width="191" align="left" class=""><b>RESULTS</b></td>
                                                    <td width="172" align="center" class=""><b>CUT OFF VALUE</b></td>
                                                    <td width="169" align="center" class=""><b>PATIENT'S VALUE</b></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">VDRL/RPR</td>
                                                    <td align="left" valign="top"><?php echo e($exam->vdrl_result); ?></td>
                                                    <td align="center" valign="top"> - </td>
                                                    <td align="center" valign="top"> - </td>
                                                </tr>
                                                <tr>
                                                    <td align="left">HBsAg (Hepatitis B) </td>
                                                    <td align="left" valign="top"><?php echo e($exam->hbsag_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbsag_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbsag_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HCV (Hepatitis C) </td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihcv_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihcv_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihcv_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HAV IgG</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihavigg_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigg_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigg_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">TPHA</td>
                                                    <td align="left" valign="top"><?php echo e($exam->tpha_result); ?></td>
                                                    <td align="center" valign="top"> - </td>
                                                    <td align="center" valign="top"> - </td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HBs</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbs_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbs_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbs_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">HBeAg</td>
                                                    <td align="left" valign="top"><?php echo e($exam->hbeag_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbeag_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbeag_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HBe</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbe_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbe_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbe_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HBc (lgM):</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbclgm_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgm_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgm_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left">Anti-HBc (lgG)</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbclgg_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgg_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgg_pv); ?></td>
                                                </tr>
                                                <tr>
                                                    <td align="left"><?php echo e($exam->sothers); ?></td>
                                                    <td align="left" valign="top"><?php echo e($exam->sothers_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->sothers_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->sothers_pv); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="760" border="0" cellpadding="2" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td height="150" align="center" valign="bottom">
                                                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"></td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician1): ?>
                                                                        <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?><br>
                                                                        Medical Technologist<br>
                                                                        Lic. No.
                                                                        <?php echo e($technician1->license_no); ?>

                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td colspan="3" align="center" valign="bottom">
                                                        <table width="200" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"></td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician2): ?>
                                                                        <?php echo e($technician2->firstname . " " . $technician2->middlename . " " . $technician2->lastname . ", " . $technician2->title); ?><br>
                                                                        Pathologist<br>
                                                                        Lic. No. <?php echo e($technician2->license_no); ?>

                                                                        <?php endif; ?>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60"><span class="lblForm">FORM NO. 15<br>REV. 01 / 02-12-2019</span></td>
                </tr>
            </tbody>
        </table>
    </center>


</body>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/examlab_bloodsero_print.blade.php ENDPATH**/ ?>