

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit HIV</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_hiv" role="form">
                            <?php if(Session::get('status')): ?>
                                <?php $__env->startPush('scripts'); ?>
                                    <script>
                                       toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                    </script>
                                <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td colspan="3"><b>EXAMINATION DONE:</b></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <input name="exam" type="radio" class="m-1" id="exam_2" value="enzyme" <?php
                                                echo $exam->exam == "enzyme" ? "checked" : "" ?>>
                                            EIA/CMIA/ELFA&nbsp;
                                            <input name="exam" type="radio" class="m-1" id="exam_0" value="rapid" <?php
                                                echo $exam->exam == "rapid" ? "checked" : "" ?>>
                                            RAPID &nbsp;
                                            <input name="exam" type="radio" class="m-1" id="exam_1" value="particle"
                                                <blade
                                                php|%20echo%20%24exam-%3Eexam%20%3D%3D%20%26%2334%3Bparticle%26%2334%3B%20%3F%20%26%2334%3Bchecked%26%2334%3B%20%3A%20%26%2334%3B%26%2334%3B%20%40endphp%3E%0D>
                                            Particle Agglutination
                                            <input name="exam" type="radio" class="m-1" id="exam_3" value="others" <?php
                                                echo $exam->exam == "others" ? "checked" : "" ?>>
                                            OTHERS&nbsp;
                                        </td>
                                        <td width="45%">
                                            <input name="others" type="text" id="others" value="<?php echo e($exam->others); ?>"
                                                placeholder="Others..." class="form-control" style="width:200px">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="25%"><b>Result</b></td>
                                        <td colspan="2">
                                            <input name="result" type="radio" id="result_0" class="m-1"
                                                value="Non Reactive" <?php echo $exam->result == "others" ? "Non
                                            Reactive" : "" ?>>Non Reactive
                                            <input name="result" type="radio" id="result_1" class="m-1" value="Reactive">
                                                Reactive
                                            <input name="result" type="radio" id="result_2" class="m-1" value="" <?php
                                                echo $exam->result == "others" ? "checked" : "" ?>>Reset
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>HIV Proficiency Cert. <br>
                                                Expiry Date</b></td>
                                        <td colspan="2"><input name="expiry_date" type="date" max="2050-12-31" id="expiry_date"
                                                value="<?php echo e($exam->expiry_date); ?>" class="form-control"
                                                style="width:160px">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td><b>Physician: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician3_id"
                                                                    id="technician3_id" class="form-control">
                                                                    <option <?php echo e($exam->technician3_id == "" || $exam->technician3_id == null ? 'selected' : null); ?> value="">--SELECT--</option>
                                                                    <option <?php echo e($exam->technician3_id == "15" ? 'selected' : null); ?> value="15">Charisse Nicole F. Gonzales, M.D.
                                                                    </option>
                                                                    <option <?php echo e($exam->technician3_id == "26" ? 'selected' : null); ?> value="26">Alexander Cabungcal, MD</option>
                                                                    <option <?php echo e($exam->technician3_id == "27" ? 'selected' : null); ?> value="27">Emma Y. Chua, MD</option>
                                                                    <option <?php echo e($exam->technician3_id == "28" ? 'selected' : null); ?> value="28">Erick A. Ho, MD</option>
                                                                    <option <?php echo e($exam->technician3_id == "29" ? 'selected' : null); ?> value="29">Ana Maria Luisa Javier, MD
                                                                    </option>
                                                                    <option <?php echo e($exam->technician3_id == "30" ? 'selected' : null); ?> value="30">Ethel . Mabbagu, M.D.</option>
                                                                    <option <?php echo e($exam->technician3_id == "32" ? 'selected' : null); ?> value="32">Elizabeth C. Paulo, M.D.</option>
                                                                    <option <?php echo e($exam->technician3_id == "33" ? 'selected' : null); ?> value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                    <option <?php echo e($exam->technician3_id == "34" ? 'selected' : null); ?> value="34">Ricardo Tabinga, MD</option>
                                                                    <option <?php echo e($exam->technician3_id == "39" ? 'selected' : null); ?> value="39">Renelene Macabeo, MD</option>
                                                                    <option <?php echo e($exam->technician3_id == "40" ? 'selected' : null); ?> value="40">Mary Christine G. Fillarca, MD
                                                                    </option>
                                                                    <option <?php echo e($exam->technician3_id == "46" ? 'selected' : null); ?> value="46">admin a. admin, DR.</option>
                                                                    <option <?php echo e($exam->technician3_id == "49" ? 'selected' : null); ?> value="49">Renelene A. Macabeo, M.D.
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "14" ? 'selected' : null); ?>

                                                                        value="14">Rowena P. Bondoc, RMT</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "16" ? 'selected' : null); ?>

                                                                        value="16">Audrey Dianne G. Partosa, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "53" ? 'selected' : null); ?>

                                                                        value="53">Audrey Dianne F. Gonzales, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "55" ? 'selected' : null); ?>

                                                                        value="55">GRACE JOY C. PEÑARANDA, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "56" ? 'selected' : null); ?>

                                                                        value="56">MA. LOURDES C. VELEÑA, RMT
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "33" ? 'selected' : null); ?>

                                                                        value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/HIV/edit-hiv.blade.php ENDPATH**/ ?>