<html>

<head>
    <title>TRANSMITTAL</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    * {
        font-size: 13px;
    }

    @page  {
        size: landscape;
    }
    </style>
</head>

<body>
    <table width="1400" border="0" cellpadding="2" cellspacing="2">
        <tr>
            <td>
                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td width="11%" rowspan="2" align="left"><img src="../../../app-assets/images/logo/logo.jpg"
                                width="116" height="104" alt="" /></td>
                        <td align="left"><b style="font-size: 20px">

                            </b></td>
                    </tr>
                    <tr>
                        <td width="89%" align="left" valign="top">
                            <br />Tel. No.:<br><br>
                            <span style="font-size:9px;">Date Printed: <?php echo e(date("Y-m-d")); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <hr />
                        </td>
                    </tr>
                    <tr>
                        <td height="40" colspan="2" valign="top">
                            <span style="font-weight:bold; font-size:22px">TRANSMITTAL REPORT</span>
                            <span style="margin-left:100px; font-size:16px"><b>Period:</b> <?php echo e($from_date); ?> -
                                <?php echo e($to_date); ?></span>
                            <span style="margin-left:100px; font-size:16px"><b>Agency:</b>
                            </span>
                            <span style="margin-left:100px; font-size:16px"><b>Patient Status:</b>
                                <?php echo e($patientstatus); ?></span>
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellspacing="5" cellpadding="5" class="brdTable">
                    <tbody>
                        <tr>
                            <td width="2%" bgcolor="#C0C0C0" class="brdBtm"><b>No.</b></td>
                            <td width="1%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Adm.ID</b></td>
                            <td width="5%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Agency</b></td>
                            <td width="4%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Surname</b></td>
                            <td width="5%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>First Name</b></td>
                            <td width="6%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Middle Name</b></td>
                            <td width="4%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>PEME Date</b></td>
                            <td width="4%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Position</b></td>
                            <td width="2%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Age</b></td>
                            <td width="17%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Findings</b></td>
                            <td width="13%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Recommendation</b></td>
                            <td width="10%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Vital Signs</b></td>
                            <td width="6%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Remarks</b></td>
                            <td width="5%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Vessel</b></td>
                            <td width="5%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Emp. Status</b></td>
                            <td width="11%" bgcolor="#C0C0C0" class="brdLeftBtm"><b>Med. Pckg.</b></td>
                        </tr>
                        <?php
                            $count = 1; 
                        ?>
                        <?php if(count($patients) != 0): ?>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($count++); ?></td>
                            <td><?php echo e($patient->id); ?></td>
                            <td><?php echo e($patient->agencyname); ?></td>
                            <td><?php echo e($patient->lastname); ?></td>
                            <td><?php echo e($patient->firstname); ?></td>
                            <td><?php echo e($patient->middlename); ?></td>
                            <td><?php echo e($patient->trans_date); ?></td>
                            <td><?php echo e($patient->position); ?></td>
                            <td><?php echo e($patient->age); ?></td>
                            <td>
                                <?php if($patient->examlab_bloodsero_remarks_status == 'findings'): ?>
                                <b>Blood Serology:</b> <?php echo e($patient->examlab_bloodsero_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_feca_remarks_status == 'findings'): ?>
                                <b>Fecalysis :</b> <?php echo e($patient->examlab_feca_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_drug_remarks_status == 'findings'): ?>
                                <b>Fecalysis :</b> <?php echo e($patient->examlab_drug_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_drug_remarks_status == 'findings'): ?>
                                <b>Drug Test :</b> <?php echo e($patient->examlab_drug_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_hema_remarks_status == 'findings'): ?>
                                <b>Hematology :</b> <?php echo e($patient->examlab_hema_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_hepa_remarks_status == 'findings'): ?>
                                <b>Hepatitis :</b> <?php echo e($patient->examlab_hepa_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_hiv_remarks_status == 'findings'): ?>
                                <b>HIV :</b> <?php echo e($patient->examlab_hiv_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_misc_remarks_status == 'findings'): ?>
                                <b>Miscellaneous :</b> <?php echo e($patient->examlab_misc_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_pregnancy_remarks_status == 'findings'): ?>
                                <b>Pregnancy :</b> <?php echo e($patient->examlab_pregnancy_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->examlab_urin_remarks_status == 'findings'): ?>
                                <b>Urinalysis :</b> <?php echo e($patient->examlab_urin_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_audio_remarks_status == 'findings'): ?>
                                <b>Audiometry :</b> <?php echo e($patient->exam_audio_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_cardio_remarks_status == 'findings'): ?>
                                <b>Cardiovascular :</b> <?php echo e($patient->exam_cardio_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_crf_remarks_status == 'findings'): ?>
                                <b>Cardiac Risk Factor :</b> <?php echo e($patient->exam_crf_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_dental_remarks_status == 'findings'): ?>
                                <b>Dental :</b> <?php echo e($patient->exam_dental_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_ecg_remarks_status == 'findings'): ?>
                                <b>ECG :</b> <?php echo e($patient->exam_ecg_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_echodoppler_remarks_status == 'findings'): ?>
                                <b>2D Echo Doppler :</b> <?php echo e($patient->exam_echodoppler_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_echoplain_remarks_status == 'findings'): ?>
                                <b>2D Echo Plain :</b> <?php echo e($patient->exam_echoplain_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_ishihara_remarks_status == 'findings'): ?>
                                <b>Ishihara :</b> <?php echo e($patient->exam_ishihara_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_psycho_remarks_status == 'findings'): ?>
                                <b>Psychological :</b> <?php echo e($patient->exam_psycho_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_psychobpi_remarks_status == 'findings'): ?>
                                <b>Psycho BPI :</b> <?php echo e($patient->exam_psychobpi_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_stressecho_remarks_status == 'findings'): ?>
                                <b>Stress Echo :</b> <?php echo e($patient->exam_stressecho_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_stresstest_remarks_status == 'findings'): ?>
                                <b>Stress Test :</b> <?php echo e($patient->exam_stresstest_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_ultrasound_remarks_status == 'findings'): ?>
                                <b>Ultrasound :</b> <?php echo e($patient->exam_ultrasound_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_visacuity_remarks_status == 'findings'): ?>
                                <b>Visual Acuity :</b> <?php echo e($patient->exam_visacuity_remarks); ?> <br>
                                <?php endif; ?>
                                <?php if($patient->exam_xray_remarks_status == 'findings'): ?>
                                <b>XRAY :</b> <?php echo e($patient->exam_xray_remarks); ?> <br>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($patient->recommendations); ?></td>
                            <td>
                                <b>Height: </b><?php echo e($patient->height); ?> <br>
                                <b>Weight: </b><?php echo e($patient->weight); ?> <br>
                                <b>BMI: </b><?php echo e($patient->bmi); ?> <br>
                            </td>
                            <td>
                                <?php echo e($patient->fit); ?></td>
                            <td><?php echo e($patient->vessel); ?></td>
                            <td><?php echo e($patient->emp_status); ?></td>
                            <td><?php echo e($patient->packagename); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="16" align="center">No Record Found</td>
                        </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>

<script>
window.addEventListener('load', (event) => {
    window.print();
});
</script><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintTemplates/transmittal_print.blade.php ENDPATH**/ ?>