

<?php $__env->startSection('content'); ?>

<div class="app-content content">
    <div class="toaster bg-success "><i class="feather icon-check"></i> <?php echo e(Session::get('success_delete')); ?></div>
    <?php if(Session::get('success_delete')): ?>
    <script>
    document.querySelector('.toaster').classList.add('toaster-active');
    </script>
    <?php endif; ?>
    <div class="container my-4">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-11">
                        <h2 class="text-bold-600">Cashier Official Recipt
                        </h2>
                    </div>
                    <div class="col-md-1">
                        <a href="" class="btn btn-solid btn-primary">Add
                        </a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="card-body">
                <div class="table-responsive">
                    <table data-order='[[ 0, "desc" ]]'
                        class="table table-bordered table-striped table-hover data-table">
                        <thead>
                            <tr>
                                <th>Serial No.</th>
                                <th>OR No.</th>
                                <th>Paying Type</th>
                                <th>OR Date</th>
                                <th>Payor</th>
                                <th>Amount</th>
                                <th width="100px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

    let table = $('.data-table').DataTable({
        processing: true,
        pageLength: 50,
        responsive: true,
        serverSide: true,
        ajax: "/cashier_or",
        columns: [{
                data: 'serial_no',
                name: 'serial_no'
            },
            {
                data: 'trans_no',
                name: 'trans_no',
            },
            {
                data: 'paying_type',
                name: 'paying_type'
            },
            {
                data: 'trans_date',
                name: 'trans_date'
            },
            {
                data: 'payor',
                name: 'payor'
            },
            {
                data: 'amount',
                name: 'amount'
            },
            {
                data: 'action',
                name: 'action',
                orderable: true,
                searchable: true
            },
        ],
    });

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/cashier-or.blade.php ENDPATH**/ ?>