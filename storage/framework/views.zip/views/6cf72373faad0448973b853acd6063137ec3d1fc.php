

<?php $__env->startSection('name'); ?>
<?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
<?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
<img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="container mt-2">
        <div class="card">
            <div class="card-header"></div>
            <div class="card-body">
                <canvas id="myChart" style="width:100%;"></canvas>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script>
let count_deck_services = parseInt('<?php echo e($count_deck_services); ?>');
let count_engine_services = parseInt('<?php echo e($count_engine_services); ?>');
let count_catering_services = parseInt('<?php echo e($count_catering_services); ?>');
let count_other_services = parseInt('<?php echo e($count_other_services); ?>');
let count_none_services = parseInt('<?php echo e($count_none_services); ?>');
var xValues = ["DECK SERVICES", "CATERING SERVICES", "ENGINE SERVICES", "OTHER SERVICES", "NONE SERVICES"];
var yValues = [count_deck_services, count_engine_services, count_catering_services, count_other_services,
    count_none_services
];
var barColors = ["lightseagreen", "lightsalmon", "lightcoral", "aquamarine"];

new Chart("myChart", {
    type: "bar",
    data: {
        labels: xValues,
        datasets: [{
            backgroundColor: barColors,
            data: yValues
        }]
    },
    responsive: true,
    options: {
        legend: {
            display: false
        },
        title: {
            display: true,
            text: "PATIENT CATEGORY STATISTICS"
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Admission/admission_statistics.blade.php ENDPATH**/ ?>