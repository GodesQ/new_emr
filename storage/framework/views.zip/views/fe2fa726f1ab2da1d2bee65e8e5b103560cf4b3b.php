

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Urinalysis</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_urinalysis" role="form">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <?php if(Session::get('status')): ?>
                                    <?php $__env->startPush('scripts'); ?>
                                        <script>
                                            toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                                        </script>
                                    <?php $__env->stopPush(); ?>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control input-sm pull-left" placeholder="Admission No."
                                                    readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table no-border">
                                <tbody>
                                    <tr>
                                        <td width="186"><b>MACROSCOPIC</b></td>
                                        <td width="387"><span class="brdBtm"><b>RESULTS</b></span></td>
                                        <td width="207">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdAll">Color</td>
                                        <td>
                                            <select name="color" id="color" class="form-control">
                                                <option value="" <?php echo $exam->color == "" ? "selected=''" : ""
                                                    ?>>--SELECT--</option>
                                                <option value="Yellow" <?php echo $exam->color == "Yellow" ?
                                                    "selected=''" : "" ?>>Yellow</option>
                                                <option value="Light Yellow" <?php echo $exam->color == "Light Yellow" ?
                                                    "selected=''" : "" ?>>Light Yellow</option>
                                                <option value="Dark Yellow" <?php echo $exam->color == "Dark Yellow" ?
                                                    "selected=''" : "" ?>>Dark Yellow</option>
                                            </select>
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdAll">Transparency</td>
                                        <td>
                                            <select name="transparency" id="transparency" class="form-control">
                                                <option value="" <?php echo $exam->transparency == "" ? "selected=''" :
                                                    "" ?>>--SELECT--</option>
                                                <option value="Clear" <?php echo $exam->transparency == "Clear" ?
                                                    "selected=''" : "" ?>>Clear</option>
                                                <option value="Sl. Turbid" <?php echo $exam->transparency == "Sl. Turbid"
                                                    ? "selected=''" : "" ?>>Sl. Turbid</option>
                                                <option value="Turbid" <?php echo $exam->transparency == "Turbid" ?
                                                    "selected=''" : "" ?>>Turbid</option>
                                            </select>
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdAll">pH</td>
                                        <td>
                                            <select name="ph" id="ph" class="form-control">
                                                <option value="">--SELECT--</option>
                                                <option <?php echo e($exam->ph == "5.0" ? "selected" : null); ?> value="5.0">5.0</option>
                                                <option <?php echo e($exam->ph == "5.5" ? "selected" : null); ?> value="5.5">5.5</option>
                                                <option <?php echo e($exam->ph == "6.0" ? "selected" : null); ?> value="6.0">6.0</option>
                                                <option <?php echo e($exam->ph == "6.5" ? "selected" : null); ?> value="6.5">6.5</option>
                                                <option <?php echo e($exam->ph == "7.0" ? "selected" : null); ?> value="7.0">7.0</option>
                                                <option <?php echo e($exam->ph == "7.5" ? "selected" : null); ?> value="7.5">7.5</option>
                                                <option <?php echo e($exam->ph == "8.0" ? "selected" : null); ?> value="8.0">8.0</option>
                                            </select>
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdAll">Specific Gravity</td>
                                        <td>
                                            <select name="spgravity" id="spgravity" class="form-control">
                                                <option value="">--SELECT--</option>
                                                <option <?php echo e($exam->spgravity == "1.000" ? "selected" : null); ?> value="1.000">1.000</option>
                                                <option <?php echo e($exam->spgravity == "1.005" ? "selected" : null); ?> value="1.005">1.005</option> 
                                                <option <?php echo e($exam->spgravity == "1.010" ? "selected" : null); ?> value="1.010">1.010</option>
                                                <option <?php echo e($exam->spgravity == "1.015" ? "selected" : null); ?> value="1.015">1.015</option>
                                                <option <?php echo e($exam->spgravity == "1.020" ? "selected" : null); ?> value="1.020">1.020</option>
                                                <option <?php echo e($exam->spgravity == "1.020" ? "selected" : null); ?> value="1.025">1.025</option>
                                                <option <?php echo e($exam->spgravity == "1.030" ? "selected" : null); ?> value="1.030">1.030</option>
                                            </select>
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Sugar</td>
                                        <td>
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_0" value="Negative" <?php
                                            echo $exam->sugar == "Negative" ? "checked" : "" ?>>Negative
                                                
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_1" value="+1" <?php
                                                echo $exam->sugar == "+1" ? "checked" : "" ?>>+1
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_2" value="+2" <?php
                                                echo $exam->sugar == "+2" ? "checked" : "" ?>>+2
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_3" value="+3" <?php
                                                echo $exam->sugar == "+3" ? "checked" : "" ?>>+3
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_4" value="+4" <?php
                                                echo $exam->sugar == "+4" ? "checked" : "" ?>>+4
                                            <input name="sugar" type="radio" style="width: 20px; height: 20px;" class="m-1" id="sugar_5" value="" <?php echo
                                                $exam->sugar == "" ? "checked" : "" ?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Protein/Albumin</td>
                                        <td>
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_0"
                                                value="Negative" <?php echo $exam->albumin == "Negative" ? "checked" : ""
                                            ?>>Negative
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_1" value="+1" <?php echo $exam->albumin == "+1" ? "checked" : ""
                                            ?>>+1
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_2" value="+2" <?php echo $exam->albumin == "+2" ? "checked" : ""
                                            ?>>+2
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_3" value="+3" <?php echo $exam->albumin == "+3" ? "checked" : ""
                                            ?>>+3
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_4" value="+4" <?php echo $exam->albumin == "+4" ? "checked" : ""
                                            ?>>+4
                                            <input name="albumin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="albumin_5" value="" <?php
                                                echo $exam->albumin == "" ? "checked" : "" ?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Ketone</td>
                                        <td>
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_0" value="Negative"<?php echo $exam->albumin == "Negative" ? "checked" : ""?>>Negative
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_1" value="+1" <?php
                                                echo $exam->ketone == "+1" ? "checked" : "" ?>>+1
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_2" value="+2" <?php
                                                echo $exam->ketone == "+2" ? "checked" : "" ?>>+2
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_3" value="+3" <?php
                                                echo $exam->ketone == "+3" ? "checked" : "" ?>>+3
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_4" value="+4" <?php
                                                echo $exam->ketone == "+4" ? "checked" : "" ?>>+4
                                            <input name="ketone" type="radio" style="width: 20px; height: 20px;" class="m-1" id="ketone_5" value="" <?php
                                                echo $exam->ketone == "" ? "checked" : "" ?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Urobilinogen</td>
                                        <td>
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_0"
                                                value="Normal" <?php echo $exam->urobilinogen == "Negative" ? "checked" :
                                            "" ?>>Normal
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_1"
                                                value="+1" <?php echo $exam->urobilinogen == "+1" ? "checked" : ""
                                            ?>>+1
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_2"
                                                value="+2" <?php echo $exam->urobilinogen == "+2" ? "checked" : ""
                                            ?>>+2
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_3"
                                                value="+3" <?php echo $exam->urobilinogen == "+3" ? "checked" : ""
                                            ?>>+3
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_4"
                                                value="+4" <?php echo $exam->urobilinogen == "+4" ? "checked" : ""
                                            ?>>+4
                                            <input name="urobilinogen" type="radio" style="width: 20px; height: 20px;" class="m-1" id="urobilinogen_5"
                                                value="" <?php echo $exam->urobilinogen == "" ? "checked" : ""
                                            ?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Bilirubin</td>
                                        <td>
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_0"
                                                value="Negative" <?php echo $exam->bilirubin == "Negative" ? "checked" :
                                            "" ?>>Negative
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_1" value="+1" <?php echo $exam->bilirubin == "+1" ? "checked" : "" ?>> +1
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_2" value="+2" <?php echo $exam->bilirubin == "+2" ? "checked" : "" ?>> +2
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_3" value="+3" <?php echo $exam->bilirubin == "+3" ? "checked" : "" ?>> +3
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_4" value="+4" <?php echo $exam->bilirubin == "+4" ? "checked" : "" ?>> +4    
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_5" value="" <?php echo $exam->bilirubin == "" ? "checked" : ""?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Nitrite</td>
                                        <td>
                                            <input name="nitrite" type="radio" style="width: 20px; height: 20px;" class="m-1" id="nitrite_0"
                                                value="Negative" <?php echo $exam->nitrite == "Negative" ? "checked" : ""
                                            ?>>Negative
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_1" value="+1" <?php echo $exam->nitrite == "+1" ? "checked" : "" ?>> +1
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_2" value="+2" <?php echo $exam->nitrite == "+2" ? "checked" : "" ?>> +2
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_3" value="+3" <?php echo $exam->nitrite == "+3" ? "checked" : "" ?>> +3
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_4" value="+4" <?php echo $exam->nitrite == "+4" ? "checked" : "" ?>> +4    
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_5" value="" <?php echo $exam->nitrite == "" ? "checked" : ""?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Leukocyte</td>
                                        <td>
                                            <input name="leukocyte" type="radio" style="width: 20px; height: 20px;" class="m-1" id="leukocyte_0"
                                                value="Negative" <?php echo $exam->leukocyte == "Negative" ? "checked" :
                                            "" ?>>Negative
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_1" value="+1" <?php echo $exam->leukocyte == "+1" ? "checked" : "" ?>> +1
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_2" value="+2" <?php echo $exam->leukocyte == "+2" ? "checked" : "" ?>> +2
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_3" value="+3" <?php echo $exam->leukocyte == "+3" ? "checked" : "" ?>> +3
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_4" value="+4" <?php echo $exam->leukocyte == "+4" ? "checked" : "" ?>> +4    
                                            <input name="bilirubin" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bilirubin_5" value="" <?php echo $exam->leukocyte == "" ? "checked" : ""?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdAll">Blood Cell</td>
                                        <td>
                                            <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_0" value="Negative" <?php echo $exam->leukocyte == "Negative" ? "checked" :
                                            "" ?>>Negative
                                                <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_1" value="+1" <?php echo $exam->blood == "+1" ? "checked" : "" ?>> +1
                                                <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_2" value="+2" <?php echo $exam->blood == "+2" ? "checked" : "" ?>> +2
                                                <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_3" value="+3" <?php echo $exam->blood == "+3" ? "checked" : "" ?>> +3
                                                <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_4" value="+4" <?php echo $exam->blood == "+4" ? "checked" : "" ?>> +4    
                                                <input name="blood" type="radio" style="width: 20px; height: 20px;" class="m-1" id="blood_5" value="" <?php echo $exam->blood == "" ? "checked" : ""?>>Reset
                                        </td>
                                        <td align="left" valign="top" class="brdAll">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table no-border">
                                <tbody>
                                    <tr>
                                        <td width="24%"><b>MICROSCOPIC</b></td>
                                        <td><span class="brdLeftBtm"><b>RESULTS</b></span></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdLeft">Pus Cells</td>
                                        <td>
                                            <input name="pus" type="text" class="form-control" id="pus"
                                                value="<?php echo e($exam->pus); ?>">
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" valign="top" class="brdLeft">RBC</td>
                                        <td width="49%">
                                            <input name="rbc" type="text" class="form-control" id="rbc"
                                                value="<?php echo e($exam->rbc); ?>">
                                        </td>
                                        <td width="27%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td height="30" align="right" valign="top" class="brdLeft">Bacteria</td>
                                        <td>
                                            <input name="bacteria" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bacteria_0"
                                                value="Occassional" <?php echo $exam->epithelial == "Occassional" ?
                                            "checked" : "" ?>>Occassional
                                            <input name="bacteria" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bacteria_1" value="Few">Few
                                            <input name="bacteria" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bacteria_2" value="Moderate">Moderate
                                            <input name="bacteria" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bacteria_3" value="Many">Many
                                            <input name="bacteria" type="radio" style="width: 20px; height: 20px;" class="m-1" id="bacteria_4" value="Reset">Reset
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="right" class="brdLeft">Others</td>
                                        <td colspan="2"><input name="others" type="text" class="form-control"
                                                id="others" value="<?php echo e($exam->others); ?>"></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                        <td colspan="4">
                                        <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" style="width: 20px; height: 20px;" class="m-1" id="remarks_status_0" value="normal" <?php echo $exam->remarks_status == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" style="width: 20px; height: 20px;" class="m-1" id="remarks_status_1" value="findings" <?php echo $exam->remarks_status == "findings" ? "checked" : null ?>>With Findings
                                        </div>
                                        <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                        </div>
                                        </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "14" ? 'selected' : null); ?>

                                                                        value="14">Rowena P. Bondoc, RMT</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "16" ? 'selected' : null); ?>

                                                                        value="16">Audrey Dianne G. Partosa, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "53" ? 'selected' : null); ?>

                                                                        value="53">Audrey Dianne F. Gonzales, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "55" ? 'selected' : null); ?>

                                                                        value="55">GRACE JOY C. PEÑARANDA, RMT
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "56" ? 'selected' : null); ?>

                                                                        value="56">MA. LOURDES C. VELEÑA, RMT
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "33" ? 'selected' : null); ?>

                                                                        value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Urinalysis/edit-urinalysis.blade.php ENDPATH**/ ?>