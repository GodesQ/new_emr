<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>file_1650439339060</title>
    <meta name="author" content="Authorized User">
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
            text-indent: 0;
        }
        
        .s1 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: bold;
            text-decoration: none;
            font-size: 14pt;
        }
        
        .s2 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: bold;
            text-decoration: none;
            font-size: 12pt;
        }
        
        .s3 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s4 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s5 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8.5pt;
            vertical-align: -2pt;
        }
        
        .s6 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8.5pt;
        }
        
        .s7 {
            color: black;
            font-family: Symbol, serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 10pt;
        }
        
        .s8 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 10pt;
        }
        
        .s9 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s10 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 9pt;
        }
        
        .s11 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
            vertical-align: 1pt;
        }
        
        .s12 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 10pt;
        }
        
        .s13 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 10pt;
        }
        
        .s15 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 9pt;
        }
        
        .s16 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s17 {
            color: #010101;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
            vertical-align: 1pt;
        }
        
        .s18 {
            color: #010101;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s19 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 8.5pt;
        }
        
        .s20 {
            color: #010101;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 9pt;
            vertical-align: 1pt;
        }
        
        .s21 {
            color: #010101;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 9pt;
            vertical-align: 1pt;
        }
        
        .s22 {
            color: #010101;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 8pt;
        }
        
        .s24 {
            color: black;
            font-family: Arial, sans-serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: underline;
            font-size: 11pt;
        }
        
        .s25 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 12pt;
        }
        
        p {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 10pt;
            margin: 0pt;
        }
        
        .s26 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 8pt;
        }
        
        .s27 {
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 12pt;
        }
        
        li {
            display: block;
        }
        
        #l1 {
            padding-left: 0pt;
            counter-reset: c1 1;
        }
        
        #l1>li>*:first-child:before {
            counter-increment: c1;
            content: "("counter(c1, lower-latin)") ";
            color: black;
            font-family: "Times New Roman", serif;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 10pt;
        }
        
        #l1>li:first-child>*:first-child:before {
            counter-increment: c1 0;
        }
        
        table,
        tbody {
            vertical-align: top;
            overflow: visible;
        }
    </style>
</head>

<body>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <table style="border-collapse:collapse;margin-left:6.2595pt" cellspacing="0">
        <tbody>
            <tr style="height:71pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s1" style="padding-top: 10pt;padding-left: 20pt;padding-right: 38pt;text-indent: 0pt;text-align: center;"><a name="bookmark0">PHYSICAL EXAMINATION REPORT/CERTIFICATE</a></p>
                    <p class="s2" style="padding-top: 2pt;padding-left: 20pt;padding-right: 38pt;text-indent: 0pt;text-align: center;"><a name="bookmark1">DEPUTY COMMISSIONER OF MARITIME AFFAIRS</a></p>
                    <p class="s2" style="padding-left: 467pt;padding-right: 38pt;text-indent: 0pt;text-align: center;"><a name="bookmark2">ANNEX 2</a></p>
                    <p class="s2" style="padding-left: 380pt;padding-right: 20pt;text-indent: 0pt;text-align: center;"><a name="">License NO: <input name="co" type="text" id="co" value="" class="brdNone" style="width:100px;text-align:left;border: none;"></a></p>
                    <p class="s2" style="padding-left: 24pt;padding-right: 38pt;text-indent: 0pt;line-height: 13pt;text-align: center;">THE REPUBLIC OF LIBERIA</p>
                </td>
            </tr>
            <tr style="height:22pt">
                <td style="width:241pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="4">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">LAST NAME OF APPLICANT</p>
                    <p class="s4" style="padding-left: 73pt;text-indent: 0pt;text-align: left;"><?php echo e($admission->lastname); ?></p>
                </td>
                <td style="width:198pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">FIRST NAME</p>
                    <p class="s4" style="padding-left: 28pt;text-indent: 0pt;text-align: left;"><?php echo e($admission->firstname); ?></p>
                </td>
                <td style="width:122pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 4pt;padding-right: 56pt;text-indent: 0pt;text-align: left;">MIDDLE INITIAL</p>
                    <p class="s4" style="padding-left: 28pt;text-indent: 0pt;text-align: left;"><?php echo e($admission->middlename); ?></p>
                </td>
            </tr>
            <tr style="height:14pt">
                <td style="width:68pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">DATE OF BIRTH</p>
                    <p class="s4" style="padding-left: 7pt;text-indent: 0pt;line-height: 15pt;text-align: left;"><?php echo e($patientInfo->birthdate); ?></p>
                </td>
                <td style="width:54pt;border-top-style:solid;border-top-width:1pt">
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                </td>
                <td style="width:84pt;border-top-style:solid;border-top-width:1pt">
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                </td>
                <td style="width:35pt;border-top-style:solid;border-top-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                </td>
                <td style="width:153pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">PLACE OF BIRTH</p>
                    <p class="s4" style="padding-left: 6pt;text-indent: 0pt;line-height: 15pt;text-align: left;"><?php echo e($patientInfo->birthplace); ?></p>
                </td>
                <td style="width:45pt;border-top-style:solid;border-top-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                </td>
                <td style="width:122pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">SEX</p>
                </td>
            </tr>
            <tr style="height:17pt">
                <td style="width:206pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt" colspan="3">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">YEAR MONTH DAY</p>
                </td>
                <td style="width:35pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                </td>
                <td style="width:153pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt">
                    <p class="s3" style="padding-top: 4pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">CITY COUNTRY</p>
                </td>
                <td style="width:45pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s6" style="padding-left: 6pt;text-indent: 0pt;line-height: 6pt;text-align: left;"></p>
                </td>
                <td style="width:122pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-top: 4pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">
                        MALE <span><?php echo $admission->gender == "Male" ? '<img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoCheck.gif" width="10">' :'<img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10">' ?></span>
                        FEMALE <span><?php echo $admission->gender == "Female" ? '<img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoCheck.gif" width="10">' :'<img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10">' ?></span>
                    </p>
                </td>
            </tr>
            <tr style="height:68pt">
                <td style="width:257pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="5">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 15pt;text-align: left;">EXAMINATION FOR DUTY AS:</p>
                    <p class="s7" style="padding-left: 13pt;text-indent: 0pt;line-height: 12pt;text-align: left;"><span class="s3">MASTER</span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"><span class="s8"></span><span class="s9">RATING</span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"></p>
                    <p class="s7" style="padding-left: 13pt;text-indent: 0pt;line-height: 12pt;text-align: left;"><span class="s3">MATE</span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"><span class="s8"></span><span class="s9">MOU DECK      </span><img  style="margin-left: 2rem; margin-right: 1rem;"src="../../../app-assets/images/icoUncheck.gif" width="10"></p>
                    <p class="s7" style="padding-left: 13pt;text-indent: 0pt;line-height: 12pt;text-align: left;"><span class="s3">ENGINEER</span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"><span class="s8"></span><span class="s9">MOU ENGINE     </span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"></p>
                    <p class="s7" style="padding-left: 13pt;text-indent: 0pt;text-align: left;"><span class="s3">RADIO OFF</span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"><span class="s8"></span><span class="s9">SUPERNUMERARY  </span><img style="margin-left: 2rem; margin-right: 1rem;" src="../../../app-assets/images/icoUncheck.gif" width="10"></p>
                </td>
                <td style="width:304pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                    <p class="s3" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">MAILING ADDRESS OF APPLICANT:</p>
                    <p class="s10" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php echo e($patientInfo->address); ?></p>
                </td>
            </tr>
            <tr style="height:15pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s8" style="padding-left: 11pt;text-indent: 0pt;line-height: 11pt;text-align: left;">MEDICAL EXAMINATION (SEE REVERSE SIDE FOR MEDICAL REQUIREMENTS) STATE DETAILS ON REVERSE SIDE</p>
                </td>
            </tr>
            <tr style="height:22pt">
                <td style="width:68pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 6pt;padding-right: 28pt;text-indent: 0pt;line-height: 9pt;text-align: center;">HEIGHT</p>
                    <p class="s10" style="padding-top: 1pt;padding-left: 4pt;padding-right: 28pt;text-indent: 0pt;text-align: center;">157</p>
                </td>
                <td style="width:54pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 5pt;padding-right: 14pt;text-indent: 0pt;line-height: 9pt;text-align: center;">WEIGHT</p>
                    <p class="s10" style="padding-left: 4pt;padding-right: 14pt;text-indent: 0pt;text-align: center;">63</p>
                </td>
                <td style="width:84pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 5pt;padding-right: 6pt;text-indent: 0pt;line-height: 9pt;text-align: center;">BLOOD PRESSURE</p>
                    <p class="s10" style="padding-top: 1pt;padding-left: 5pt;padding-right: 6pt;text-indent: 0pt;text-align: center;">120/80mmHg</p>
                </td>
                <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                    <p class="s3" style="padding-left: 6pt;text-indent: 0pt;line-height: 9pt;text-align: left;">PULSE</p>
                    <p class="s10" style="padding-left: 36pt;padding-right: 41pt;text-indent: 0pt;text-align: center;">73</p>
                </td>
                <td style="width:97pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">RESPIRATION</p>
                    <p class="s10" style="padding-left: 29pt;text-indent: 0pt;text-align: left;">18</p>
                </td>
                <td style="width:167pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                    <p class="s3" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">GENERAL APPEARANCE</p>
                    <p class="s6" style="padding-top: 1pt;padding-left: 35pt;text-indent: 0pt;line-height: 10pt;text-align: left;">NORMAL</p>
                </td>
            </tr>
            <tr style="height:65pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s3" style="padding-left: 5pt;padding-right: 322pt;text-indent: 0pt;line-height: 89%;text-align: left; margin-top: 1rem; margin-bottom: 0.5rem;">VISION: <span style="margin: 1rem 2rem 1rem 4rem;">RIGHT EYE</span>  LEFT EYE</p>
                        <p> <span class="s11">WITHOUT GLASSES</span><span class="s12" style="margin: 1rem 2rem 1rem 1rem;">&nbsp; 20/30 </span><span style="margin: 1rem 2rem 1rem 1rem;" class="s12">&nbsp;20/30 </span></p>
                        <p> <span class="s11">WITH GLASSES    </span><span class="s12" style="margin: 1rem 2rem 1rem 2rem;">&nbsp; 20/30 </span><span style="margin: 1rem 2rem 1rem 1rem;" class="s12">&nbsp;20/30 </span></p>
                    <p style="padding-left: 5pt;padding-right: 163pt;text-indent: 0pt;line-height: 16pt;text-align: left;"><span class="s3">DATE OF LAST COLOR VISION TEST (Month/Day/Year) _</span><span class="s15">23 FEB. 2022</span><span class="s10"> </span><span class="s16" style=" background-color: #C1C1C1;">Testing Required every 6 years</span>
                       </p>
                       <p style="padding-left: 5pt;padding-right: 163pt;text-indent: 0pt;line-height: 16pt;text-align: left;"><span class="s3"> COLOR VISION MEETS STANDARDS IN STCW CODE, TABLE A-I/9? YES </span><span class="s7"></span><span class="s8">    </span><span class="s9">NO </span><span class="s7"></span></p>
                </td>
            </tr>
            <tr style="height:22pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s3" style="padding-top: 4pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">COLOR TEST TYPE: BOOK ¨ LANTERN ¨ CHECK IF COLOR TEST IS NORMAL <span style="margin: 1rem 1.5rem;">YELLOW <img src="../../../app-assets/images/icoUncheck.gif" width="10"></span> <span style="margin: 1rem 1.5rem;">RED <img src="../../../app-assets/images/icoUncheck.gif" width="10"></span> <span style="margin: 1rem 1.5rem;">GREEN <img src="../../../app-assets/images/icoUncheck.gif" width="10"></span> <span style="margin: 1rem 1.5rem;">BLUE <img src="../../../app-assets/images/icoUncheck.gif" width="10"></span></p>
                </td>
            </tr>
            <tr style="height:22pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 8pt;text-align: left;">HEARING:</p>
                    <p class="s3" style="padding-left: 79pt;text-indent: 0pt;line-height: 10pt;text-align: left;">RT. EAR <span class="s17" style="margin-right: 3rem; margin-left: 1rem; text-decoration: underline;">NORMAL</span>LEFT EAR <span class="s18" style="margin-right: 3rem; margin-left: 1rem; text-decoration: underline;">NORMAL</span></p>
                </td>
            </tr>
            <tr style="height:22pt">
                <td style="width:280pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="5">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">HEAD AND NECK</p>
                    <p class="s4" style="padding-left: 80pt;text-indent: 0pt;line-height: 9pt;text-align: left;">NORMAL</p>
                </td>
                <td style="width:281pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                    <p class="s3" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">HEART (CARDIOVASCULAR)</p>
                    <p class="s4" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">ECG: NSIVCD - Cleared by Cardiologist</p>
                </td>
            </tr>
            <tr style="height:29pt">
                <td style="width:280pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="5">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">LUNGS</p>
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                    <p class="s4" style="padding-left: 78pt;text-indent: 0pt;text-align: left;">NORMAL</p>
                </td>
                <td style="width:281pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                    <p class="s3" style="padding-left: 4pt;text-indent: 0pt;text-align: left;">SPEECH (DECK/NAVIGATIONAL OFFICER AND RADIO OFFICER) IS SPEECH UNIMPAIRED FOR NORMAL VOICE COMMUNICATION?</p>
                </td>
            </tr>
            <tr style="height:26pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">EXTREMITIES:</p>
                    <p class="s3" style="padding-top: 3pt;padding-left: 77pt;text-indent: 0pt;text-align: left;">UPPER <span class="s17">NORMAL</span>_ LOWER <span class="s18">NORMAL              </span>_</p>
                </td>
            </tr>
            <tr style="height:31pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s3" style="padding-left: 5pt;padding-right: 8pt;text-indent: 0pt;text-align: left;">IS APPLICANT SUFFERING FROM ANY DISEASE LIKELY TO BE AGGRAVATED BY, OR TO RENDER HIM UNFIT FOR SERVICE AT SEA OR LIKELY TO ENDANGER THE HEALTH OF OTHER PERSONS ON BOARD? IF YES, EXPLAIN IN DETAILS OF MEDICAL EXAMINATION ON PAGE 2.</p>
                </td>
            </tr>
            <tr style="height:112pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <div style="width: 100%; display: flex; align-items: center; justify-content: space-around; margin: 1.5rem 0rem;">
                        <div>
                            <div style="border-bottom: 1px solid black; width: 200px;"></div>
                            <div class="s3" style="text-align: center">SIGNATURE OF APPLICANT</div>  
                        </div>
                        <div>
                            <div style="border-bottom: 1px solid black; width: 200px;"></div>
                            <div class="s3" style="text-align: center">DATE OF EXAM</div>  
                        </div>
                        <div>
                            <div style="border-bottom: 1px solid black; width: 200px;"></div>
                            <div class="s3" style="text-align: center">EXPIRY DATE</div>  
                        </div>

                    </div>
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;line-height: 9pt;text-align: left;">THIS IS TO CERTIFY THAT A PHYSICAL EXAMINATION WAS GIVEN TO: <span class="s15">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($admission->lastname); ?>, <?php echo e($admission->firstname); ?> <?php echo e($admission->middlename); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
                    <p class="s3" style="padding-left: 329pt;text-indent: 0pt;line-height: 9pt;text-align: left;">(NAME OF APPLICANT)</p>
                    <p style="text-indent: 0pt;text-align: left;"><br></p>
                    <p class="s3" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">(<u>HE</u>) (SHE) IS FOUND TO BE (FIT) (NOT FIT) FOR DUTY AS A: (MASTER, MATE, ENGINEER, RADIO OFFICER, RATING, MOU DECK, MOU ENGINE or SUPERNUMERARY).</p>
                </td>
            </tr>
            <tr style="height:95pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s8" style="padding-top: 6pt;padding-left: 5pt;text-indent: 0pt;text-align: justify;">NAME AND DEGREE OF PHYSICIAN <span class="s19">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TERESITA  F.  GONZALES  M.D. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
                    <p class="s8" style="padding-top: 6pt;padding-left: 5pt;padding-right: 5pt;text-indent: 0pt;line-height: 161%;text-align: justify;">ADDRESS <span class="s20">&nbsp;5th Floor Jettac Bldg 920 Pres. Quirino Ave.cor. San Antonio, Malate, Manila </span><span class="s21"> </span>NAME OF PHYSICIAN'S CERTIFICATING AUTHORITY <span class="s22">&nbsp;PROFESSIONAL REGULATION COMMISSION </span>
                        <span class="s18"> </span>DATE OF ISSUE OF PHYSICIAN'S CERTIFICATE<span class="s19"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; JUNE  14,  1984 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
                    <p class="s8" style="padding-left: 5pt;text-indent: 0pt;line-height: 12pt;text-align: justify;">SIGNATURE OF PHYSICIAN <u>&nbsp;</u> DATE OF EXAMINATION<span class="s9">: </span><span class="s24">23 FEB. 2022 </span></p>
                </td>
            </tr>
            <tr style="height:84pt">
                <td style="width:561pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="7">
                    <p class="s8" style="padding-left: 59pt;padding-right: 41pt;text-indent: -49pt;text-align: left;">This certificate is issued by authority of the Deputy Commissioner of Maritime Affairs, R.L. and in compliance with the requirements of the Maritime Labour Convention, 2006 for the Medical Examination of Seafarers.</p>
                    <p class="s8" style="padding-top: 1pt;padding-left: 59pt;padding-right: 41pt;text-indent: -43pt;text-align: left;">The Medical Certificate shall be valid for no more than two (2) years from the date of the Examination for those over 18 years of age and for no more than one (1) year for those under 18 years of age.</p>
                    <p class="s8" style="padding-top: 3pt;padding-left: 9pt;text-indent: 0pt;text-align: left;">RLM-l05M (REV. 06/16) <span class="s25">1</span></p>
                </td>
            </tr>
        </tbody>
    </table>
    <div style="height: 100px"></div>
    <p style="padding-top: 3pt;text-indent: 0pt;text-align: center;">MEDICAL REQUIREMENT</p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: center;">
        All applicants for an officer certificate, Seafarer's Identification and Record Book or certification of special qualifications shall be required to have a physical examination reported on this Medical Form completed by a certificated physician. The
        completed medical form must accompany the application for officer certificate, application for seafarer's identity document, or application for certification of special qualifications. This physical examination must be carried out not more than
        12 months prior to the date of making application for an officer certificate, certification of special qualifications or a seafarer's book. Such proof of examination must establish that the applicant is in satisfactory physical condition for the
        specific duty assignment undertaken and is generally in possession of all body faculties necessary in fulfilling the requirements of the seafaring profession. In addition, the following minimum requirements shall apply:</p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <ol id="l1">
        <li data-list-text="(a)">
            <p style="text-indent: -23pt;text-align: justify;">All applicants must have hearing unimpaired for normal sounds and be capable of hearing a whispered voice in the better ear at 15 feet and in the poorer ear at 5 feet.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(b)">
            <p style="text-indent: -23pt;text-align: justify;">Deck officer applicants must have (either with or without glasses) at least 20/20 vision in one eye and at least 20/40 in the other. If the applicant wears glasses, he must have vision without glasses of at least 20/160 in both eyes. Deck
                officer applicants must also have normal color perception and be capable of distinguishing the colors red, green, blue and yellow.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(c)">
            <p style="text-indent: -23pt;text-align: justify;">Engineer and radio officer applicants must have (either with or without glasses) at least 20/30 vision in one eye and at least 20/50 in the other. If the applicant wears glasses, he must have vision without glasses of at least 20/200 in both
                eyes. Engineer and radio officer applicants must also be able to perceive the colors red, yellow and green.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(d)">
            <p style="text-indent: -23pt;text-align: left;">An applicant's blood pressure must fall within an average range, taking age into consideration.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(e)">
            <p style="text-indent: -23pt;text-align: justify;">Applicants afflicted with any of the following diseases or conditions shall be disqualified: epilepsy, insanity, senility, alcoholism, tuberculosis, acute venereal disease or neurosyphilis, AIDS and/or the use of narcotics.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(f)">
            <p style="text-indent: -23pt;text-align: justify;">Deck/Navigational officer applicants and Radio officer applicants must have speech which is unimpaired for normal voice communication.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(g)">
            <p style="text-indent: -23pt;text-align: justify;">Applicants for able seaman, bosun, GP-1, ordinary seaman and junior ordinary seaman must meet the physical requirements for a deck/navigational officer's certificate.</p>
            <p style="text-indent: 0pt;text-align: left;"><br></p>
        </li>
        <li data-list-text="(h)">
            <p style="text-indent: -23pt;text-align: justify;">Applicants for fireman/watertender, oiler/motorman, pumpman, electrician ,wiper, tankerman and survival craft/rescue boat crewman must meet the physical requirements for an engineer officer's certificate.</p>
        </li>
    </ol>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 195pt;text-indent: 0pt;text-align: center;">DETAILS OF MEDICAL EXAMINATION</p>
    <p class="s26" style="padding-left: 195pt;text-indent: 0pt;text-align: center;">(To be completed by examining physician)</p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-left: 51pt;text-indent: 0pt;line-height: 1pt;text-align: left;"></p>
    <p style="text-indent: 0pt;text-align: left;"><br></p>
    <p style="padding-top: 4pt;padding-left: 22pt;text-indent: 0pt;text-align: left;">RLM-l05M (REV. 06/16) <span class="s27">2</span></p>
</body>

</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintPanel/liberian.blade.php ENDPATH**/ ?>