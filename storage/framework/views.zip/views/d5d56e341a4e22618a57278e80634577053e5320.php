

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit Cardiovascular</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_cardiovascular" role="form">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            let toaster = toastr.success(
                                '<?php echo e(Session::get("status")); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table class="table table-responsive table-bordered" id="tblExam" width="100%"
                                cellpadding="2" cellspacing="2">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control my-1"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control my-1 input-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control my-1" readonly="">
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td colspan="3">
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table table-responsive" width="100%" border="0" cellpadding="2"
                                cellspacing="2">
                                <tbody>
                                    <tr>
                                        <td width="21%" align="left"><b>Past Medical History</b></td>
                                        <td colspan="6"><textarea name="pasthistory" id="pasthistory" cols="50" rows="4"
                                                class="form-control my-1"><?php echo e($exam->pasthistory); ?></textarea></td>
                                    </tr>
                                    <tr>
                                        <td width="21%" align="left"><b>Medications/Maintenance</b></td>
                                        <td colspan="6"><textarea name="medmaint" id="medmaint" cols="50" rows="2"
                                                class="form-control my-1"><?php echo e($exam->medmaint); ?></textarea></td>
                                    </tr>
                                    <tr>
                                        <td align="left"><b>Smoking History</b></td>
                                        <td colspan="6"><input name="smoking" id="smoking" type="text"
                                                value="<?php echo e($exam->smoking); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td align="left"><b>Alcohol Intake</b></td>
                                        <td colspan="6"><input name="alcohol" id="alcohol" type="text"
                                                value="<?php echo e($exam->alcohol); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td align="left"><b>VITAL SIGNS</b></td>
                                        <td colspan="6">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="14%"><b>Height (cm)</b></td>
                                        <td width="10%"><input name="height" type="text" id="height"
                                                value="<?php echo e($exam->height); ?>" class="form-control my-1"
                                                style="width:50px">
                                        </td>
                                        <td width="14%"><b>Weight
                                                (kg) </b></td>
                                        <td width="11%"><input name="weight" type="text" id="weight"
                                                value="<?php echo e($exam->weight); ?>" class="form-control my-1"
                                                style="width:50px">
                                        </td>
                                        <td width="13%"><b>Resting BP</b></td>
                                        <td width="17%"><input name="bp" type="text" id="bp" value="<?php echo e($exam->bp); ?>"
                                                size="15" class="form-control my-1" style="width:50px"></td>
                                    </tr>
                                    <tr>
                                        <td><b>BMI</b></td>
                                        <td><input name="bmi" type="text" id="bmi" value="<?php echo e($exam->bmi); ?>"
                                                class="form-control my-1" style="width:50px"></td>
                                        <td><b>Respiratory Rate</b></td>
                                        <td><input name="rhythm" type="text" id="rhythm" value="<?php echo e($exam->rhythm); ?>"
                                                size="15" class="form-control my-1" style="width:50px"></td>
                                        <td><b>Heart Rate</b></td>
                                        <td><input name="hr" type="text" id="hr" value="<?php echo e($exam->hr); ?>"
                                                class="form-control my-1" style="width:50px"></td>
                                    </tr>
                                    <tr>
                                        <td><b>HEENT</b></td>
                                        <td colspan="6"><input name="heent" id="heent" type="text"
                                                value="<?php echo e($exam->heent); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Cardiac Findings</b></td>
                                        <td colspan="6"><input name="cardiac" id="cardiac" type="text"
                                                value="<?php echo e($exam->cardiac); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Lung Findings</b></td>
                                        <td colspan="6"><input name="lung" id="lung" type="text"
                                                value="<?php echo e($exam->lung); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Other Findings</b></td>
                                        <td colspan="6"><input name="other" id="other" type="text"
                                                value="<?php echo e($exam->pasthistoothery); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>12 LEAD ECG</b></td>
                                        <td colspan="6"><input name="egc" id="egc" type="text" value="<?php echo e($exam->egc); ?>"
                                                class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>2D Echocardiogram</b></td>
                                        <td colspan="6"><input name="echo" id="echo" type="text"
                                                value="<?php echo e($exam->echo); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Stress Test</b></td>
                                        <td colspan="6"><input name="stress" id="stress" type="text"
                                                value="<?php echo e($exam->stress); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>TSE</b></td>
                                        <td colspan="6"><input name="tse" id="tse" type="text" value="<?php echo e($exam->tse); ?>"
                                                class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Other Test/s</b></td>
                                        <td colspan="6"><input name="othertest" id="othertest" type="text"
                                                value="<?php echo e($exam->othertest); ?>" class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Cardiac Risk Factor</b></td>
                                        <td colspan="6"><input name="crf" id="crf" type="text" value="<?php echo e($exam->crf); ?>"
                                                class="form-control my-1"></td>
                                    </tr>
                                    <tr>
                                        <td><b>Impression</b></td>
                                        <td colspan="6"><textarea name="impression" id="impression" cols="50" rows="3"
                                                class="form-control my-1"><?php echo e($exam->impression); ?></textarea></td>
                                    </tr>
                                    <tr>
                                        <td><b>Recommendation/s</b></td>
                                        <td colspan="6"><textarea name="recommendations" id="recommendations" cols="50"
                                                rows="3"
                                                class="form-control my-1"><?php echo e($exam->recommendations); ?></textarea>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table" width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table table-responsive" width="100%" border="0" cellspacing="2"
                                cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table class="table" width="100%" border="0" cellspacing="2"
                                                cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="15%"><b>Cardiologist</b></td>
                                                        <td width="85%">
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control my-1">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "29" ? 'selected' : null); ?>

                                                                        value="29">Ana Maria Luisa Javier, MD
                                                                    </option>
                                                                    <option value="30"
                                                                        <?php echo e($exam->technician_id == "30" ? 'selected' : null); ?>>
                                                                        Ethel . Mabbagu, M.D.</option>
                                                                    <option value="39"
                                                                        <?php echo e($exam->technician_id == "39" ? 'selected' : null); ?>>
                                                                        Renelene Macabeo, MD</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit"
                                    class="btn btn-primary">Save</button>
                                <input name="table" id="table" type="hidden" value="exam_cardio">
                                <input name="uid" id="uid" type="hidden" value="3250">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/CardioVascular/edit-cardiovascular.blade.php ENDPATH**/ ?>