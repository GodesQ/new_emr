<html>

<head>
    <title>Referral Slip</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    body,
    table,
    tr,
    td {
        font-family: sans-serif;
        font-size: 13px;
    }

    .fontBoldLrg {
        font: bold 15px sans-serif;
    }

    .fontMed {
        font: normal 12px sans-serif;
    }

    .text-below {
        word-spacing: 1rem;
        font-weight: 600;
        font-size: 0.8rem;
        margin-top: 1rem;
    }

    .box-container {
        padding: 0rem;
        width: 100%;
        margin-bottom: 1rem;
        border: 1px solid black;
        text-align: center;
    }

    .instruction {
        width: 100%;
    }

    .box {
        margin-left: 0.5rem;
        padding-left: 0.8rem;
        padding-right: 0.8rem;
        padding-bottom: 0.1rem;
        padding-top: 0.1rem;
        border: 1px solid black;
    }
    </style>
</head>

<body>

</body>
<center>
    <table celspacing="0" cellpadding="0" width="760">
        <tbody>
            <tr>
                <td>
                    <table width="100%" celspacing="0" cellpadding="5">
                        <tbody>
                            <tr>
                                <td><span style="font: bold 20px sans-serif;">REFERRAL SLIP FOR MEDICAL
                                        EXAMINATION</span></td>
                            </tr>
                            <tr>
                                <td><span style="font: bold 14px sans-serif;">Joint DOH-POEA-MARINA CONSULTATIVE
                                        COMMITTEE</span></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="10" cellpadding="5">
                        <tbody>
                            <tr>
                                <td width="25%"><b>Name of Employer</b></td>
                                <td width="70%">
                                    <div style="border-bottom: 1px solid black;"><?php echo e($referral ? $referral->agencyname : ""); ?></div>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="25%"><b>Vessel</b></td>
                                <td width="70%">
                                    <div style="border-bottom: 1px solid black;"><?php echo e($referral ? $referral->vessel : ""); ?></div>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="25%"><b>Country of Destination</b></td>
                                <td width="70%">
                                    <div style="border-bottom: 1px solid black;"><?php echo e($referral ? $referral->country_destination : ""); ?></div>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="10" cellpadding="5">
                        <tbody>
                            <tr>
                                <td width="100%">
                                    <div style="border-bottom: 1px solid black;  margin-bottom: 0.7rem;"><?php echo e($referral ? $referral->lastname . ", " . $referral->firstname . " " . $referral->middlename : ""); ?>

                                    </div>
                                    <span class="text-below">Lastname, Firstname M.N</span>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="100%">
                                    <div style="border-bottom: 1px solid black; margin-bottom: 1rem;"><?php echo e($referral ? $referral->address : null); ?>

                                    </div>
                                    <div style="text-align: center; font-weight: 600; font-size: 0.8rem;">Permanent Address
                                        (Street,
                                        Municipality)</div>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="10" cellpadding="5">
                        <tbody>
                            <tr>
                                <td>
                                    <div style="border-bottom: 1px solid black; margin-bottom: 1rem;"><?php echo e($referral ? $referral->age . " " . $referral->civil_status  . " " . $referral->position_applied : null); ?>

                                    </div>
                                    <span style="font-weight: 600; font-size: 0.8rem;"><span
                                            style="margin-right: 1.5rem">Age</span> <span
                                            style="margin-right: 1.5rem">Civil
                                            Status</span> <span style="margin-right: 1.5rem">Position
                                            Applied</span></span>
                                </td>
                                <td>
                                    <div class="second-third-row">
                                        <h4>Passport <span
                                                style="font-weight: 400; border-bottom: 1px solid black; margin-left: 0.6rem; padding-right: 1rem"><?php echo e($referral ? $referral->passport : null); ?></span>
                                        </h4>
                                        <h4>SSRB <span
                                                style="font-weight: 400; border-bottom: 1px solid black; margin-left: 0.6rem; padding-right: 1rem"><?php echo e($referral ? $referral->ssrb : null); ?></span>
                                        </h4>
                                        <h4>Cellphone #: <span
                                                style="font-weight: 400; border-bottom: 1px solid black; margin-left: 0.6rem; padding-right: 1rem"><?php echo e($referral ? $referral->contactno : null); ?></span>
                                        </h4>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="box-container">
                        <h2 class="clinic">MERITA DIAGNOSTIC CLINIC INC.</h2>
                        <p style="line-height: 10px">5th floor Jettac Bldg. 920 Pres. Quirino Ave.cor. San Antonio,
                            Malate, Manila
                        </p>
                        <p style="line-height: 10px">Tel: (02) 310-0595/404-3441 / Cell No. 0917-8576942 Email:
                            mdcinc2019@gmail.com
                        </p>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="10" cellpadding="3">
                        <tbody>
                            <tr>
                                <td colspan="2"><b>INSTRUCTION TO WORKER: (OLY PATIENT ARE ALLOWED TO ENTER)</b></td>
                            </tr>
                            <tr>
                                <td width="30%">
                                    1. You are scheduled for medical on
                                </td>
                                <td width="70%">
                                    <div style="border-bottom: 1px solid black;">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">2. Bring 3 copies of 1x1 PICTURES.</td>
                            </tr>
                            <tr>
                                <td colspan="2">3. (FASTING) NO INTAKE OF FOOD OR DRINKS FOR 8-10 HOURS.</td>
                            </tr>
                            <tr>
                                <td colspan="2">4.Non-Compliance of the above Instruction may cause delay of processing
                                    of your application.</td>
                            </tr>
                            <tr>
                                <td colspan="2"><b>I have read, understand and agree to comply with the above
                                        requirment.</b></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="instruction">
                                        <div style="float: left; width: 47%; margin-left: 0.5rem">
                                            <div style="padding: 0.4rem;
                             padding-right: 2rem;
                             border-bottom: 1px solid black;
                             font-weight: 400; text-align: center;"><?php echo e($referral ? $referral->created_date : null); ?></div>
                                            <div style="text-align: center; font-weight: 600; font-size: 0.8rem;">Date
                                            </div>
                                        </div>
                                        <div style="float: right; width: 50%; margin-left: 0.5rem">
                                            <div
                                                style="padding: 0.4rem;padding-right: 2rem;border-bottom: 1px solid black;font-weight: 400; display: flex; justify-content: center; align-items: center;">
                                                <?php if($referral): ?>
                                                <img width="100px" height="30px" style="object-fit:cover;" src="<?php echo base64_decode($referral->signature) ?>"
                                                    alt="">
                                                <?php endif; ?>
                                            </div>
                                            <div style="text-align: center; font-weight: 600; font-size: 0.8rem;">
                                                Signature</div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="3">
                        <tbody>
                            <tr>
                                <td colspan="3">5. Please conduct the following medication exam:</td>
                            </tr>
                            <tr>
                                <td colspan="3">5.1 BASIC DOH PACKAGE (for seabase and landbase) :</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="3">
                        <tbody>
                            <tr>
                                <td width="40%">5.2 For Seafarer</td>
                                <td>Audiometry <span class="box"> </span>
                                </td>
                                <td colspan="2">Ishihara <span class="box"> </span>
                                </td>
                            </tr>
                            <tr>
                                <td>5.3 As required by the country of destination :</td>
                                <td>VDRL <span class="box"> </span>
                                </td>
                                <td>Hepatitis B <span class="box"> </span>
                                </td>
                                <td>HIV <span class="box"> </span>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Medical Package</b></td>
                                <td colspan="3">
                                    <div
                                        style="padding: 0.4rem;padding-right: 2rem;border-bottom: 1px solid black;font-weight: 400; text-align: center;">
                                        <?php echo e($referral ? $referral->packagename : null); ?></div>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Agency / Company</b></td>
                                <td colspan="3">
                                    <div
                                        style="padding: 0.4rem;padding-right: 2rem;border-bottom: 1px solid black;font-weight: 400; text-align: center;">
                                        <?php echo e($referral ? $referral->agencyname : null); ?></div>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Type of Payment: </b></td>
                                <td>Applicant Paid
                                    <span>
                                    <?php if($referral): ?> 
                                        <?php if($referral->payment_type == "Applicant Paid"): ?>
                                            <input type="checkbox" name="" id="" style="margin-top: 0.5rem" checked disabled>
                                        <?php else: ?>
                                            <input type="checkbox" name="" id="" style="margin-top: 0.5rem" disabled>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <input type="checkbox" name="" id="" style="margin-top: 0.5rem" disabled>
                                    <?php endif; ?>
                                    </span>
                                </td>
                                <td>Billed Agency
                                    <?php if($referral): ?> 
                                        <?php if($referral->payment_type == "Billed"): ?> 
                                            <input type="checkbox" name="" id="" style="margin-top: 0.5rem" checked disabled>
                                        <?php else: ?>
                                            <input type="checkbox" name="" id="" style="margin-top: 0.5rem" disabled>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <input type="checkbox" name="" id="" style="margin-top: 0.5rem" disabled>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</center>

</html><?php /**PATH C:\merita-app\resources\views/PrintTemplates/referral_pdf_print.blade.php ENDPATH**/ ?>