

<?php $__env->startSection('name'); ?>
    <?php echo e($data['employeeFirstname'] . " " . $data['employeeLastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_image'); ?>
    <?php if($data['employee_image'] != null || $data['employee_image'] != ""): ?>
    <img src="../../../app-assets/images/employees/<?php echo e($data['employee_image']); ?>" alt="avatar">
    <?php else: ?>
    <img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body my-2">
        <section id="basic-form-layouts">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="basic-layout-form">Add Exam</h4>
                        <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                        
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <form id="update_exam" action="/update_exam" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-body">
                                    <h4 class="form-section"><i class="feather icon-user"></i>Exam</h4>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Exam Name</label>
                                                <input type="text" class="form-control" name='examname'
                                                    value="<?php echo e($exam->examname); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="form-group">
                                                    <label for="">Price</label>
                                                    <input type="text" class="form-control" name='price'
                                                        value="<?php echo e($exam->price); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Category</label>
                                                <input type="text" class="form-control" name='category'
                                                    value="<?php echo e($exam->category); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="form-group">
                                                    <label for="">Section</label>
                                                    <select required name="section" id="" class="form-control">
                                                        <option value="" disabled="" selected="">Select Section
                                                        </option>
                                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->sectionname); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Created at</label>
                                                <input class="form-control" type="text" name="created_at" value="<?php echo date('Y-m-d');
                                    ?>" readonly>
                                                <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions">
                                    <a href="/list_exam" type="reset" class="btn btn-warning mr-1">
                                        <i class="feather icon-x"></i> Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-check-square-o"></i> Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$("#update_exam").submit(function(e) {
    e.preventDefault();
    const fd = new FormData(this);
    $.ajax({
        url: '/update_exam',
        method: 'POST',
        data: fd,
        cache: false,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function(response) {
            console.log(response);
            if (response.status == 200) {
                Swal.fire(
                    'Update!',
                    'Exam Update Successfully!',
                    'success'
                ).then((result) => {
                    if (result.isConfirmed) {
                        location.href = "/list_exam";
                    }
                })
            } else {
                Swal.fire(
                    'Not Send!',
                    'Chart Account Added Failed!',
                    'warning'
                )
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Exam/edit-exam.blade.php ENDPATH**/ ?>