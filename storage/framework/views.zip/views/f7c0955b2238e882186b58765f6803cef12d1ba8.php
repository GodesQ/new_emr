

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Edit ECG</h3>
                            <a href="patient_edit?id=<?php echo e($patient->id); ?>&patientcode=<?php echo e($exam->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/update_ecg" role="form">
                            <?php if(Session::get('status')): ?>
                            <?php $__env->startPush('scripts'); ?>
                            <script>
                            toastr.success('<?php echo e(Session::get("status")); ?>', 'Success');
                            </script>
                            <?php $__env->stopPush(); ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table=bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control my-1"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($exam->admission_id); ?>"
                                                    class="form-control my-1 input-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date"
                                                value="<?php echo e($exam->trans_date); ?>" class="form-control my-1" readonly="">
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td colspan="3">
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($patient->lastname . ', ' . $patient->firstname); ?>"
                                                class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($exam->patientcode); ?>" class="form-control my-1" readonly="">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2"
                                class="table table-bordered table-responsive">
                                <tbody>
                                    <tr>
                                        <td width="12%"><b>Otoscopy:</b></td>
                                        <td width="88%">
                                            <input name="otoscopy" type="text" id="otoscopy"
                                                value="<?php echo e($exam->otoscopy); ?>" size="15" class="form-control my-1"
                                                placeholder="Otoscopy">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Heart:</b></td>
                                        <td>
                                            <input name="heart" type="text" id="heart" value="<?php echo e($exam->heart); ?>"
                                                size="15" class="form-control my-1" placeholder="Heart">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Lung:</b></td>
                                        <td>
                                            <input name="lung" type="text" id="lung" value="<?php echo e($exam->lung); ?>" size="15"
                                                class="form-control my-1" placeholder="Lung">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><b>ECG Result:</b></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio" required name="ecg" id="radio" value="Normal" <?php echo
                                                $exam->ecg == 'Normal' ? 'checked' : '' ?>>
                                            Normal
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio" required name="ecg" id="radio" value="Significant Findings" <?php
                                                echo $exam->ecg == 'Significant Findings' ? 'checked' : '' ?>>
                                            Significant Findings
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio" required name="ecg" id="radio" value="Not Required" <?php echo
                                                $exam->ecg == 'Not Required' ? 'checked' : '' ?>>
                                            Not Required
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>
                                            <input type="radio" required name="ecg" id="radio"
                                                value="Clinically Not Significant">
                                            Clinically Not Significant
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td colspan="4">
                                            <div class="form-group">
                                                <label for=""><b>Remarks</b></label>
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal" <?php echo $exam->remarks_status
                                                == "normal" ? "checked" : null ?>>Normal
                                                <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_1" value="findings" <?php echo
                                                    $exam->remarks_status == "findings" ? "checked" : null ?>>With
                                                Findings
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Remarks" class="form-control" name="remarks"
                                                    id="" cols="30" rows="6"><?php echo e($exam->remarks); ?></textarea>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td><b>Nurse: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select required name="technician_id" id="technician_id"
                                                                    class="form-control my-1">
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "11" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="11">Pinky Jay C. Junio, R.N.</option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "17" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="17">Jennifer Joy C. Velete, RN
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician_id == "52" || $exam->technician_id == null ? 'selected' : null); ?>

                                                                        value="52">Nanette D. Cabiserano</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td width="24%"><b>Physician</b></td>
                                                        <td width="76%">
                                                            <div class="col-md-8">
                                                                <select required name="technician2_id"
                                                                    id="technician2_id" class="form-control my-1">
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "" || $exam->technician2_id == null ? 'selected' : null); ?>

                                                                        value="">--SELECT--</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "15" ? 'selected' : null); ?>

                                                                        value="15">Charisse Nicole F. Gonzales, M.D.
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "26" ? 'selected' : null); ?>

                                                                        value="26">Alexander Cabungcal, MD</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "27" ? 'selected' : null); ?>

                                                                        value="27">Emma Y. Chua, MD</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "28" ? 'selected' : null); ?>

                                                                        value="28">Erick A. Ho, MD</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "29" ? 'selected' : null); ?>

                                                                        value="29">Ana Maria Luisa Javier, MD
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "30" ? 'selected' : null); ?>

                                                                        value="30">Ethel . Mabbagu, M.D.</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "32" ? 'selected' : null); ?>

                                                                        value="32">Elizabeth C. Paulo, M.D.</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "33" ? 'selected' : null); ?>

                                                                        value="33">Noel C. Santos, M.D. FPSP
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "34" ? 'selected' : null); ?>

                                                                        value="34">Ricardo Tabinga, MD</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "39" ? 'selected' : null); ?>

                                                                        value="39">Renelene Macabeo, MD</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "40" ? 'selected' : null); ?>

                                                                        value="40">Mary Christine G. Fillarca, MD
                                                                    </option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "46" ? 'selected' : null); ?>

                                                                        value="46">admin a. admin, DR.</option>
                                                                    <option
                                                                        <?php echo e($exam->technician2_id == "49" ? 'selected' : null); ?>

                                                                        value="49">Renelene A. Macabeo, M.D.
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/ECG/edit-ecg.blade.php ENDPATH**/ ?>