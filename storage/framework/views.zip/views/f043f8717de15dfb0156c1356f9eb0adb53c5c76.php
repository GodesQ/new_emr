

<?php $__env->startSection('content'); ?>

<div class="app-content content">
    <div class="toaster bg-success "><i class="feather icon-check"></i> <?php echo e(Session::get('success_delete')); ?></div>
    <?php if(Session::get('success_delete')): ?>
    <script>
    document.querySelector('.toaster').classList.add('toaster-active');
    </script>
    <?php endif; ?>
    <div class="container my-4">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-11">
                        <h2 class="text-bold-600">List Patients</h2>
                    </div>
                    <div class="col-md-1">
                        <a href="" class="btn btn-solid btn-primary">Add
                        </a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="card-body">
                <div class="table-responsive">
                    <table data-order='[[ 0, "desc" ]]'
                        class="table table-bordered table-striped table-hover data-table">
                        <thead>
                            <tr>
                                <th>Patient Code</th>
                                <th>Firstname</th>
                                <th>Lastname</th>
                                <th>Middlename</th>
                                <th>Email</th>
                                <th width="100px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

    let table = $('.data-table').DataTable({
        processing: true,
        pageLength: 50,
        responsive: true,
        serverSide: true,
        ajax: "/patients",
        columns: [{
                data: 'patientcode',
                name: 'patientcode'
            },
            {
                data: 'firstname',
                name: 'firstname'
            },
            {
                data: 'lastname',
                name: 'lastname'
            },
            {
                data: 'middlename',
                name: 'middlename'
            },
            {
                data: 'email',
                name: 'email'
            },
            {
                data: 'action',
                name: 'action',
                orderable: true,
                searchable: true
            },
        ],
    });

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/patients.blade.php ENDPATH**/ ?>