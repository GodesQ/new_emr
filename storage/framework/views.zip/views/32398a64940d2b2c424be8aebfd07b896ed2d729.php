

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Add Hepatitis</h3>
                            <a href="patient_edit?id=<?php echo e($admission->patient_id); ?>&patientcode=<?php echo e($admission->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/store_hepatitis" role="form">
                            <?php if(Session::get('status')): ?>
                            <div class="success alert-success p-2 my-2">
                                <?php echo e(Session::get('status')); ?>

                            </div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input required required required type="hidden" name="id" value="<?php echo e($admission->id); ?>">
                            <input type="hidden" name="patient_id" value="<?php echo e($admission->patient_id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input required required required name="peme_date" type="text"
                                                id="peme_date" value="<?php echo e($admission->trans_date); ?>" class="form-control"
                                                readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input required required required name="admission_id" type="text"
                                                    id="admission_id" value="<?php echo e($admission->id); ?>"
                                                    class="form-control input required required-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input required required required name="trans_date" type="text"
                                                id="trans_date" value="<?php echo date(
                                    'Y-m-d'
                                ); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input required required required name="patientname" id="patientname"
                                                type="text"
                                                value="<?php echo e($admission->lastname . ", " . $admission->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input required required required name="patientcode" id="patientcode"
                                                type="text" value="<?php echo e($admission->patientcode); ?>" class="form-control"
                                                readonly=""></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table no-border">
                                <tbody>
                                    <tr>
                                        <td align="left" class="brdBtm"><b>Examination</b></td>
                                        <td align="left" class="brdBtm"><b><b>Result</b></b></td>
                                        <td align="left" class="brdLeftBtm">
                                            <p><b>Cut-Off Value</b></p>
                                        </td>
                                        <td align="left" class="brdBtm"><b>Patient Count</b></td>
                                    </tr>
                                    <tr>
                                        <td width="22%" align="left" valign="top">HBsAg</td>
                                        <td width="38%" class="brdLeft">
                                            <input name="hbsag_result" type="radio" class="m-1" id="hbsag_result_0"
                                                value="Non Reactive">Non Reactive<input name="hbsag_result" type="radio"
                                                class="m-1" id="hbsag_result_1" value="Reactive">Reactive<input
                                                name="hbsag_result" type="radio" class="m-1" id="hbsag_result_2"
                                                value="">Reset
                                        </td>
                                        <td width="20%" class="brdLeft"><input name="hbsag_cutoff" type="text"
                                                class="form-control" id="hbsag_cutoff" value=""></td>
                                        <td width="20%" class="brdLeft"><input name="hbsag_value" type="text"
                                                class="form-control" id="hbsag_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBs</td>
                                        <td class="brdLeft">
                                            <input name="antihbs_result" type="radio" class="m-1" id="antihbs_result_0"
                                                value="Non Reactive">Non Reactive<input name="antihbs_result"
                                                type="radio" class="m-1" id="antihbs_result_1"
                                                value="Reactive">Reactive<input name="antihbs_result" type="radio"
                                                class="m-1" id="antihbs_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbs_cutoff" type="text"
                                                class="form-control" id="antihbs_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihbs_value" type="text" class="form-control"
                                                id="antihbs_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">HBeAg</td>
                                        <td class="brdLeft">
                                            <input name="hbeag_result" type="radio" class="m-1" id="hbeag_result_0"
                                                value="Non Reactive">Non Reactive<input name="hbeag_result" type="radio"
                                                class="m-1" id="hbeag_result_1" value="Reactive">Reactive<input
                                                name="hbeag_result" type="radio" class="m-1" id="hbeag_result_2"
                                                value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="hbeag_cutoff" type="text" class="form-control"
                                                id="hbeag_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="hbeag_value" type="text" class="form-control"
                                                id="hbeag_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBe</td>
                                        <td class="brdLeft">
                                            <input name="antihbe_result" type="radio" class="m-1" id="antihbe_result_0"
                                                value="Non Reactive">Non Reactive<input name="antihbe_result"
                                                type="radio" class="m-1" id="antihbe_result_1"
                                                value="Reactive">Reactive<input name="antihbe_result" type="radio"
                                                class="m-1" id="antihbe_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbe_cutoff" type="text"
                                                class="form-control" id="antihbe_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihbe_value" type="text" class="form-control"
                                                id="antihbe_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgM):</td>
                                        <td class="brdLeft">
                                            <input name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_0" value="Non Reactive">Non Reactive<input
                                                name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_1" value="Reactive">Reactive<input
                                                name="antihbclgm_result" type="radio" class="m-1"
                                                id="antihbclgm_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbclgm_cutoff" type="text"
                                                class="form-control" id="antihbclgm_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihbclgm_value" type="text"
                                                class="form-control" id="antihbclgm_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HBc (lgG)</td>
                                        <td class="brdLeft">
                                            <input name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_0" value="Non Reactive">Non Reactive<input
                                                name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_1" value="Reactive">Reactive<input
                                                name="antihbclgg_result" type="radio" class="m-1"
                                                id="antihbclgg_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihbclgg_cutoff" type="text"
                                                class="form-control" id="antihbclgg_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihbclgg_value" type="text"
                                                class="form-control" id="antihbclgg_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgM)</td>
                                        <td class="brdLeft">
                                            <input name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_0" value="Non Reactive">Non Reactive<input
                                                name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_1" value="Reactive">Reactive<input
                                                name="antihavlgm_result" type="radio" class="m-1"
                                                id="antihavlgm_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihavlgm_cutoff" type="text"
                                                class="form-control" id="antihavlgm_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihavlgm_value" type="text"
                                                class="form-control" id="antihavlgm_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HAV (lgG)</td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_0" value="Non Reactive">Non Reactive<input
                                                name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_1" value="Reactive">Reactive<input
                                                name="antihavlgg_result" type="radio" class="m-1"
                                                id="antihavlgg_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_cutoff" type="text" class="form-control"
                                                id="antihavlgg_cutoff" value="">
                                        </td>
                                        <td class="brdLeft">
                                            <input name="antihavlgg_value" type="text" class="form-control"
                                                id="antihavlgg_value" value="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Anti-HCV </td>
                                        <td class="brdLeft">
                                            <input name="antihcv_result" type="radio" class="m-1" id="antihcv_result_0"
                                                value="Non Reactive">Non Reactive<input name="antihcv_result"
                                                type="radio" class="m-1" id="antihcv_result_1"
                                                value="Reactive">Reactive<input name="antihcv_result" type="radio"
                                                class="m-1" id="antihcv_result_2" value="">Reset
                                        </td>
                                        <td class="brdLeft"><input name="antihcv_cutoff" type="text"
                                                class="form-control" id="antihcv_cutoff" value=""></td>
                                        <td class="brdLeft"><input name="antihcv_value" type="text" class="form-control"
                                                id="antihcv_value" value=""></td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top">Others</td>
                                        <td valign="top" class="brdLeft">
                                            <input name="others_result" type="radio" class="m-1" id="others_result_0"
                                                value="Non Reactive">Non Reactive<input name="others_result"
                                                type="radio" class="m-1" id="others_result_1"
                                                value="Reactive">Reactive<input name="others_result" type="radio"
                                                class="m-1" id="others_result_2" value="">Reset
                                        </td>
                                        <td valign="top" class="brdLeft"><input name="others_cutoff" type="text"
                                                class="form-control" id="others_cutoff" value=""></td>
                                        <td valign="top" class="brdLeft"><input name="others_value" type="text"
                                                class="form-control" id="others_value" value=""></td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                        <tr>
                                            <td colspan="4">
                                            <div class="form-group">
                                                    <label for=""><b>Remarks</b></label>
                                                    <input name="remarks_status" type="radio" class="m-1"
                                                    id="remarks_status_0" value="normal">Normal
                                                    <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings">With Findings
                                            </div>
                                            <div class="form-group">
                                                    <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"></textarea>
                                            </div>
                                            </td>
                                        </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                <tbody>
                                    <tr>
                                        <td align="left">
                                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                    <tr>
                                                        <td width="23%"><b>Medical Technologist: </b></td>
                                                        <td width="77%">
                                                            <div class="col-md-8">
                                                                <select name="technician_id" id="technician_id"
                                                                    class="form-control">
                                                                    <option value="">--SELECT--</option>
                                                                    <option value="14">Rowena P. Bondoc, RMT</option>
                                                                    <option value="16">Audrey Dianne G. Partosa, RMT
                                                                    </option>
                                                                    <option value="53" selected="">Audrey Dianne F.
                                                                        Gonzales, RMT</option>
                                                                    <option value="55">GRACE JOY C. PEÑARANDA, RMT
                                                                    </option>
                                                                    <option value="56">MA. LOURDES C. VELEÑA, RMT
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><b>Pathologist: </b></td>
                                                        <td>
                                                            <div class="col-md-8">
                                                                <select name="technician2_id" id="technician2_id"
                                                                    class="form-control">
                                                                    <option value="">--SELECT--</option>
                                                                    <option value="33" selected="">Noel C. Santos, M.D.
                                                                        FPSP</option>
                                                                </select>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/Hepatitis/add-hepatitis.blade.php ENDPATH**/ ?>