

<?php $__env->startSection('content'); ?>
<div class="app-content content bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>Add Ultrasound</h3>
                            <a href="patient_edit?id=<?php echo e($admission->patient_id); ?>&patientcode=<?php echo e($admission->patientcode); ?>"
                                class="float-right btn btn-primary">Back to Patient</a>
                        </div>
                    </div>
                    <div class="card-content p-2">
                        <form name="frm" method="post" action="/store_ultrasound" role="form">
                            <?php if(Session::get('status')): ?>
                            <div class="success alert-success p-2 my-2">
                                <?php echo e(Session::get('status')); ?>

                            </div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <input required type="hidden" name="id" value="<?php echo e($admission->id); ?>">
                            <input type="hidden" name="patient_id" value="<?php echo e($admission->patient_id); ?>">
                            <table id="tblExam" width="100%" cellpadding="2" cellspacing="2"
                                class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td width="92"><b>PEME Date</b></td>
                                        <td width="247">
                                            <input required name="peme_date" type="text" id="peme_date"
                                                value="<?php echo e($admission->trans_date); ?>" class="form-control" readonly="">
                                        </td>
                                        <td width="113"><b>Admission No.</b></td>
                                        <td width="322">
                                            <div class="col-md-10" style="margin-left: -14px">
                                                <input required name="admission_id" type="text" id="admission_id"
                                                    value="<?php echo e($admission->id); ?>"
                                                    class="form-control input required required-sm pull-left"
                                                    placeholder="Admission No." readonly="">
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Exam Date</b></td>
                                        <td><input name="trans_date" type="text" id="trans_date" value="<?php echo date(
                                    'Y-m-d'
                                ); ?>" class="form-control" readonly=""></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td><b>Patient</b></td>
                                        <td>
                                            <input name="patientname" id="patientname" type="text"
                                                value="<?php echo e($admission->lastname . ", " . $admission->firstname); ?>"
                                                class="form-control" readonly="">
                                        </td>
                                        <td><b>Patient Code</b></td>
                                        <td><input name="patientcode" id="patientcode" type="text"
                                                value="<?php echo e($admission->patientcode); ?>" class="form-control" readonly="">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table width="100%" border="0" cellpadding="4" cellspacing="2" class="table table-bordered">
                                <tr>
                                    <td><b>TYPE OF EXAM</b></td>
                                    <td><select name="exam_type" id="exam_type" class="form-control"
                                            style="width:200px">
                                            <option value="">--SELECT--</option>
                                            <option value="KUB" selected="">KUB</option>
                                            <option value="HBT">HBT</option>
                                            <option value="THYROID">THYROID</option>
                                            <option value="BREAST">BREAST</option>
                                            <option value="WHOLE ABDOMEN">WHOLE ABDOMEN</option>
                                            <option value="GENITALS">GENITALS</option>
                                        </select></td>
                                </tr>
                                <tr>
                                    <td width="20%">&nbsp;</td>
                                    <td width="80%"><b>RESULT </b></td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div id="divKUB">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>KIDNEY</b></td>
                                                    <td width="80%"><textarea name="kidney" id="kidney" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top"><b>URETER/URINARY BLADDER</b></td>
                                                    <td><textarea name="urinary_bladder" id="urinary_bladder" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divHBT">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>LIVER</b></td>
                                                    <td width="80%"><textarea name="liver" id="liver" cols="50" rows="5"
                                                            class="form-control"></textarea></td>
                                                </tr>
                                                <tr>
                                                    <td valign="top"><b>GALLBLADDER</b></td>
                                                    <td><textarea name="gall_bladder" id="gall_bladder" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                                <tr>
                                                    <td width="20%" valign="top"><b>PANCREAS</b></td>
                                                    <td width="80%"><textarea name="pancreas" id="pancreas" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divTHYROID">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>THYROID</b></td>
                                                    <td width="80%"><textarea name="thyroid" id="thyroid" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divBREAST">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>BREAST</b></td>
                                                    <td width="80%"><textarea name="breast" id="breast" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divABDOMEN">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>WHOLE ABDOMEN</b></td>
                                                    <td width="80%"><textarea name="abdomen" id="abdomen" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divGENITALS">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>GENITALS</b></td>
                                                    <td width="80%"><textarea name="genitals" id="genitals" cols="50"
                                                            rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div id="divIMPRESSION">
                                            <table width="100%">
                                                <tr>
                                                    <td width="20%" valign="top"><b>IMPRESSION</b></td>
                                                    <td width="80%"><textarea name="impression" id="impression" cols="50" rows="5" class="form-control"></textarea></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <table width="100%" border="0" cellspacing="2" cellpadding="2">
                                                <tbody>
                                                        <tr>
                                                        <td colspan="4">
                                                        <div class="form-group">
                                                                <label for=""><b>Remarks</b></label>
                                                                <input name="remarks_status" type="radio" class="m-1"
                                                                id="remarks_status_0" value="normal">Normal
                                                                <input name="remarks_status" type="radio" class="m-1" id="remarks_status_1" value="findings">With Findings
                                                        </div>
                                                        <div class="form-group">
                                                                <textarea placeholder="Remarks" class="form-control" name="remarks" id="" cols="30" rows="6"></textarea>
                                                        </div>
                                                        </td>
                                                        </tr>
                                                </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="18%"><b>Sonologist: </b></td>
                                    <td width="82%">
                                        <div class="col-md-8">
                                            <select name="technician_id" id="technician_id" class="form-control">
                                                <?php $__currentLoopData = $sonologists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sonologist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($sonologist->id); ?>><?php echo e($sonologist->firstname); ?> <?php echo e($sonologist->lastname); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <div class="box-footer">
                                <button name="action" id="btnSave" value="save" type="submit" class="btn btn-primary"
                                    onclick="return chkAdmission();">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {
    dispExam($('#exam_type').val());
});

$('#exam_type').change(function() {
    dispExam($('#exam_type').val());
});

function dispExam(exam) {
    uid = $('#uid').val();
    $('#divKUB').hide();
    $('#divHBT').hide();
    $('#divTHYROID').hide();
    $('#divBREAST').hide();
    $('#divABDOMEN').hide();
    $('#divGENITALS').hide();

    if (exam == "KUB") {
        $('#divKUB').show();
        $('#impression').val("Normal Kidneys and Urinary Bladder");
        $('#kidney').val(`Right kidney measures 10*.0x44.0 mm. while left kidney measures 111.0x42.0 mm.
Negative for stone, masses nor hydronephrosis.`);
        $('#urinary_bladder').val("Urinary bladder lumen is echofree, Post void shows no residual urine.");
        
    }
    if (exam == "HBT") {
        $('#divHBT').show();
        $('#impression').val(`Normal liver, gallbladder and pancreas.`);
        $('#pancreas').val(`Pancreas is normal in size.`);
        $('#gall_bladder').val(`Gallbladder is normal in size.
No stones nor masses seen.`);
        $('#liver').val(`Liver is normal in size.
The intrahepatic duests are not dilated.
Negative for focal solid cystic mass.`);
    }
    if (exam == "GALLBLADDER") {
        $('#divHBT').show();
    }

    if (exam == "THYROID") $('#divTHYROID').show();
    if (exam == "BREAST") $('#divBREAST').show();
    if (exam == "WHOLE ABDOMEN") $('#divABDOMEN').show();
    if (exam == "GENITALS") $('#divGENITALS').show();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/Ultrasound/add-ultrasound.blade.php ENDPATH**/ ?>