

<?php $__env->startSection('name'); ?>
<?php echo e($data['agencyName']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-content content">
    <div class="container my-2">
        <div class="row p-1">
            <div class="shadow-sm col-lg-3 bg-white p-1">
                <span class="h6 font-weight-normal">DECK</span> <br>
                <div class="h4 font-bold mt-50"><?php echo e($category_count['deck']); ?> PATIENTS</div>
            </div>
            <div class="shadow-sm col-lg-3 bg-white p-1">
                <span class="h6 font-weight-normal">ENGINE</span> <br>
                <div class="h4 font-bold mt-50"><?php echo e($category_count['engine']); ?> PATIENTS</div>
            </div>
            <div class="shadow-sm col-lg-3 bg-white p-1">
                <span class="h6 font-weight-normal">CATERING</span> <br>
                <div class="h4 font-bold mt-50"><?php echo e($category_count['catering']); ?> PATIENTS</div>
            </div>
            <div class="shadow-sm col-lg-3 bg-white p-1">
                <span class="h6 font-weight-normal">OTHER</span> <br>
                <div class="h4 font-bold mt-50"><?php echo e($category_count['other']); ?> PATIENTS</div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4>Your Employees Information</h4>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="float-right container-fluid">
                    <div class="form-group">
                        <label><strong>Status :</strong></label>
                        <select id='status' class="form-control" style="width: 200px">
                            <option value="">All</option>
                            <option value="0">No Exams</option>
                            <option value="1">Registered</option>
                            <option value="2">Admitted & Taking Exam</option>
                            <option value="3">Re Assessment</option>
                            <option value="4">Fit to Work</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-12 table-responsive">
                    <table data-order='[[ 0, "desc" ]]' class="table table-bordered data-table">
                        <thead>
                            <tr>
                                <th>Patient Code</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Gender</th>
                                <th>Package</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let table = $('.data-table').DataTable({
    processing: true,
    pageLength: 25,
    serverSide: true,
    deferRender: true,
    search: {
        "regex": true
    },
    ajax: {
          url: "/agency_patient_table",
          data: function (d) {
                d.status = $('#status').val(),
                d.search = $('input[type="search"]').val()
            }
        },
    columns: [{
            data: 'patientcode',
            name: 'patientcode'
        },
        {
            data: 'lastname',
            name: 'lastname',
            orderable: true,
            searchable: true
        },
        {
            data: 'firstname',
            name: 'firstname',
            orderable: true,
            searchable: true
        },
        {
            data: 'gender',
            name: 'gender',
            orderable: true,
            searchable: true
        },
        {
            data: 'medical_package',
            name: 'medical_package',
            orderable: true,
            searchable: true
        },
        {
            data: 'status',
            name: 'status',
            orderable: true,
            searchable: true
        },
        {
            data: 'action',
            name: 'action',
            orderable: true,
            searchable: true
        },
    ],
});


$('#status').change(function() {
    table.draw();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.agency-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/layouts/agency-dashboard.blade.php ENDPATH**/ ?>