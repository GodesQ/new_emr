

<?php $__env->startSection('name'); ?>
<?php echo e($data['firstname'] . " " . $data['lastname']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('patient_image'); ?>
<?php if($data['patient_image'] != null || $data['patient_image'] != ""): ?>
<img src="../../../app-assets/images/profiles/<?php echo e($data['patient_image']); ?>" alt="avatar">
<?php else: ?>
<img src="../../../app-assets/images/profiles/profilepic.jpg" alt="default avatar">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-body">
        <div class="container my-1">
            <?php if($patientAdmission): ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="float-left">
                            <h5>Status:
                                <?php if($patientAdmission->lab_status == 2): ?>
                                <b><u>FIT TO WORK</u></b>
                                <?php elseif($patientAdmission->lab_status == 1): ?>
                                <b><u>NEED REASSESSMENT</u></b>
                                <?php else: ?>
                                <b><u>MEDICAL DONE </u></b><span>(WAITING FOR RESULT)</span>
                                <?php endif; ?>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col">
                        <h3>Impression</h3>
                        <div class="border container p-1">
                            <?php echo nl2br($patientAdmission->impression) ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col">
                        <h3>Recommendations/Remarks</h3>
                        <div class="border container p-1">
                            <?php echo nl2br($patientAdmission->remarks) ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <h5 class="text-center">You are not admitted</h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\merita-app\resources\views/ProgressInfo/laboratory_result.blade.php ENDPATH**/ ?>