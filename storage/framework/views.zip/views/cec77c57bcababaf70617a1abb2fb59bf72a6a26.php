<html>

<head>
    <title>Blood Serology</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
        .red-text {
            color: red;
        }
    </style>
</head>

<body>
    <center>
        <table width="760" border="0" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td>
                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="brdAll">
                            <tbody>
                                <tr>
                                    <td width="80" rowspan="3" align="center"><img
                                            src="../../../app-assets/images/logo/logo.jpg" width="80" height="80"
                                            alt=""></td>
                                    <td width="356" rowspan="3" align="center" valign="middle">
                                        <span class="lblCompName">MERITA DIAGNOSTIC CLINIC INC.</span><br
                                            style="margin-bottom: 20px">
                                        <span class="lblCompDtl"><b>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave.
                                                Cor. San Antonio St. Malate, Manila<b><br>
                                                    Tel No.: (02) 5310-032 / 5310-0825 / 0917-8576942 / 0908-8908850<br>
                                                    Email: meritaclinic@gmail.com / meritadiagnosticclinic@yahoo.com<br>
                                                    Accredited: DOH * POEA * MARINA * TESDA * Oil &amp; Gas UK<br>Skuld
                                                    P&amp;I * West of England P&amp;I</b></b></span><b><b>
                                            </b></b>
                                    </td>
                                    <td width="218" valign="top" class="brdLeftBtm"><b>NAME:</b><br>
                                        <span
                                            style="font-size:15px; text-transform: uppercase;"><?php echo e($admission->lastname . ', ' . $admission->firstname . " " . $admission->middlename); ?></span>
                                    </td>
                                    <td width="39" valign="top" class="brdLeftBtm"><b>AGE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->age); ?></span>
                                    </td>
                                    <td width="45" valign="top" class="brdLeftBtm"><b>SEX:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->gender); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="27" colspan="3" align="left" valign="top" class="brdLeftBtm">
                                        <b>REQUESTED BY:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->agencyname); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="26" align="left" valign="top" class="brdLeft"><b>PEME DATE:</b><br>
                                        <span style="font-size:15px"><?php echo e($admission->trans_date); ?></span>
                                    </td>
                                    <td colspan="2" align="left" valign="top" class="brdLeft"><b>PATIENT
                                            NO:</b><br><span style="font-size:15px"><?php echo e($admission->patientcode); ?></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="50" align="center" class="lblReport">BLOOD CHEMISTRY</td>
                </tr>
                <tr>
                    <td>
                        <link href="dist/css/eureka-print.css" rel="stylesheet" type="text/css">
                        <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
                            <tbody>
                                <tr>
                                    <td>
                                        <table width="100%" border="0" cellpadding="5" cellspacing="5" class="">
                                            <tbody>
                                                <tr>
                                                    <td width="24%"><b>EXAMINATION</b></td>
                                                    <td width="26%"> <b>RESULTS</b></td>
                                                    <td width="50%"><b>NORMAL VALUE</b></td>
                                                </tr>
                                                <?php if($exam->hba1c): ?>
                                                <tr>
                                                    <td>HBA1C</td>
                                                    <td class="<?php echo e($exam->hba1c < 4.0 ||$exam->hba1c > 6.4  ? 'red-text': null); ?>">
                                                        <?php echo e($exam->hba1c); ?>

                                                        <?php if($exam->hba1c < 0.8): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->hba1c > 1.2): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>4.0-6.4%</td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->fbs): ?>
                                                <tr>
                                                    <td>FBS</td>
                                                    <td class="<?php echo e($exam->fbs < 70 || $exam->bun > 110 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->fbs); ?>

                                                        <?php if($exam->bun < 5): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->bun > 110): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        70-110 mg/dL
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->bun): ?>
                                                <tr>
                                                    <td>BUN</td>
                                                    <td class="<?php echo e($exam->bun < 5 || $exam->bun > 20 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->bun); ?>

                                                        <?php if($exam->bun < 5): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->bun > 20): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>5-20 mg/dL</td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->creatinine): ?>
                                                <tr>
                                                    <td>CREATININE</td>
                                                    <td class="<?php echo e($exam->creatinine < 0.8 || $exam->creatinine > 1.2 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->creatinine); ?>

                                                        <?php if($exam->creatinine < 0.8): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->creatinine > 1.2): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        0.8-1.2 mg/dL
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->cholesterol): ?>
                                                <tr>
                                                    <td>CHOLESTEROL</td>
                                                    <td class="<?php echo e($exam->cholesterol < 125 || $exam->cholesterol > 200 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->cholesterol); ?>

                                                        <?php if($exam->cholesterol < 125): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->cholesterol > 200): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        125-200 mg/dL
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->triglycerides): ?>
                                                <tr>
                                                    <td>TRIGLYCERIDES</td>
                                                    <td class="<?php echo e($exam->triglycerides < 35 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->triglycerides); ?> <?php echo e($exam->triglycerides < 35 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        M:40-160 F:35-130
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->hdl): ?>
                                                <tr>
                                                    <td>HDL Chole</td>
                                                    <td class="<?php echo e($exam->hdl < 40 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->hdl); ?> <?php echo e($exam->hdl < 40 ? 'L': null); ?>

                                                     </td>
                                                    <td>
                                                        >40 mg/dL
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->ldl): ?>
                                                <tr>
                                                    <td>LDL Chole</td>
                                                    <td class="<?php echo e($exam->ldl > 100 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ldl); ?> <?php echo e($exam->ldl > 100 ? 'H': null); ?>

                                                    </td>
                                                    <td>
                                                        < 100 mg/dL </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->vldl): ?>
                                                <tr>
                                                    <td>VLDL Chole</td>
                                                    <td class="<?php echo e($exam->vldl < 7 ? 'red-text': null); ?>">
                                                            <?php echo e($exam->vldl); ?> <?php echo e($exam->vldl < 7 ? 'L': null); ?>

                                                    </td>
                                                    <td>
                                                        M:8-32 F:7-26
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->uricacid): ?>
                                                <tr>
                                                    <td>URIC ACID</td>
                                                    <td class="<?php echo e($exam->uricacid < 140 || $exam->uricacid > 430 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->uricacid); ?>

                                                        <?php if($exam->uricacid < 140): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->uricacid > 430): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        140-430 umol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->sgot): ?>
                                                <tr>
                                                    <td>SGOT (AST)</td>
                                                    <td class="<?php echo e($exam->sgot < 0 || $exam->sgot > 38 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->sgot); ?>

                                                        <?php if($exam->sgot < 0): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->sgot > 38): ?>
                                                            H
                                                        <?php endif; ?>
                                                    <td>
                                                        0-38 u/L
                                                    </td>
                                                </tr>
                                                 <?php endif; ?>
                                                <?php if($exam->sgpt): ?>
                                                <tr>
                                                    <td>SGPT (ALT) </td>
                                                    <td class="<?php echo e($exam->sgpt < 0 || $exam->sgpt > 41 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->sgpt); ?>

                                                        <?php if($exam->sgpt < 0): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->sgpt > 41): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        0-41 u/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->ggt): ?>
                                                    <tr>
                                                        <td>GGT</td>
                                                        <td class="<?php echo e($exam->ggt < 7 || $exam->ggt > 50 ? 'red-text': null); ?>">
                                                            <?php echo e($exam->ggt); ?>

                                                            <?php if($exam->ggt < 7): ?>
                                                            L
                                                            <?php endif; ?>
                                                            <?php if($exam->ggt > 50): ?>
                                                                H
                                                            <?php endif; ?>
                                                           
                                                        </td>
                                                        <td>
                                                            7-50 u/L
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                <?php if($exam->alkphos): ?>
                                                <tr>
                                                    <td>ALK. PHOS.</td>
                                                    <td class="<?php echo e($exam->alkphos < 35 || $exam->alkphos > 129 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->alkphos); ?>

                                                        <?php if($exam->alkphos < 35): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->alkphos > 129): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        35-129 u/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->ttlbilirubin): ?>
                                                <tr>
                                                    <td>TOTAL BILIRUBIN </td>
                                                    <td class="<?php echo e($exam->ttlbilirubin < 0 || $exam->ttlbilirubin > 17 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ttlbilirubin); ?>

                                                        <?php if($exam->ttlbilirubin < 0): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->ttlbilirubin > 17): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        0-17 umol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                 <?php if($exam->dirbilirubin): ?>
                                                <tr>
                                                    <td>DIRECT BILIRUBIN</td>
                                                    <td class="<?php echo e($exam->dirbilirubin < 0 || $exam->dirbilirubin > 4.3 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->dirbilirubin); ?>

                                                        <?php if($exam->dirbilirubin < 0): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->dirbilirubin > 4.3): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        0-4.3 umol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->indbilirubin): ?>
                                                    <tr>
                                                        <td>INDIRECT BILIRUBIN</td>
                                                        <td class="<?php echo e($exam->indbilirubin < 0 || $exam->indbilirubin > 12.7 ? 'red-text': null); ?>">
                                                            <?php echo e($exam->indbilirubin); ?>

                                                            <?php if($exam->indbilirubin < 0): ?>
                                                                L
                                                            <?php endif; ?>
                                                            <?php if($exam->indbilirubin > 12.7): ?>
                                                                H
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            0-12.7 umol/L
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                 <?php if($exam->ttlprotein): ?>
                                                <tr>
                                                    <td>TOTAL PROTEIN</td>
                                                    <td class="<?php echo e($exam->ttlprotein < 66 || $exam->ttlprotein > 87 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->ttlprotein); ?>

                                                        <?php if($exam->ttlprotein < 66): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->ttlprotein > 87): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        66-87 g/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->albumin): ?>
                                                <tr>
                                                    <td>ALBUMIN</td>
                                                    <td class="<?php echo e($exam->albumin < 35 || $exam->albumin > 52 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->albumin); ?>

                                                        <?php if($exam->albumin < 35): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->albumin > 52): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        35-52 g/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>  
                                                <?php if($exam->globulin): ?>
                                                <tr>
                                                    <td>GLOBULIN</td>
                                                    <td class="<?php echo e($exam->globulin < 31 || $exam->globulin > 35 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->globulin); ?>

                                                        <?php if($exam->globulin < 31): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->globulin > 35): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        31-35 g/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?> 
                                                <?php if($exam->sodium): ?>
                                                <tr>
                                                    <td>SODIUM</td>
                                                    <td class="<?php echo e($exam->sodium < 31 || $exam->sodium > 35 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->sodium); ?>

                                                        <?php if($exam->sodium < 31): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->sodium > 35): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        31-35 g/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>    
                                                <?php if($exam->potassium): ?>
                                                <tr>
                                                    <td>POTASSIUM</td>
                                                    <td class="<?php echo e($exam->potassium < 135 || $exam->potassium > 148 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->potassium); ?>

                                                        <?php if($exam->potassium < 135): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->potassium > 148): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        135.0-148 mmol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>   
                                                <?php if($exam->chloride): ?>
                                                <tr>
                                                    <td>CHLORIDE</td>
                                                    <td class="<?php echo e($exam->chloride < 96 || $exam->chloride > 108 ? 'red-text': null); ?>">
                                                        <?php echo e($exam->chloride); ?>

                                                        <?php if($exam->chloride < 96): ?>
                                                            L
                                                        <?php endif; ?>
                                                        <?php if($exam->chloride > 108): ?>
                                                            H
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        96.0-108 mmol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->calcium): ?>
                                                <tr>
                                                    <td>CALCIUM</td>
                                                    <td class="<?php echo e($exam->calcium < 2.10 || $exam->calcium > 2.90 ? 'red-text': null); ?>">
                                                            <?php echo e($exam->calcium); ?>

                                                            <?php if($exam->calcium < 2.10): ?>
                                                                L
                                                            <?php endif; ?>
                                                            <?php if($exam->calcium > 2.90): ?>
                                                                H
                                                            <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        2.10-2.90 mmol/L
                                                    </td>
                                                </tr>
                                                <?php endif; ?>    
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="30" align="center"><span class="lblReport">SEROLOGY</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="760" border="0" cellpadding="2" cellspacing="0" class="">
                                            <tbody>
                                                <tr>
                                                    <td width="196" align="left" class=""><b>EXAMINATION</b></td>
                                                    <td width="191" align="left" class=""><b>RESULTS</b></td>
                                                    <td width="172" align="center" class=""><b>CUT OFF VALUE</b></td>
                                                    <td width="169" align="center" class=""><b>PATIENT'S VALUE</b></td>
                                                </tr>
                                                <?php if($exam->vdrl_result): ?>
                                                <tr>
                                                    <td align="left">VDRL/RPR</td>
                                                    <td align="left" valign="top"><?php echo e($exam->vdrl_result); ?></td>
                                                    <td align="center" valign="top"> - </td>
                                                    <td align="center" valign="top"> - </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->hbsag_result): ?>
                                                <tr>
                                                    <td align="left">HBsAg (Hepatitis B) </td>
                                                    <td align="left" valign="top"><?php echo e($exam->hbsag_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbsag_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbsag_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihcv_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HCV (Hepatitis C) </td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihcv_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihcv_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihcv_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihavigm_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HAV IgM</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihavigm_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigm_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigm_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihavigg_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HAV IgG</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihavigg_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigg_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihavigg_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->tpha_result): ?>
                                                <tr>
                                                    <td align="left">TPHA</td>
                                                    <td align="left" valign="top"><?php echo e($exam->tpha_result); ?></td>
                                                    <td align="center" valign="top"> - </td>
                                                    <td align="center" valign="top"> - </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihbs_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HBs</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbs_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbs_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbs_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->hbeag_result): ?>
                                                <tr>
                                                    <td align="left">HBeAg</td>
                                                    <td align="left" valign="top"><?php echo e($exam->hbeag_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbeag_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->hbeag_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihbe_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HBe</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbe_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbe_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbe_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihbclgm_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HBc (lgM):</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbclgm_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgm_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgm_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->antihbclgg_result): ?>
                                                <tr>
                                                    <td align="left">Anti-HBc (lgG)</td>
                                                    <td align="left" valign="top"><?php echo e($exam->antihbclgg_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgg_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->antihbclgg_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($exam->sothers_result): ?>
                                                <tr>
                                                    <td align="left"><?php echo e($exam->sothers); ?></td>
                                                    <td align="left" valign="top"><?php echo e($exam->sothers_result); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->sothers_cov); ?></td>
                                                    <td align="center" valign="top"><?php echo e($exam->sothers_pv); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width="100%" border="0" cellpadding="2" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td height="150" align="center" valign="bottom">
                                                        <table width="260" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                         <?php if($technician1): ?>
                                                                            <img src="<?php echo e($technician1->signature); ?>" width="100px" style="object-fit: cover;"/>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician1): ?>
                                                                            <?php echo e($technician1->firstname . " " . $technician1->middlename . " " . $technician1->lastname . ", " . $technician1->title); ?><br>
                                                                            Medical Technologist<br>
                                                                            Lic. No.
                                                                            <?php echo e($technician1->license_no); ?>

                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td colspan="3" align="center" valign="bottom">
                                                        <table width="260" border="0" cellspacing="2" cellpadding="2">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"></td>
                                                                </tr>
                                                                <tr valign="bottom">
                                                                    <td align="center" class="brdTop">
                                                                        <?php if($technician2): ?>
                                                                        <?php echo e($technician2->firstname . " " . $technician2->middlename . " " . $technician2->lastname . ", " . $technician2->title); ?><br>
                                                                        Pathologist<br>
                                                                        Lic. No. <?php echo e($technician2->license_no); ?>

                                                                        <?php endif; ?>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60"><span class="lblForm">FORM NO. 15<br>REV. 01 / 02-12-2019</span></td>
                </tr>
            </tbody>
        </table>
    </center>


</body>

</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintTemplates/examlab_bloodsero_print.blade.php ENDPATH**/ ?>