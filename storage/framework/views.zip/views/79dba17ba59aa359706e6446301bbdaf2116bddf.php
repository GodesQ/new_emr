<?php 
    $count = 0;
?>
<html>

<head>
    <title>Follow UP Form</title>
    <link href="../../../app-assets/css/print.css" rel="stylesheet" type="text/css">
    <style>
    * {
        font-family: constantia;
        font-size: 12px;
        text-transform: uppercase;
    }

    .fontBoldLrg {
        font: bold 15px constantia;
    }

    .fontMed {
        font: bold 13px constantia;
    }

    div,
    ul li {
        font-size: 12px;
        font-weight: 400;
    }
    @page  {
        margin-top: 0;
        size: legal;
    }
    </style>
</head>
<body>
        <table valign="top" width="800" cellspacing="0" cellpadding="0" class="brdNone">
            <tbody>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="10" class="brdNone">
                            <tbody>
                                <tr>
                                    <td width="7%" rowspan="5" align="center"><img src="../../../app-assets/images/logo/logo.jpg" width="80" height="80" alt=""></td>
                                    <td width="73%" align="center">
                                        <span style="font-size: 25px; font-weight: 800;">MERITA DIAGNOSTIC CLINIC INC.</span> <br>
                                        <span>5th &amp; 6th Flr Jettac Bldg., 920 Quirino Ave. Cor. San Antonio St. Malate, Manila</span>
                                    </td>
                                    <td width="20%"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="10" cellpadding="0" class="brdNone">
                            <tbody>
                                <tr>
                                    <td width="60%">
                                        <div style="display: flex; align-items: flex-end; justify-content: flex-start;  width: 100%;">
                                            <div style="width: 15%;">Name :</div>
                                            <div class="fontBoldLrg" style="border-bottom: 1px solid black; width: 85%;"><?php echo e($patient->firstname); ?> <?php echo e($patient->middlename); ?> <?php echo e($patient->lastname); ?> </div>
                                        </div>
                                    </td>
                                    <td width="20%">
                                        <div style="display: flex; align-items: flex-stendart; justify-content: flex-start; width: 100%;">
                                            <div style="width: 25%;">Age :</div>
                                            <div class="fontBoldLrg" style="border-bottom: 1px solid black; width: 75%;"><?php echo e($patient->age); ?></div>
                                        </div>
                                    </td>
                                    <td width="20%">
                                        <div style="display: flex; align-items: flex-end; justify-content: flex-start; width: 100%;">
                                            <div style="width: 25%;">Sex :</div>
                                            <div class="fontBoldLrg" style="border-bottom: 1px solid black; width: 75%;"><?php echo e($patient->gender); ?></div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: flex-end; justify-content: flex-start; width: 100%;">
                                            <div style="width: 15%;">Agency :</div>
                                            <div class="fontBoldLrg" style="border-bottom: 1px solid black; width: 85%;"><?php echo e($patient->agencyname); ?></div>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div style="display: flex; align-items: flex-end; justify-content: flex-start; width: 100%;">
                                            <div style="width: 25%;">Position :</div>
                                            <div class="fontBoldLrg" style="border-bottom: 1px solid black; width: 75%;"><?php echo e($patient->position_applied); ?></div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <h2 style="font-size: 25px; font-weight: 800;">FOLLOW UP FORM</h2>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellspacing="0" cellpadding="10" class="brdTable">
                            <tbody>
                                <tr>
                                    <td width="15%">DATE</td>
                                    <td width="30%">FINDINGS</td>
                                    <td width="30%">DIAGNOSIS / IMPRESSION</td>
                                    <td width="25%">RECOMMENDATIONS</td>
                                </tr>
                                <?php if($exam_audio): ?>
                                   <?php if($exam_audio->remarks_status == "findings"): ?>
                                   <?php $count++ ?>
                                <tr>
                                    <td valign="top"><?php echo e(date_format(new DateTime($exam_audio->trans_date), "F d, Y")); ?></td>
                                    <td valign="top">
                                        <b>Audiometry :</b> <?php echo nl2br($exam_audio->remarks) ?>
                                    </td>
                                    <td valign="top"><?php echo nl2br($admission->impression) ?></td>
                                    <td valign="top"><?php echo nl2br($admission->remarks) ?></td>
                                </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_dental): ?>
                                    <?php if($exam_dental->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top">
                                                <?php echo e(date_format(new DateTime($exam_dental->trans_date), "F d, Y")); ?>

                                            </td>
                                            <td valign="top">
                                               <b>Dental :</b> <?php echo nl2br($exam_dental->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_ecg): ?>
                                    <?php if($exam_ecg->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top">
                                                <?php echo e(date_format(new DateTime($exam_ecg->trans_date), "F d, Y")); ?>

                                            </td>
                                            <td valign="top">
                                              <b>ECG :</b>  <?php echo nl2br($exam_ecg->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_echodoppler): ?>
                                    <?php if($exam_echodoppler->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_echodoppler->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                               <b>Echo Doppler :</b> <?php echo nl2br($exam_echodoppler->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_echoplain): ?>
                                    <?php if($exam_echoplain->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_echoplain->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                               <b>Echo Plain :</b> <?php echo nl2br($exam_echoplain->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_stressecho): ?>
                                    <?php if($exam_stressecho->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_stressecho->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Stress Echo :</b>  <?php echo nl2br($exam_stressecho->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_stresstest): ?>
                                    <?php if($exam_stresstest->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_stresstest->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Stress Test :</b>  <?php echo nl2br($exam_stresstest->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_ishihara): ?>
                                    <?php if($exam_ishihara->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_ishihara->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Ishihara :</b>  <?php echo nl2br($exam_ishihara->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_visacuity): ?>
                                    <?php if($exam_visacuity->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_visacuity->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Visual Acuity :</b>  <?php echo nl2br($exam_visacuity->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_psycho): ?>
                                    <?php if($exam_psycho->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_psycho->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Psychological :</b>  <?php echo nl2br($exam_psycho->remarks) ?>
                                            </td>
                                            
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_psychobpi): ?>
                                    <?php if($exam_psychobpi->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_psychobpi->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Psycho BPI :</b>  <?php echo nl2br($exam_psychobpi->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_ultrasound): ?>
                                    <?php if($exam_ultrasound->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_ultrasound->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Ultrasound :</b>  <?php echo nl2br($exam_ultrasound->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_xray): ?>
                                    <?php if($exam_xray->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_xray->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Xray :</b>  <?php echo nl2br($exam_xray->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_cardio): ?>
                                    <?php if($exam_cardio->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_cardio->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Cardiovascular :</b>  <?php echo nl2br($exam_cardio->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_crf): ?>
                                    <?php if($exam_crf->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_crf->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>CRF :</b>  <?php echo nl2br($exam_crf->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_physical): ?>
                                    <?php if($exam_physical->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_physical->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Physical Exam :</b>  <?php echo nl2br($exam_physical->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($exam_blood_serology): ?>
                                    <?php if($exam_blood_serology->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($exam_blood_serology->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Physical Exam :</b>  <?php echo nl2br($exam_blood_serology->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_hiv): ?>
                                    <?php if($examlab_hiv->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_hiv->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Physical Exam :</b>  <?php echo nl2br($examlab_hiv->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_drug): ?>
                                    <?php if($examlab_drug->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_drug->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Drug Test :</b>  <?php echo nl2br($examlab_drug->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_hepa): ?>
                                    <?php if($examlab_hepa->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_hepa->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Hepatitis :</b>  <?php echo nl2br($examlab_hepa->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_hema): ?>
                                    <?php if($examlab_hema->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_hema->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Hematology :</b>  <?php echo nl2br($examlab_hema->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_feca): ?>
                                    <?php if($examlab_feca->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_feca->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Fecalysis :</b>  <?php echo nl2br($examlab_feca->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_feca): ?>
                                    <?php if($examlab_feca->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_feca->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Fecalysis :</b>  <?php echo nl2br($examlab_feca->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_pregnancy): ?>
                                    <?php if($examlab_pregnancy->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_pregnancy->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Pregnancy :</b>  <?php echo nl2br($examlab_pregnancy->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_urin): ?>
                                    <?php if($examlab_urin->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_urin->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Urinalysis :</b>  <?php echo nl2br($examlab_urin->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($examlab_misc): ?>
                                    <?php if($examlab_misc->remarks_status == "findings"): ?>
                                    <?php $count++ ?>
                                        <tr>
                                            <td valign="top"><?php echo e(date_format(new DateTime($examlab_misc->trans_date), "F d, Y")); ?></td>
                                            <td valign="top">
                                              <b>Miscellaneous :</b>  <?php echo nl2br($examlab_misc->remarks) ?>
                                            </td>
                                            <td valign="top"></td>
                                            <td valign="top"></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($count > 10): ?>
                                    <?php for($i = 0; $i < 10; $i++): ?>
                                        <tr>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                        </tr>
                                    <?php endfor; ?>
                                <?php else: ?>
                                    <?php for($i = 0; $i < 15; $i++): ?>
                                        <tr>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                            <td style="padding: 1.5rem;"></td>
                                        </tr>
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody> 
        </table>
</body>
</html><?php /**PATH /home/godesqco/meritaclinic.app/resources/views/PrintPanel/follow_up_print.blade.php ENDPATH**/ ?>